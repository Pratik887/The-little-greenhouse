# Changes: Shiprocket catalog integration

Reference: Shiprocket "SRC Custom Integration" Postman doc (Catalog APIs + Catalog Webhooks).

## New file
- `api/utils/FastrrCatalog.php`: single place that converts our products/categories into Shiprocket's catalog format and pushes them to Shiprocket. The pull feed and the push webhooks both use it, so they always return identical data.

## Modified: `api/index.php`
1. **Fetch Products / Fetch Products by Collection**
   (`GET /api/shiprocket/products?page=&limit=[&collection_id=]`) now built through `FastrrCatalog::mapProduct`.
   - `created_at` / `updated_at` are ISO 8601 with offset (were raw DB timestamps).
   - Each variant now has `option_values` (`{"Title":"Default"}`), as in the doc.
   - `compare_at_price` can no longer be lower than `price`.
   - Image URLs are always absolute.
   - Product `tags` now include the product's own tag.
2. **Fetch Collections** (`GET /api/shiprocket/collections`) built through `FastrrCatalog::mapCollection`: ISO dates, absolute image URL.
2b. `api/utils/FastrrCatalog.php` is loaded optionally: if it is missing on the server the rest of the API (admin login, checkout) still works, and only the catalog endpoints answer 503 with a clear message.
3. **Catalog webhooks (new behaviour):** previously `syncProductWebhook` / `syncCollectionWebhook` existed but were never called. Now:
   - Create / edit product -> `POST /wh/v1/custom/product`
   - Delete product -> sent with `status: archived`; inactive products are also sent as `archived`
   - Create category -> `POST /wh/v1/custom/collection`
   - Failures are only logged (`error_log`); they never block the admin save.
4. **New owner-only endpoint** `POST /api/admin/fastrr/catalog/sync`: pushes all active collections and products to Shiprocket once (use after adding the API key/secret).

## New file: `setup-owner.php` (one-time admin login fix, for hosts without terminal/phpMyAdmin)
Creates or resets the owner account (`admin@truelokal.com` / `admin@thelittlegreenhouse.com`) from the browser.
- Returns 404 unless `SETUP_TOKEN` (20+ chars) is set in `api/.env`; the token is required on every submit.
- Password must be 14+ characters; only the two authorized emails are accepted.
- Also clears any "too many sign-in attempts" block.
- After one success it deletes itself (or writes a lock file). Remove `SETUP_TOKEN` from `.env` afterwards.

The temporary root-level database/API diagnostic script has been removed after troubleshooting. Use `/api/health` for the normal health check; it reports whether the configured database is reachable.

## Modified: `admin/admin.js`
If the host returns an HTML page for `/api/...` (api/.htaccess missing or not applied), the admin page now retries through `/api/index.php?__route=/...` (plain file URL, works even when PATH_INFO is unsupported), then `/api/index.php/...`, and remembers the first that works. `api/index.php` accepts the `__route` query parameter for this. The "invalid JSON" error also now shows the first part of what the server sent.

## Modified: `README.md`
Documents the webhook push and the sync endpoint.

## Not changed
Checkout, order webhook, refunds, loyalty stubs, database schema. No DB migration needed.

## Credentials still needed (owner's Shiprocket account)
`FASTRR_API_KEY`, `FASTRR_API_SECRET` (Checkout), and `SHIPROCKET_EMAIL` / `SHIPROCKET_PASSWORD` (API user). Keep `api/.env` private and never package it with deployable source.

## Tested
Pull endpoints verified locally (SQLite) against the doc's response shape. Push webhooks not yet tested live (need real key/secret).
