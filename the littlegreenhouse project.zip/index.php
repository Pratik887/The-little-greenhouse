<?php
require_once __DIR__ . '/api/utils/SiteMedia.php';
$homeHeroPhoto = SiteMedia::get('home_hero');
$homeHeroMetaImage = SiteMedia::absolute($homeHeroPhoto) ?: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85';
$homeStoryPhoto = SiteMedia::get('home_story');
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — handmade pots, candles & home décor</title>
  <meta name="description"
    content="the little green house is a small studio making handcrafted pots, candles, plants and earthy home décor — every piece shaped, poured and finished by hand." />
  <meta name="keywords"
    content="handmade pots, hand poured candles, home decor, plants, artisan gifts, ceramic studio, earthy home decor, the little green house" />
  <meta name="author" content="the little green house" />
  <meta name="robots" content="index, follow" />
  <link rel="canonical" href="https://thelittlegreenhouse.in/" />

  <!-- open graph -->
  <meta property="og:title" content="the little green house — handmade pots, candles & home décor" />
  <meta property="og:description"
    content="small batch, hand shaped pieces for a warmer home. pots, candles, plants and décor — made slowly, by hand." />
  <meta property="og:type" content="website" />
  <meta property="og:image" content="<?= htmlspecialchars($homeHeroMetaImage, ENT_QUOTES, 'UTF-8') ?>" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/" />
  <meta property="og:site_name" content="the little green house" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="the little green house — handmade pots, candles & home décor" />
  <meta name="twitter:description"
    content="small batch, hand shaped pieces for a warmer home. pots, candles, plants and décor — made slowly, by hand." />
  <meta name="twitter:image" content="<?= htmlspecialchars($homeHeroMetaImage, ENT_QUOTES, 'UTF-8') ?>" />

  <!-- theme color for mobile browser UI -->
  <meta name="theme-color" content="#fbf7f1" />

  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🏺</text></svg>" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />

  <link rel="stylesheet" href="styles.css" />

  <!-- structured data for seo -->
  <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "Store",
        "name": "the little green house",
        "description": "handmade pots, candles, plants and earthy home décor, crafted by hand in small batches.",
        "priceRange": "$$",
        "image": <?= json_encode($homeHeroMetaImage, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
        "url": "https://thelittlegreenhouse.in/",
        "telephone": "+91 98765 43210",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Bhubaneswar",
          "addressRegion": "Odisha",
          "addressCountry": "IN"
        },
        "sameAs": [
          "https://instagram.com/thelittlegreenhouse",
          "https://pinterest.com/thelittlegreenhouse",
          "https://facebook.com/thelittlegreenhouse"
        ]
      }
    </script>
</head>

<body>
  <a class="skip-link" href="#main">skip to content</a>

  <!-- ambient grain overlay -->
  <div class="grain" aria-hidden="true"></div>

  <!-- ============ header ============ -->
  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="#top" class="logo" aria-label="the little green house home">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="34" height="34">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>


        <nav class="main-nav" id="main-nav" aria-label="primary">
          <a href="shop/">shop</a>
          <a href="ourstory/">our story</a>
          <a href="theprocess/">the process</a>
          <a href="reviews/">reviews</a>
          <a href="visit/">visit</a>
        </nav>

        <div class="header-actions">
          <a href="shop/" class="icon-btn" aria-label="search products">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <circle cx="11" cy="11" r="7" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
          </a>
          <a href="cart/" class="icon-btn cart-btn" aria-label="view cart">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <path
                d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
            </svg>
            <span class="cart-dot"></span>
          </a>
          <button class="menu-toggle" id="menuToggle" aria-label="open menu" aria-expanded="false"
            aria-controls="main-nav">
            <span></span><span></span><span></span>
          </button>
        </div>
    </div>
  </header>

  <main id="main">
    <!-- ============ hero ============ -->
    <section class="hero" aria-label="introduction">
      <div class="wrap hero-inner">
        <div class="hero-copy">
          <p class="eyebrow reveal">
            <span class="eyebrow-dot"></span>handmade in small batches, since
            2016
          </p>
          <h1 class="reveal">
            things for a home <br />
            that feels <em>lived in,</em> <br />not <em>bought.</em>
          </h1>
          <p class="hero-sub reveal">
            hand-thrown pots, hand-poured candles and slow-grown plants —
            every piece carries the mark of the hand that made it. no two are
            exactly alike, and that's the point.
          </p>
          <div class="hero-actions reveal">
            <a href="shop/" class="btn btn-primary">
              <span>browse the shop</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="5" y1="12" x2="19" y2="12" />
                <polyline points="12 5 19 12 12 19" />
              </svg>
            </a>
            <a href="ourstory/" class="btn btn-ghost">our story</a>
          </div>

          <div class="hero-badges reveal">
            <div class="badge-item">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
                <path d="M12 2l2.4 6.8L21 9l-5.5 4.3L17 21l-5-3.8L7 21l1.5-7.7L3 9l6.6-.2z" />
              </svg>
              <span>hand-finished, every piece</span>
            </div>
            <div class="badge-item">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
                <path d="M20 6L9 17l-5-5" />
              </svg>
              <span>no two pieces alike</span>
            </div>
            <div class="badge-item">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
                <rect x="3" y="7" width="18" height="13" rx="2" />
                <path d="M16 3v8M8 3v8" />
              </svg>
              <span>packed &amp; shipped with care</span>
            </div>
          </div>
        </div>

        <div class="hero-visual reveal" aria-hidden="true">
          <?php if ($homeHeroPhoto): ?>
            <img src="<?= htmlspecialchars($homeHeroPhoto, ENT_QUOTES, 'UTF-8') ?>" alt="The Little Green House studio" style="position:relative;z-index:1;width:min(420px,90%);height:420px;object-fit:cover;border-radius:28px;box-shadow:0 30px 40px rgba(53,29,21,.15);" fetchpriority="high" />
          <?php else: ?>
          <div class="hero-blob"></div>
          <svg class="hero-illustration" viewBox="0 0 420 480" xmlns="http://www.w3.org/2000/svg">
            <!-- shelf -->
            <rect x="20" y="400" width="380" height="10" rx="3" fill="#ce9969" opacity="0.5" />
            <!-- big pot -->
            <path d="M120 230 Q108 340 165 400 Q220 340 208 230 Z" fill="#c3804c" />
            <ellipse cx="164" cy="228" rx="46" ry="16" fill="#7a4632" />
            <ellipse cx="164" cy="224" rx="40" ry="13" fill="#ddbb94" />
            <!-- plant leaves in pot -->
            <path d="M164 224 C150 170 120 150 100 130 C130 150 155 170 164 210" fill="#8a9a6b" />
            <path d="M164 224 C178 160 210 140 235 118 C205 145 178 168 168 214" fill="#7a8a5c" />
            <path d="M164 224 C164 150 164 120 164 90 C164 130 164 170 164 220" fill="#9aab77" />
            <!-- candle -->
            <rect x="260" y="330" width="46" height="70" rx="4" fill="#f5ecdf" stroke="#ddbb94" stroke-width="2" />
            <rect x="278" y="312" width="10" height="20" fill="#e5cdae" />
            <ellipse class="flame" cx="283" cy="304" rx="6" ry="12" fill="#e6a95c" />
            <ellipse cx="283" cy="308" rx="3" ry="6" fill="#fbf7f1" />
            <!-- small pot -->
            <path d="M320 360 Q314 400 345 410 Q376 400 370 360 Z" fill="#975637" />
            <ellipse cx="345" cy="358" rx="26" ry="9" fill="#633b2b" />
            <path d="M345 358 C336 330 320 320 308 305 C325 320 340 335 347 356" fill="#8a9a6b" />
            <path d="M345 358 C352 325 368 315 380 300 C365 320 352 338 347 356" fill="#7a8a5c" />
          </svg>
          <?php endif; ?>
        </div>
      </div>

      <div class="scroll-cue reveal" aria-hidden="true">
        <span>scroll</span>
        <div class="scroll-line"></div>
      </div>
    </section>

    <!-- ============ marquee strip ============ -->
    <div class="marquee" aria-hidden="true">
      <div class="marquee-track">
        <span>hand-thrown pottery</span><span>•</span>
        <span>soy wax candles</span><span>•</span>
        <span>slow-grown plants</span><span>•</span>
        <span>earthy home décor</span><span>•</span>
        <span>made to be kept, not replaced</span><span>•</span>
        <span>hand-thrown pottery</span><span>•</span>
        <span>soy wax candles</span><span>•</span>
        <span>slow-grown plants</span><span>•</span>
        <span>earthy home décor</span><span>•</span>
        <span>made to be kept, not replaced</span><span>•</span>
      </div>
    </div>

    <!-- ============ categories ============ -->
    <section class="offer-banner" aria-label="current offer"
      style="padding:20px 24px;margin:12px auto 28px;max-width:1160px;text-align:center;background:#f5ecdf;border:1px solid rgba(99,59,43,.12);border-radius:14px">
      <p class="eyebrow">a little something extra</p>
      <h2 style="margin:6px 0">Complimentary shipping on orders over ₹999</h2>
      <a href="shop/" class="btn btn-ghost">shop the collection →</a>
    </section>
    <section class="categories" aria-label="shop by category">
      <div class="wrap">
        <div class="section-head">
          <p class="eyebrow reveal">
            <span class="eyebrow-dot"></span>shop by category
          </p>
          <h2 class="reveal">four kinds of quiet</h2>
        </div>

        <div class="cat-grid">
          <a href="shop/?cat=pots" class="cat-card reveal">
            <div class="cat-icon">
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="M6 8l1.5 12a2 2 0 0 0 2 1.8h5a2 2 0 0 0 2-1.8L18 8" />
                <ellipse cx="12" cy="8" rx="7" ry="2.5" />
              </svg>
            </div>
            <h3>pots &amp; planters</h3>
            <p>wheel-thrown stoneware, each one glazed by hand</p>
          </a>

          <a href="shop/?cat=candles" class="cat-card reveal">
            <div class="cat-icon">
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="M9 21h6M12 21v-6M8 15h8l-1-9H9l-1 9Z" />
                <path d="M12 6c1 -2 -1 -3 0 -5c1 2 3 3 1 5" />
              </svg>
            </div>
            <h3>candles</h3>
            <p>slow-burning soy wax, poured and wicked by hand</p>
          </a>

          <a href="shop/?cat=plants" class="cat-card reveal">
            <div class="cat-icon">
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="M12 22V10M12 10c-4-1-6-4-6-8 4 0 6 3 6 6M12 10c4-1 6-4 6-8-4 0-6 3-6 6" />
              </svg>
            </div>
            <h3>plants</h3>
            <p>easy-care greens, grown slow and rooted deep</p>
          </a>

          <a href="shop/?cat=decor" class="cat-card reveal">
            <div class="cat-icon">
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <path d="M3 15l5-5 4 4 5-6 4 5" />
              </svg>
            </div>
            <h3>home décor</h3>
            <p>trays, mirrors &amp; textures for a warmer room</p>
          </a>
        </div>
      </div>
    </section>

    <!-- ============ shop / featured products ============ -->
    <section class="shop" id="shop" aria-label="featured products">
      <div class="wrap">
        <div class="section-head">
          <p class="eyebrow reveal">
            <span class="eyebrow-dot"></span>the current collection
          </p>
          <h2 class="reveal">pieces worth living with</h2>
          <p class="section-sub reveal">
            small runs, made when the studio has time to do them right. once
            they're gone, that particular piece won't return.
          </p>
        </div>

        <div class="filter-row reveal" role="tablist" aria-label="filter products">
          <button class="filter-chip is-active" role="tab" aria-selected="true" data-filter="all">
            all
          </button>
          <button class="filter-chip" role="tab" aria-selected="false" data-filter="pots">
            pots
          </button>
          <button class="filter-chip" role="tab" aria-selected="false" data-filter="candles">
            candles
          </button>
          <button class="filter-chip" role="tab" aria-selected="false" data-filter="plants">
            plants
          </button>
          <button class="filter-chip" role="tab" aria-selected="false" data-filter="decor">
            décor
          </button>
        </div>

        <div class="product-grid" id="productGrid">
          <!-- injected by js -->
        </div>
        <div style="text-align: center; margin-top: 48px;" class="reveal">
          <a href="shop/" class="btn btn-primary">
            <span>view full collection in shop</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="5" y1="12" x2="19" y2="12" />
              <polyline points="12 5 19 12 12 19" />
            </svg>
          </a>
        </div>
      </div>
    </section>

    <!-- ============ story / authenticity ============ -->
    <section class="story" id="story" aria-label="our story">
      <div class="wrap story-inner">
        <div class="story-visual reveal" aria-hidden="true">
          <div class="story-frame">
            <?php if ($homeStoryPhoto): ?>
              <img src="<?= htmlspecialchars($homeStoryPhoto, ENT_QUOTES, 'UTF-8') ?>" alt="Inside The Little Green House studio" style="display:block;width:100%;height:auto;object-fit:cover;" loading="lazy" />
            <?php else: ?>
            <svg viewBox="0 0 360 420" xmlns="http://www.w3.org/2000/svg">
              <rect x="0" y="0" width="360" height="420" fill="#e5cdae" />
              <!-- potter's wheel with pot being shaped -->
              <ellipse cx="180" cy="330" rx="130" ry="26" fill="#c3804c" opacity="0.5" />
              <ellipse cx="180" cy="322" rx="130" ry="22" fill="#975637" />
              <path d="M138 200 Q126 290 180 322 Q234 290 222 200 Z" fill="#ce9969" />
              <ellipse cx="180" cy="198" rx="46" ry="15" fill="#7a4632" />
              <ellipse cx="180" cy="193" rx="38" ry="11" fill="#e5cdae" opacity="0.8" />
              <!-- hands shaping the pot -->
              <path d="M118 250 Q100 235 96 205 Q94 190 108 188 Q120 188 124 202 Q140 220 140 250 Z" fill="#7a4632" />
              <path d="M242 250 Q260 235 264 205 Q266 190 252 188 Q240 188 236 202 Q220 220 220 250 Z" fill="#7a4632" />
              <!-- water splash dots for texture -->
              <circle cx="150" cy="140" r="4" fill="#fbf7f1" opacity="0.6" />
              <circle cx="210" cy="150" r="3" fill="#fbf7f1" opacity="0.6" />
              <circle cx="180" cy="120" r="3" fill="#fbf7f1" opacity="0.5" />
            </svg>
            <?php endif; ?>
            <span class="story-tag">est. 2016 · one studio, one wheel</span>
          </div>
        </div>

        <div class="story-copy">
          <p class="eyebrow reveal">
            <span class="eyebrow-dot"></span>our story
          </p>
          <h2 class="reveal">
            made by one pair of hands, <em>not a factory line.</em>
          </h2>
          <p class="reveal">
            the little green house started in a spare room with a second-hand
            pottery wheel and a handful of candle tins. nine years on, it's
            still a small studio — every pot still centred on the wheel by
            hand, every candle still poured one batch at a time, every plant
            still potted before it ships.
          </p>
          <p class="reveal">
            we don't chase volume. we'd rather make three hundred pieces we're
            proud of than three thousand we're not. if a glaze runs a little
            differently, or a candle's edge isn't perfectly straight — that's
            not a flaw slipping through. that's the hand that made it, still
            visible.
          </p>

          <div class="story-stats reveal">
            <div class="stat">
              <span class="stat-num">9</span>
              <span class="stat-label">years in the studio</span>
            </div>
            <div class="stat">
              <span class="stat-num">100%</span>
              <span class="stat-label">hand-finished pieces</span>
            </div>
            <div class="stat">
              <span class="stat-num">1</span>
              <span class="stat-label">wheel, one studio</span>
            </div>
          </div>
          <div class="reveal" style="margin-top: 28px;">
            <a href="ourstory/" class="btn btn-ghost">read the full studio story &rarr;</a>
          </div>
        </div>
      </div>
    </section>

    <!-- ============ process ============ -->
    <section class="process" id="process" aria-label="how we make our pieces">
      <div class="wrap">
        <div class="section-head">
          <p class="eyebrow reveal">
            <span class="eyebrow-dot"></span>how it's made
          </p>
          <h2 class="reveal">from raw material to your shelf</h2>
        </div>

        <div class="process-row">
          <div class="process-step reveal">
            <span class="process-num">01</span>
            <h3>shaped by hand</h3>
            <p>
              clay is centred and thrown on the wheel; wax is weighed and
              warmed by eye, not app.
            </p>
          </div>
          <div class="process-step reveal">
            <span class="process-num">02</span>
            <h3>finished slow</h3>
            <p>
              glazes are mixed in-house, candles rest for two weeks before
              they're ever lit.
            </p>
          </div>
          <div class="process-step reveal">
            <span class="process-num">03</span>
            <h3>checked by hand</h3>
            <p>
              every single piece is inspected before it's wrapped — nothing
              ships that we wouldn't keep.
            </p>
          </div>
          <div class="process-step reveal">
            <span class="process-num">04</span>
            <h3>wrapped with care</h3>
            <p>
              packed in recycled kraft and straw, cushioned for the trip to
              your door.
            </p>
          </div>
        </div>
        <div style="text-align: center; margin-top: 48px;" class="reveal">
          <a href="theprocess/" class="btn btn-ghost">explore the full crafting process &rarr;</a>
        </div>
      </div>
    </section>

    <!-- ============ testimonials ============ -->
    <section class="reviews" id="reviews" aria-label="customer reviews">
      <div class="wrap">
        <div class="section-head">
          <p class="eyebrow reveal">
            <span class="eyebrow-dot"></span>kind words
          </p>
          <h2 class="reveal">from homes like yours</h2>
        </div>

        <div class="review-grid">
          <figure class="review-card reveal">
            <div class="stars" aria-hidden="true">★★★★★</div>
            <blockquote>
              “you can genuinely feel the difference. the glaze on my planter
              isn't perfect — and that's exactly why I love it.”
            </blockquote>
            <figcaption>— anjali r., bengaluru</figcaption>
          </figure>
          <figure class="review-card reveal">
            <div class="stars" aria-hidden="true">★★★★★</div>
            <blockquote>
              “the candle burned so evenly and smelled nothing like the
              mass-produced ones I'd bought before. worth every rupee.”
            </blockquote>
            <figcaption>— devansh k., pune</figcaption>
          </figure>
          <figure class="review-card reveal">
            <div class="stars" aria-hidden="true">★★★★★</div>
            <blockquote>
              “packaging alone felt like a gift. my mother still has the note
              that came with her pot.”
            </blockquote>
            <figcaption>— priya s., bhubaneswar</figcaption>
          </figure>
        </div>
        <div style="text-align: center; margin-top: 48px;" class="reveal">
          <a href="reviews/" class="btn btn-ghost">read all customer reviews &rarr;</a>
        </div>
      </div>
    </section>

    <!-- ============ newsletter / visit ============ -->
    <section class="visit" id="visit" aria-label="visit the studio and newsletter">
      <div class="wrap visit-inner">
        <div class="visit-copy">
          <p class="eyebrow reveal">
            <span class="eyebrow-dot"></span>stay in touch
          </p>
          <h2 class="reveal">new pieces drop in small runs.</h2>
          <p class="reveal">
            join the list and hear first — before things sell out. no spam,
            just the studio's quiet updates.
          </p>

          <form class="newsletter-form reveal" id="newsletterForm">
            <label for="newsletterEmail" class="visually-hidden">email address</label>
            <input type="email" id="newsletterEmail" placeholder="your email address" required autocomplete="email" />
            <button type="submit" class="btn btn-primary">
              <span>join the list</span>
            </button>
          </form>
          <p class="form-note" id="formNote" aria-live="polite"></p>
        </div>

        <div class="visit-info reveal">
          <h3>visit the studio</h3>
          <p>by appointment — we love showing people around the wheel.</p>
          <p style="margin-top: 14px;"><a href="visit/" class="btn btn-ghost"
              style="padding: 9px 20px; font-size: 0.85rem;">book an appointment &rarr;</a></p>
          <ul>
            <li>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                <path d="M21 10c0 6-9 12-9 12S3 16 3 10a9 9 0 1 1 18 0Z" />
                <circle cx="12" cy="10" r="3" />
              </svg>
              <span>bhubaneswar, odisha, india</span>
            </li>
            <li>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                <path
                  d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.1-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.7a2 2 0 0 1-.5 2.1L8 9.7a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.5 2.7.6a2 2 0 0 1 1.7 2Z" />
              </svg>
              <span>+91 98765 43210</span>
            </li>
            <li>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                <path d="M4 4h16v16H4z" />
                <path d="m4 6 8 7 8-7" />
              </svg>
              <span>hello@thelittlegreenhouse.com</span>
            </li>
          </ul>
        </div>
      </div>
    </section>
  </main>

  <!-- ============ footer ============ -->
  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>
          handmade pots, candles &amp; home décor — made slowly, on purpose.
        </p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>

      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="shop/?cat=pots">pots &amp; planters</a>
        <a href="shop/?cat=candles">candles</a>
        <a href="shop/?cat=plants">plants</a>
        <a href="shop/?cat=decor">home décor</a>
        <a href="category/">browse categories</a>
      </nav>

      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="ourstory/">our story</a>
        <a href="theprocess/">the process</a>
        <a href="reviews/">reviews</a>
        <a href="visit/">visit us</a>
        <a href="faqs/">faqs</a>
      </nav>

      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="shipping-and-returns/">shipping &amp; returns</a>
        <a href="care-guide/">caring for your piece</a>
        <a href="terms-and-conditions/">terms &amp; conditions</a>
        <a href="privacy-policy/">privacy policy</a>
        <a href="order/">track order</a>
        <a href="cart/">shopping cart</a>
      </div>
    </div>

    <div class="wrap footer-bottom">
      <p>
        © 2026 The Little Green House. Developed by MSC HIRETECH.
      </p>
    </div>
  </footer>

  <script src="script.js"></script>
</body>

</html>
