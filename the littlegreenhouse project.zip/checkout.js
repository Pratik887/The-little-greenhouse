(function () {
  'use strict';

  const scriptFallback = 'https://checkout-ui.shiprocket.com/assets/js/channels/shopify.js';
  const styleFallback = 'https://checkout-ui.shiprocket.com/assets/styles/shopify.css';
  let sdkPromise = null;

  function providerAsset(value, fallback) {
    const url = new URL(value || fallback, window.location.href);
    if (url.protocol !== 'https:' || url.hostname !== 'checkout-ui.shiprocket.com') {
      throw new Error('The configured Fastrr checkout asset URL is invalid.');
    }
    return url.href;
  }

  function loadSdk(src) {
    if (window.HeadlessCheckout) return Promise.resolve();
    if (sdkPromise) return sdkPromise;

    sdkPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.async = true;
      script.onload = resolve;
      script.onerror = () => {
        sdkPromise = null;
        reject(new Error('Fastrr checkout script could not load. Please try again.'));
      };
      document.head.append(script);
    });
    return sdkPromise;
  }

  async function startCheckout(items, clickEvent) {
    const normalizedItems = (Array.isArray(items) ? items : []).map((item) => ({
      product_id: Number(item.product_id),
      quantity: Number(item.quantity)
    }));
    if (!normalizedItems.length || normalizedItems.some((item) =>
      !Number.isSafeInteger(item.product_id) || item.product_id < 1 ||
      !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 20
    )) {
      throw new Error('Your cart contains an invalid product or quantity. Refresh the page and try again.');
    }

    const endpoint = new URL('../api/fastrr/checkout', document.baseURI);
    const response = await fetch(endpoint.href, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ items: normalizedItems })
    });
    const responseText = await response.text();
    let data = null;
    try {
      data = JSON.parse(responseText.replace(/^\uFEFF/, ''));
    } catch (_) {}
    if (!response.ok) {
      throw new Error(data?.error || `Checkout could not start (HTTP ${response.status}).`);
    }
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      const contentType = response.headers.get('content-type') || 'missing';
      throw new Error(`The checkout API returned invalid JSON (HTTP ${response.status}, ${contentType}). Check the PHP API route.`);
    }

    if (typeof data.token !== 'string' || !data.token) {
      throw new Error('Fastrr did not return a checkout access token.');
    }

    const styleUrl = providerAsset(data.checkout_style, styleFallback);
    if (![...document.querySelectorAll('link[rel="stylesheet"]')].some((link) => link.href === styleUrl)) {
      const stylesheet = document.createElement('link');
      stylesheet.rel = 'stylesheet';
      stylesheet.href = styleUrl;
      document.head.append(stylesheet);
    }

    await loadSdk(providerAsset(data.checkout_script, scriptFallback));
    if (typeof window.HeadlessCheckout?.addToCart !== 'function') {
      throw new Error('Fastrr checkout did not initialize. Please try again.');
    }
    window.HeadlessCheckout.addToCart(clickEvent, data.token);
  }

  window.TLGHCheckout = { startCheckout };
})();
