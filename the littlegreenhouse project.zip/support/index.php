<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Customer support | The Little Green House</title>
    <meta name="description" content="Get help with a Little Green House order, shipping, returns or product care.">
    <link rel="canonical" href="https://thelittlegreenhouse.in/support/" />
    <link rel="stylesheet" href="../styles.css">
    <style>
        main {
            max-width: 760px;
            margin: 8vh auto;
            padding: 24px
        }

        main p {
            line-height: 1.8
        }

        .help {
            padding: 20px;
            background: #f5ecdf;
            border-radius: 12px;
            margin: 16px 0
        }
    </style>
  <meta property="og:title" content="Customer support | The Little Green House" />
  <meta property="og:description" content="Get help with a Little Green House order, shipping, returns or product care." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/support/" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
    <main><a href="../">← home</a>
        <h1>How can we help?</h1>
        <p>We’re happy to help with order updates, delivery questions, returns, or caring for your piece.</p>
        <section class="help">
            <h2>Order and delivery</h2>
            <p>Look up payment and delivery status with your order number and checkout email.</p><a
                class="btn btn-primary" href="../order/">track an order</a>
        </section>
        <section class="help">
            <h2>Returns and shipping</h2>
            <p>Read our shipping, delivery and return information.</p><a href="../shipping-and-returns/">shipping &amp;
                returns policy</a>
        </section>
        <section class="help">
            <h2>Product care</h2>
            <p>Find care instructions for plants, ceramics and candles.</p><a href="../care-guide/">care guide</a>
        </section>
        <section class="help">
            <h2>Talk to our studio</h2>
            <p>Email us and include your order number if your question is about an order.</p><a class="btn btn-primary"
                href="mailto:orders@thelittlegreenhouse.com?subject=Store%20support">email customer support</a>
        </section>
    </main>
    <footer class="site-footer">
        <div class="wrap">
            <p>© 2026 The Little Green House · Developed by MSC HIRETECH</p>
        </div>
    </footer>
</body>

</html>