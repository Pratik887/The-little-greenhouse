<?php
require_once __DIR__ . '/../api/utils/SiteMedia.php';
$visitHeroPhoto = SiteMedia::get('visit_hero');
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — visit the studio</title>
  <meta name="description"
    content="visit the the little green house studio in bhubaneswar — by appointment only. see the wheel, smell the candles, and take home something made just for you." />
  <link rel="canonical" href="https://thelittlegreenhouse.in/visit/" />
  <meta property="og:title" content="the little green house — visit the studio" />
  <meta property="og:description" content="plan a visit to our Bhubaneswar studio and see how our pieces are made." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/visit/" />
  <?php if ($visitHeroPhoto): ?><meta property="og:image" content="<?= htmlspecialchars(SiteMedia::absolute($visitHeroPhoto), ENT_QUOTES, 'UTF-8') ?>" /><?php endif; ?>
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🏺</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    /* ============================================================
       the little green house — visit page (with appointment form)
       ============================================================ */
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1180px;
    }

    *,
    *::before,
    *::after {
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      margin: 0;
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
    }

    img,
    svg {
      display: block;
      max-width: 100%;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    ul {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    h1,
    h2,
    h3,
    h4 {
      font-family: var(--font-display);
      font-weight: 500;
      margin: 0;
      text-transform: lowercase;
    }

    p {
      margin: 0;
    }

    input,
    textarea,
    select {
      font-family: inherit;
      text-transform: lowercase;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    .reveal {
      opacity: 0;
      transform: translateY(22px);
      transition:
        opacity 0.9s var(--ease-hand),
        transform 0.9s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      html {
        scroll-behavior: auto;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 15px 28px;
      border-radius: 100px;
      font-size: 0.95rem;
      letter-spacing: 0.02em;
      transition:
        transform 0.35s var(--ease-hand),
        box-shadow 0.35s var(--ease-hand),
        background 0.35s ease,
        color 0.35s ease;
      white-space: nowrap;
    }

    .btn svg {
      transition: transform 0.35s var(--ease-hand);
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
      background: var(--c-900);
    }

    .btn-primary:hover svg {
      transform: translateX(4px);
    }

    .btn-ghost {
      background: transparent;
      border: 1.5px solid var(--c-800);
      color: var(--ink);
    }

    .btn-ghost:hover {
      background: var(--c-800);
      color: var(--c-50);
      transform: translateY(-3px);
    }

    .eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 9px;
      font-family: var(--font-body);
      font-size: 0.82rem;
      letter-spacing: 0.14em;
      color: var(--c-700);
      margin-bottom: 14px;
    }

    .eyebrow-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-600);
      box-shadow: 0 0 0 4px var(--c-200);
    }

    /* ---------- header ---------- */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 500;
      background: rgba(251, 247, 241, 0.82);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 82px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.3rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active-link {
      color: var(--ink);
    }

    .main-nav a.is-active-link::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s ease,
        color 0.3s ease;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition:
        transform 0.3s var(--ease-hand),
        opacity 0.3s ease;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* ===== visit hero ===== */
    .visit-hero {
      padding: 70px 0 40px;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .visit-hero-inner {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .visit-hero h1 {
      font-size: clamp(2.4rem, 5vw, 4rem);
      line-height: 1.08;
      letter-spacing: -0.01em;
      max-width: 780px;
      margin-bottom: 18px;
    }

    .visit-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .visit-hero p {
      font-size: 1.15rem;
      color: var(--muted);
      max-width: 620px;
      margin-bottom: 28px;
    }

    /* ===== visit content ===== */
    .visit-main {
      padding: 60px 0 80px;
    }

    .visit-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 60px;
      align-items: start;
    }

    /* ----- left: info ----- */
    .visit-info-block h2 {
      font-size: 1.9rem;
      margin-bottom: 16px;
    }

    .visit-info-block h2 em {
      color: var(--c-600);
      font-style: italic;
    }

    .visit-info-block .lead {
      color: var(--muted);
      font-size: 1.05rem;
      margin-bottom: 28px;
      max-width: 480px;
    }

    .visit-details {
      display: flex;
      flex-direction: column;
      gap: 18px;
      margin-bottom: 34px;
    }

    .visit-details li {
      display: flex;
      align-items: center;
      gap: 14px;
      font-size: 1rem;
      color: var(--ink-soft);
    }

    .visit-details li svg {
      color: var(--c-600);
      flex-shrink: 0;
      width: 20px;
      height: 20px;
    }

    .visit-details li strong {
      font-weight: 500;
      color: var(--ink);
    }

    .visit-hours {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      padding: 22px 26px;
      margin-top: 10px;
    }

    .visit-hours h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.08em;
      color: var(--c-600);
      margin-bottom: 10px;
    }

    .visit-hours p {
      font-size: 0.95rem;
      color: var(--ink-soft);
    }

    .visit-hours span {
      display: inline-block;
      margin-right: 16px;
    }

    /* ----- right: form ----- */
    .form-card {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      padding: 38px 34px 40px;
      box-shadow: var(--shadow-soft);
    }

    .form-card h3 {
      font-size: 1.5rem;
      margin-bottom: 6px;
    }

    .form-card .form-sub {
      color: var(--muted);
      font-size: 0.95rem;
      margin-bottom: 28px;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-size: 0.85rem;
      font-weight: 500;
      color: var(--ink-soft);
      margin-bottom: 5px;
      letter-spacing: 0.02em;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
      width: 100%;
      padding: 13px 16px;
      border-radius: var(--radius-sm);
      border: 1.5px solid var(--line);
      background: var(--bg);
      font-size: 0.95rem;
      color: var(--ink);
      transition:
        border-color 0.3s ease,
        box-shadow 0.3s ease;
      font-family: var(--font-body);
    }

    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
      border-color: var(--c-500);
      box-shadow: 0 0 0 4px var(--c-200);
      outline: none;
    }

    .form-group textarea {
      resize: vertical;
      min-height: 100px;
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    .form-group .helper {
      font-size: 0.78rem;
      color: var(--muted);
      margin-top: 4px;
    }

    .form-card .btn {
      width: 100%;
      justify-content: center;
      margin-top: 6px;
      padding: 16px;
    }

    .form-note {
      margin-top: 14px;
      font-size: 0.85rem;
      color: var(--c-700);
      text-align: center;
      min-height: 1.4em;
    }

    .form-note.success {
      color: var(--c-600);
    }

    .form-note.error {
      color: #b34a4a;
    }

    /* ===== map / studio visual ===== */
    .studio-map {
      margin-top: 60px;
      border-radius: var(--radius-lg);
      overflow: hidden;
      border: 1px solid var(--line);
      background: var(--surface-2);
      padding: 30px 20px;
      text-align: center;
    }

    .studio-map svg {
      max-width: 100%;
      height: auto;
      border-radius: var(--radius-sm);
    }

    .studio-map p {
      margin-top: 14px;
      font-size: 0.9rem;
      color: var(--muted);
    }

    /* ===== footer ===== */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 80px 0 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.6fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 60px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand .logo-text em {
      color: var(--c-400);
    }

    .footer-brand p {
      margin: 16px 0 22px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 10px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      color: var(--c-200);
      transition:
        background 0.3s ease,
        transform 0.3s var(--ease-hand);
    }

    .socials a:hover {
      background: var(--c-600);
      transform: translateY(-3px);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 18px;
    }

    .footer-col {
      display: flex;
      flex-direction: column;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.3s ease;
    }

    .footer-col a:hover {
      color: var(--c-100);
    }

    .footer-bottom {
      padding: 26px 0;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
      text-align: center;
    }

    /* ===== responsive ===== */
    @media (max-width: 1024px) {
      .visit-grid {
        grid-template-columns: 1fr;
        gap: 44px;
      }

      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 20px;
      }

      .main-nav {
        position: fixed;
        top: 82px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 20px 28px 30px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition:
          transform 0.45s var(--ease-hand),
          opacity 0.4s ease;
        z-index: 400;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 14px 0;
        border-bottom: 1px solid var(--line);
      }

      .menu-toggle {
        display: flex;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 34px;
      }

      .form-row {
        grid-template-columns: 1fr;
      }

      .form-card {
        padding: 28px 20px;
      }

      .visit-hero h1 {
        font-size: 2rem;
      }

      .visit-main {
        padding: 40px 0 60px;
      }

      .studio-map {
        padding: 16px 10px;
      }

      .visit-hours span {
        display: block;
        margin-right: 0;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <link rel="canonical" href="https://thelittlegreenhouse.in/visit/" />
  <meta property="og:title" content="the little green house — visit the studio" />
  <meta property="og:description" content="visit the the little green house studio in bhubaneswar — by appointment only. see the wheel, smell the candles, and take home something made just for you." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/visit/" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
  <a class="skip-link" href="#main">skip to content</a>
  <div class="grain" aria-hidden="true"></div>

  <!-- ===== header ===== -->
  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="34" height="34">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/" class="is-active-link">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="open menu" aria-expanded="false"
          aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <!-- ===== hero ===== -->
    <section class="visit-hero" aria-label="visit the studio"<?= $visitHeroPhoto ? ' style="background-image:linear-gradient(rgba(251,247,241,.82),rgba(251,247,241,.90)),url(\'' . htmlspecialchars($visitHeroPhoto, ENT_QUOTES, 'UTF-8') . '\');background-size:cover;background-position:center"' : '' ?>>
      <div class="wrap visit-hero-inner">
        <p class="eyebrow reveal">
          <span class="eyebrow-dot"></span>come see the wheel
        </p>
        <h1 class="reveal">visit the <em>studio</em></h1>
        <p class="reveal">
          we're a small space in bhubaneswar — by appointment only. come see
          how things are made, smell the wax, and take home something special.
        </p>
      </div>
    </section>

    <!-- ===== visit content ===== -->
    <section class="visit-main" id="visit" aria-label="studio visit and appointment">
      <div class="wrap">
        <div class="visit-grid">
          <!-- left: info -->
          <div class="visit-info-block reveal">
            <h2>plan your <em>visit</em></h2>
            <p class="lead">
              we love showing people around the wheel. every visit is a chance
              to see the process up close — and maybe even get your hands on a
              piece that hasn't been listed yet.
            </p>

            <ul class="visit-details">
              <li>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                  <path d="M21 10c0 6-9 12-9 12S3 16 3 10a9 9 0 1 1 18 0Z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
                <span><strong>location</strong> — bhubaneswar, odisha,
                  india</span>
              </li>
              <li>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                  <path
                    d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.1-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.7a2 2 0 0 1-.5 2.1L8 9.7a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.5 2.7.6a2 2 0 0 1 1.7 2Z" />
                </svg>
                <span><strong>phone</strong> — +91 98765 43210</span>
              </li>
              <li>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
                  <path d="M4 4h16v16H4z" />
                  <path d="m4 6 8 7 8-7" />
                </svg>
                <span><strong>email</strong> — hello@thelittlegreenhouse.com</span>
              </li>
            </ul>

            <div class="visit-hours">
              <h4>studio hours (by appointment)</h4>
              <p>
                <span>mon–fri: 10:00 am – 6:00 pm</span>
                <span>sat: 11:00 am – 4:00 pm</span>
                <span>sun: closed</span>
              </p>
            </div>
          </div>

          <!-- right: appointment form -->
          <div class="form-card reveal">
            <h3>book an appointment</h3>
            <p class="form-sub">
              we'll confirm within 24 hours. visits are about 45 minutes —
              just enough time to see the wheel, pour a candle, and browse.
            </p>

            <form id="appointmentForm" novalidate>
              <div class="form-row">
                <div class="form-group">
                  <label for="fullName">full name</label>
                  <input type="text" id="fullName" placeholder="your name" required autocomplete="name" />
                </div>
                <div class="form-group">
                  <label for="email">email address</label>
                  <input type="email" id="email" placeholder="you@example.com" required autocomplete="email" />
                </div>
              </div>

              <div class="form-group">
                <label for="phone">phone number</label>
                <input type="tel" id="phone" placeholder="+91 98765 43210" autocomplete="tel" />
              </div>

              <div class="form-row">
                <div class="form-group">
                  <label for="visitDate">preferred date</label>
                  <input type="date" id="visitDate" required />
                </div>
                <div class="form-group">
                  <label for="visitTime">preferred time</label>
                  <select id="visitTime" required>
                    <option value="">select a time</option>
                    <option value="10:00">10:00 am</option>
                    <option value="11:00">11:00 am</option>
                    <option value="12:00">12:00 pm</option>
                    <option value="13:00">1:00 pm</option>
                    <option value="14:00">2:00 pm</option>
                    <option value="15:00">3:00 pm</option>
                    <option value="16:00">4:00 pm</option>
                    <option value="17:00">5:00 pm</option>
                  </select>
                </div>
              </div>

              <div class="form-group">
                <label for="guests">number of guests</label>
                <select id="guests">
                  <option value="1">1</option>
                  <option value="2" selected>2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5+</option>
                </select>
              </div>

              <div class="form-group">
                <label for="notes">anything special? (optional)</label>
                <textarea id="notes"
                  placeholder="e.g. celebrating a birthday, looking for a specific piece..."></textarea>
              </div>

              <button type="submit" class="btn btn-primary">
                request appointment
              </button>
              <p class="form-note" id="formNote" aria-live="polite"></p>
            </form>
          </div>
        </div>

        <!-- ===== map / studio visual ===== -->
        <div class="studio-map reveal">
          <!--<svg viewBox="0 0 800 280" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">-->
          <!--  <rect width="800" height="280" fill="#f5ecdf" rx="16" />-->
          <!--  <rect x="40" y="40" width="720" height="200" rx="12" fill="#e5cdae" opacity="0.5" />-->
            <!-- stylised map pin -->
          <!--  <circle cx="400" cy="130" r="40" fill="#b56c41" opacity="0.2" />-->
          <!--  <circle cx="400" cy="130" r="28" fill="#c3804c" opacity="0.4" />-->
          <!--  <circle cx="400" cy="130" r="16" fill="#7a4632" />-->
          <!--  <circle cx="400" cy="124" r="6" fill="#fbf7f1" opacity="0.6" />-->
            <!-- roads -->
          <!--  <line x1="180" y1="130" x2="280" y2="130" stroke="#975637" stroke-width="2" opacity="0.3" />-->
          <!--  <line x1="520" y1="130" x2="620" y2="130" stroke="#975637" stroke-width="2" opacity="0.3" />-->
          <!--  <line x1="400" y1="60" x2="400" y2="100" stroke="#975637" stroke-width="2" opacity="0.3" />-->
          <!--  <line x1="400" y1="160" x2="400" y2="200" stroke="#975637" stroke-width="2" opacity="0.3" />-->
            <!-- small markers -->
          <!--  <circle cx="260" cy="130" r="6" fill="#ce9969" opacity="0.5" />-->
          <!--  <circle cx="540" cy="130" r="6" fill="#ce9969" opacity="0.5" />-->
          <!--  <text x="395" y="200" font-family="Jost, sans-serif" font-size="14" fill="#7a4632" text-anchor="middle"-->
          <!--    letter-spacing="0.06em">-->
          <!--    the little green house · bhubaneswar-->
          <!--  </text>-->
          <!--</svg>-->
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3743.4488918879747!2d85.798943575009!3d20.240209681219!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a19a757756a9313%3A0xef01e39b2b2f9fd5!2sThe%20Little%20Green%20House!5e0!3m2!1sen!2sin!4v1791888093960!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>
          <p>
            we're located in the heart of bhubaneswar — exact address shared
            upon confirmation.
          </p>
        </div>

        <!-- back to top -->
        <div style="text-align: center; margin-top: 50px" class="reveal">
          <a href="#top" class="btn btn-ghost" style="padding: 12px 32px">back to top</a>
        </div>
      </div>
    </section>
  </main>

  <!-- ===== footer ===== -->
  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>
          handmade pots, candles &amp; home décor — made slowly, on purpose.
        </p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    (function () {
      "use strict";

      // ---------- scroll reveal ----------
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.15, rootMargin: "0px 0px -40px 0px" },
      );

      document
        .querySelectorAll(".reveal")
        .forEach((el) => observer.observe(el));

      // ---------- appointment form ----------
      const form = document.getElementById("appointmentForm");
      const note = document.getElementById("formNote");

      form.addEventListener("submit", function (e) {
        e.preventDefault();

        const name = document.getElementById("fullName").value.trim();
        const email = document.getElementById("email").value.trim();
        const date = document.getElementById("visitDate").value;
        const time = document.getElementById("visitTime").value;

        if (!name || !email || !date || !time) {
          note.textContent = "please fill in all required fields.";
          note.className = "form-note error";
          return;
        }

        // simple email validation
        if (!email.includes("@") || !email.includes(".")) {
          note.textContent = "please enter a valid email address.";
          note.className = "form-note error";
          return;
        }

        // success simulation
        note.textContent =
          "thank you — we'll confirm your appointment within 24 hours. we look forward to seeing you!";
        note.className = "form-note success";
        form.reset();

        // clear success after 8 seconds
        setTimeout(() => {
          note.textContent = "";
          note.className = "form-note";
        }, 8000);
      });

      // ---------- mobile nav ----------
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) => {
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          });
        });
      }

      // ---------- cart dot (visual) ----------
      const cartDot = document.querySelector(".cart-dot");
      document.addEventListener("click", (e) => {
        const btn = e.target.closest(".add-btn");
        if (!btn) return;
        if (cartDot) {
          cartDot.style.animation = "none";
          void cartDot.offsetWidth;
          cartDot.style.background = "var(--c-600)";
          cartDot.style.transform = "scale(1.6)";
          setTimeout(() => {
            cartDot.style.transform = "scale(1)";
          }, 300);
        }
      });

      // ---------- header shadow ----------
      const header = document.querySelector(".site-header");
      window.addEventListener(
        "scroll",
        () => {
          if (header) {
            header.style.boxShadow =
              window.scrollY > 20
                ? "0 8px 24px -18px rgba(53,29,21,0.35)"
                : "none";
          }
        },
        { passive: true },
      );

      // set default date to tomorrow
      const dateInput = document.getElementById("visitDate");
      if (dateInput) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const year = tomorrow.getFullYear();
        const month = String(tomorrow.getMonth() + 1).padStart(2, "0");
        const day = String(tomorrow.getDate()).padStart(2, "0");
        dateInput.value = `${year}-${month}-${day}`;
      }
    })();
  </script>
</body>

</html>
