<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — care guide</title>
  <meta name="description"
    content="learn how to care for your handmade pots, candles, and décor from the little green house studio." />
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🌿</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1180px;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
      letter-spacing: 0.01em;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    ul {
      list-style: none;
    }

    img {
      display: block;
      max-width: 100%;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 9999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    .reveal {
      opacity: 0;
      transform: translateY(24px);
      transition:
        opacity 0.8s var(--ease-hand),
        transform 0.8s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 14px 26px;
      border-radius: 100px;
      font-size: 0.9rem;
      font-weight: 500;
      letter-spacing: 0.02em;
      white-space: nowrap;
      transition: all 0.3s var(--ease-hand);
      min-height: 44px;
      touch-action: manipulation;
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      background: var(--c-900);
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
    }

    .btn-outline {
      border: 1.5px solid var(--c-700);
      color: var(--ink);
      background: transparent;
    }

    .btn-outline:hover {
      background: var(--c-800);
      color: var(--c-50);
      border-color: var(--c-800);
      transform: translateY(-3px);
    }

    /* header */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 600;
      background: rgba(251, 247, 241, 0.86);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 80px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.35rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
      transition: color 0.3s;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active {
      color: var(--ink);
    }

    .main-nav a.is-active::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s,
        color 0.3s;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .profile-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: var(--c-600);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition: 0.3s;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* care hero */
    .care-hero {
      padding: 60px 0 30px;
      text-align: center;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .care-hero h1 {
      font-size: clamp(2rem, 4vw, 3rem);
      line-height: 1.1;
      margin-bottom: 10px;
    }

    .care-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .care-hero p {
      color: var(--muted);
      font-size: 1.1rem;
      max-width: 600px;
      margin: 0 auto;
    }

    /* care main */
    .care-main {
      padding: 50px 0 80px;
    }

    .care-layout {
      display: grid;
      grid-template-columns: 250px 1fr;
      gap: 40px;
      align-items: start;
    }

    /* sidebar */
    .care-nav {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      overflow: hidden;
      position: sticky;
      top: 100px;
    }

    .care-nav a {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 16px 20px;
      font-size: 0.9rem;
      font-weight: 500;
      color: var(--ink-soft);
      transition: 0.2s;
      border-bottom: 1px solid var(--line);
    }

    .care-nav a:last-child {
      border-bottom: none;
    }

    .care-nav a:hover {
      background: var(--surface-2);
      color: var(--ink);
    }

    .care-nav a.active {
      background: var(--c-100);
      color: var(--c-700);
      border-left: 3px solid var(--c-600);
    }

    .care-nav a svg {
      width: 18px;
      height: 18px;
      flex-shrink: 0;
    }

    /* care content */
    .care-section {
      margin-bottom: 40px;
    }

    .care-section:last-child {
      margin-bottom: 0;
    }

    .care-card {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      padding: 28px;
      margin-bottom: 24px;
    }

    .care-card h2 {
      font-size: 1.5rem;
      margin-bottom: 16px;
      font-family: var(--font-display);
    }

    .care-card h3 {
      font-size: 1.1rem;
      margin: 20px 0 10px;
    }

    .care-card p {
      color: var(--muted);
      font-size: 0.95rem;
      line-height: 1.7;
      margin-bottom: 12px;
    }

    .care-card ul {
      margin-bottom: 12px;
      padding-left: 20px;
    }

    .care-card ul li {
      color: var(--muted);
      font-size: 0.95rem;
      line-height: 1.7;
      margin-bottom: 8px;
      list-style: disc;
    }

    .care-card .highlight {
      background: var(--surface-2);
      border-left: 3px solid var(--c-600);
      padding: 16px 20px;
      border-radius: var(--radius-sm);
      margin: 16px 0;
    }

    .care-card .highlight p {
      color: var(--ink-soft);
      margin-bottom: 0;
    }

    /* info boxes */
    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin: 20px 0;
    }

    .info-box {
      text-align: center;
      padding: 20px;
      background: var(--surface-2);
      border-radius: var(--radius-sm);
    }

    .info-box .icon {
      font-size: 2rem;
      margin-bottom: 8px;
    }

    .info-box h4 {
      font-size: 0.95rem;
      margin-bottom: 4px;
    }

    .info-box p {
      font-size: 0.8rem;
      color: var(--muted);
      margin-bottom: 0;
    }

    /* tip cards */
    .tip-card {
      display: flex;
      gap: 16px;
      padding: 16px;
      background: var(--surface-2);
      border-radius: var(--radius-sm);
      margin-bottom: 12px;
      align-items: flex-start;
    }

    .tip-icon {
      font-size: 1.5rem;
      flex-shrink: 0;
    }

    .tip-content h4 {
      font-size: 0.95rem;
      margin-bottom: 4px;
    }

    .tip-content p {
      font-size: 0.85rem;
      color: var(--muted);
      margin-bottom: 0;
    }

    /* contact section */
    .contact-care {
      text-align: center;
      padding: 40px 20px;
      background: var(--surface-2);
      border-radius: var(--radius-lg);
      margin-top: 40px;
    }

    .contact-care h3 {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }

    .contact-care p {
      color: var(--muted);
      margin-bottom: 20px;
    }

    .contact-actions {
      display: flex;
      gap: 12px;
      justify-content: center;
      flex-wrap: wrap;
    }

    /* footer */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 70px 0 0;
      margin-top: 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.8fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 50px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand p {
      margin: 14px 0 20px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 12px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      transition: 0.3s;
    }

    .socials a:hover {
      background: var(--c-600);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 16px;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.2s;
    }

    .footer-col a:hover {
      color: white;
    }

    .footer-bottom {
      padding: 24px 0;
      text-align: center;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
    }

    /* responsive */
    @media (max-width: 1024px) {
      .care-layout {
        grid-template-columns: 1fr;
      }

      .care-nav {
        position: static;
        display: flex;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
      }

      .care-nav a {
        min-width: 140px;
        border-bottom: none;
        border-right: 1px solid var(--line);
        flex-shrink: 0;
      }

      .care-nav a.active {
        border-left: none;
        border-bottom: 3px solid var(--c-600);
      }

      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 16px;
      }

      .header-inner {
        height: 64px;
      }

      .logo-text {
        font-size: 1.1rem;
      }

      .main-nav {
        position: fixed;
        top: 64px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 16px 28px 28px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition: 0.4s var(--ease-hand);
        z-index: 500;
        max-height: calc(100vh - 64px);
        overflow-y: auto;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 16px 0;
        border-bottom: 1px solid var(--line);
        font-size: 1rem;
      }

      .menu-toggle {
        display: flex;
      }

      .profile-avatar {
        width: 32px;
        height: 32px;
        font-size: 0.8rem;
      }

      .care-hero {
        padding: 40px 0 20px;
      }

      .care-hero h1 {
        font-size: 1.8rem;
      }

      .care-hero p {
        font-size: 1rem;
      }

      .care-main {
        padding: 30px 0 60px;
      }

      .care-card {
        padding: 20px 16px;
      }

      .care-card h2 {
        font-size: 1.2rem;
      }

      .care-card h3 {
        font-size: 1rem;
      }

      .info-grid {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 12px;
      }

      .tip-card {
        flex-direction: column;
        gap: 8px;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 30px;
        padding-bottom: 30px;
      }

      .site-footer {
        padding: 50px 0 0;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <link rel="canonical" href="https://thelittlegreenhouse.in/care-guide/" />
  <meta property="og:title" content="the little green house — care guide" />
  <meta property="og:description" content="learn how to care for your handmade pots, candles, and d&#233;cor from the little green house studio." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/care-guide/" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
  <a class="skip-link" href="#main">skip to care guide</a>
  <div class="grain" aria-hidden="true"></div>

  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo" aria-label="the little green house home">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="30" height="30">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products"><svg width="19" height="19" viewBox="0 0 24 24"
            fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg></a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="menu" aria-expanded="false" aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <section class="care-hero">
      <div class="wrap">
        <h1>caring for <em>your pieces</em></h1>
        <p>
          a little love goes a long way — here's how to keep your handmade
          items beautiful for years.
        </p>
      </div>
    </section>

    <section class="care-main">
      <div class="wrap">
        <div class="care-layout">
          <!-- sidebar navigation -->
          <nav class="care-nav" aria-label="care guide sections">
            <a href="#terracotta" class="active">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <path
                  d="M12 3c-4 0-7 3-7 7v6c0 2 1.5 4 3.5 4.5L7 21h10l-1.5-.5c2-0.5 3.5-2.5 3.5-4.5v-6c0-4-3-7-7-7z" />
              </svg>
              terracotta pots
            </a>
            <a href="#candles">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <path d="M12 2v4M12 8v6M12 16v6M8 2h8v4l-2 3v6l2 3v4H8v-4l2-3v-6L8 6V2z" />
              </svg>
              candle care
            </a>
            <a href="#incense">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <path d="M12 2c-2 2-3 4-3 7s1 5 3 7 3 4 3 7M12 2c2 2 3 4 3 7s-1 5-3 7-3 4-3 7" />
              </svg>
              incense holders
            </a>
            <a href="#plants">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <path d="M12 22c4 0 8-3 8-8V4h-8c-4 0-8 3-8 8s3 8 8 8z" />
                <path d="M12 14c2 0 3-1 3-3s-1-3-3-3-3 1-3 3 1 3 3 3z" />
              </svg>
              plants in pots
            </a>
            <a href="#decor">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <rect x="3" y="3" width="18" height="18" rx="3" />
                <path d="M12 8v8M8 12h8" />
              </svg>
              home décor
            </a>
            <a href="#storage">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <path d="M4 7h16v14H4zM4 7V4h16v3M9 11h6" />
              </svg>
              storage tips
            </a>
          </nav>

          <!-- care content -->
          <div class="care-content">
            <!-- terracotta section -->
            <section class="care-section" id="terracotta">
              <div class="care-card">
                <h2>terracotta & clay pots</h2>
                <p>
                  terracotta is a living material that breathes and ages
                  beautifully. with proper care, your pot will develop a
                  unique patina over time.
                </p>

                <div class="info-grid">
                  <div class="info-box">
                    <div class="icon">💧</div>
                    <h4>cleaning</h4>
                    <p>warm water & soft brush</p>
                  </div>
                  <div class="info-box">
                    <div class="icon">🚫</div>
                    <h4>avoid</h4>
                    <p>harsh chemicals & soaking</p>
                  </div>
                  <div class="info-box">
                    <div class="icon">🌡️</div>
                    <h4>temperature</h4>
                    <p>protect from frost</p>
                  </div>
                  <div class="info-box">
                    <div class="icon">✨</div>
                    <h4>refresh</h4>
                    <p>mineral oil occasionally</p>
                  </div>
                </div>

                <h3>cleaning your pot</h3>
                <ul>
                  <li>empty the pot and remove any loose soil</li>
                  <li>
                    rinse with warm water and scrub gently with a soft brush
                  </li>
                  <li>
                    avoid soap or detergent — terracotta is porous and can
                    absorb chemicals
                  </li>
                  <li>allow to dry completely before replanting</li>
                </ul>

                <h3>seasonal care</h3>
                <p>
                  terracotta can crack in freezing temperatures. if you live
                  in a cold climate, bring your pots indoors during winter or
                  wrap them in burlap for protection.
                </p>

                <div class="highlight">
                  <p>
                    <strong>pro tip:</strong> to refresh the natural sheen of
                    your terracotta pot, rub a small amount of food-grade
                    mineral oil into the surface with a soft cloth. this also
                    helps prevent water stains.
                  </p>
                </div>
              </div>
            </section>

            <!-- candle section -->
            <section class="care-section" id="candles">
              <div class="care-card">
                <h2>candle care</h2>
                <p>
                  our candles are made with 100% soy wax and cotton wicks for
                  a clean, even burn. follow these tips for the best
                  experience.
                </p>

                <h3>first burn matters</h3>
                <p>
                  when you first light your candle, allow the wax to melt all
                  the way to the edges of the container. this prevents
                  "tunneling" and ensures an even burn for the life of the
                  candle.
                </p>

                <div class="tip-card">
                  <div class="tip-icon">✂️</div>
                  <div class="tip-content">
                    <h4>trim the wick</h4>
                    <p>
                      before each burn, trim the wick to about 1/4 inch. this
                      prevents smoking and ensures a clean flame.
                    </p>
                  </div>
                </div>

                <div class="tip-card">
                  <div class="tip-icon">⏰</div>
                  <div class="tip-content">
                    <h4>burn time</h4>
                    <p>
                      burn your candle for 2-4 hours at a time. this allows
                      the wax to melt evenly and prevents the wick from
                      drowning.
                    </p>
                  </div>
                </div>

                <div class="tip-card">
                  <div class="tip-icon">🔥</div>
                  <div class="tip-content">
                    <h4>safety first</h4>
                    <p>
                      never leave a burning candle unattended. keep away from
                      drafts, children, and pets. stop use when 1/2 inch of
                      wax remains.
                    </p>
                  </div>
                </div>

                <div class="highlight">
                  <p>
                    <strong>storage tip:</strong> store candles in a cool, dry
                    place away from direct sunlight. soy wax can soften in
                    high heat, so avoid leaving candles in hot cars or near
                    radiators.
                  </p>
                </div>
              </div>
            </section>

            <!-- incense section -->
            <section class="care-section" id="incense">
              <div class="care-card">
                <h2>incense holders</h2>
                <p>
                  our handmade incense holders are designed to catch ash and
                  protect your surfaces. with minimal care, they'll last for
                  years.
                </p>

                <h3>cleaning</h3>
                <ul>
                  <li>empty ash after each use</li>
                  <li>wipe with a dry or slightly damp cloth</li>
                  <li>
                    for stubborn residue, use a soft brush with warm water
                  </li>
                  <li>dry thoroughly before next use</li>
                </ul>

                <h3>placement</h3>
                <p>
                  place your incense holder on a heat-resistant surface away
                  from flammable materials. ensure proper ventilation when
                  burning incense.
                </p>
              </div>
            </section>

            <!-- plants section -->
            <section class="care-section" id="plants">
              <div class="care-card">
                <h2>plants in our pots</h2>
                <p>
                  our pots are designed to promote healthy plant growth.
                  here's how to keep both your plant and pot happy.
                </p>

                <h3>watering</h3>
                <p>
                  terracotta is porous and wicks moisture away from the soil.
                  this means you may need to water plants in terracotta pots
                  slightly more often than those in plastic or glazed
                  containers.
                </p>

                <h3>drainage</h3>
                <p>
                  all our pots include a drainage hole. always use a saucer
                  underneath to catch excess water and prevent staining on
                  your surfaces.
                </p>

                <div class="highlight">
                  <p>
                    <strong>repotting:</strong> if roots start growing through
                    the drainage hole or the plant becomes top-heavy, it's
                    time to repot. choose a pot one size larger for best
                    results.
                  </p>
                </div>
              </div>
            </section>

            <!-- decor section -->
            <section class="care-section" id="decor">
              <div class="care-card">
                <h2>home décor</h2>
                <p>
                  our decorative pieces are crafted to be enjoyed daily. with
                  simple care, they'll maintain their beauty for years.
                </p>

                <h3>general care</h3>
                <ul>
                  <li>dust regularly with a soft, dry cloth</li>
                  <li>avoid direct sunlight which can fade natural dyes</li>
                  <li>keep away from extreme humidity</li>
                  <li>handle with care — handmade pieces can be delicate</li>
                </ul>

                <h3>display tips</h3>
                <p>
                  group pieces together for visual impact. natural materials
                  look beautiful when mixed with plants and textiles. rotate
                  pieces seasonally to refresh your space.
                </p>
              </div>
            </section>

            <!-- storage section -->
            <section class="care-section" id="storage">
              <div class="care-card">
                <h2>storage tips</h2>
                <p>
                  whether you're storing pieces for a season or just tidying
                  up, proper storage ensures your handmade items stay in great
                  condition.
                </p>

                <div class="tip-card">
                  <div class="tip-icon">📦</div>
                  <div class="tip-content">
                    <h4>wrap individually</h4>
                    <p>
                      use tissue paper or bubble wrap to protect pieces from
                      scratching each other.
                    </p>
                  </div>
                </div>

                <div class="tip-card">
                  <div class="tip-icon">🌡️</div>
                  <div class="tip-content">
                    <h4>climate control</h4>
                    <p>
                      store in a cool, dry place. avoid attics or basements
                      where temperature fluctuations can cause damage.
                    </p>
                  </div>
                </div>

                <div class="tip-card">
                  <div class="tip-icon">📝</div>
                  <div class="tip-content">
                    <h4>label boxes</h4>
                    <p>
                      clearly label storage boxes so you can find what you
                      need without digging through everything.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            <!-- contact section -->
            <div class="contact-care">
              <h3>need specific advice?</h3>
              <p>
                every piece is unique. if you have questions about caring for
                a specific item, we're here to help.
              </p>
              <div class="contact-actions">
                <a href="mailto:hello@thelittlegreenhouse.com" class="btn btn-primary">email us</a>
                <a href="#faq" class="btn btn-outline">view faq</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>handmade pots, candles & home décor — made slowly, on purpose.</p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    (function () {
      // smooth scroll for care nav
      const careLinks = document.querySelectorAll(".care-nav a");

      careLinks.forEach((link) => {
        link.addEventListener("click", (e) => {
          e.preventDefault();
          const targetId = link.getAttribute("href").substring(1);
          const targetElement = document.getElementById(targetId);

          if (targetElement) {
            careLinks.forEach((l) => l.classList.remove("active"));
            link.classList.add("active");

            targetElement.scrollIntoView({
              behavior: "smooth",
              block: "start",
            });
          }
        });
      });

      // highlight active section on scroll
      const sections = document.querySelectorAll(".care-section");

      function updateActiveLink() {
        let currentSection = "";
        sections.forEach((section) => {
          const sectionTop = section.offsetTop - 100;
          if (window.scrollY >= sectionTop) {
            currentSection = section.id;
          }
        });

        careLinks.forEach((link) => {
          link.classList.remove("active");
          if (link.getAttribute("href") === `#${currentSection}`) {
            link.classList.add("active");
          }
        });
      }

      window.addEventListener("scroll", updateActiveLink, { passive: true });

      // menu toggle
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) =>
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }),
        );
      }

      // close mobile nav on outside click
      document.addEventListener("click", (e) => {
        if (mainNav && mainNav.classList.contains("is-open")) {
          if (
            !e.target.closest(".main-nav") &&
            !e.target.closest(".menu-toggle")
          ) {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }
        }
      });

      // header shadow
      const header = document.querySelector(".site-header");
      window.addEventListener(
        "scroll",
        () => {
          header.style.boxShadow =
            window.scrollY > 20
              ? "0 8px 24px -18px rgba(53,29,21,0.35)"
              : "none";
        },
        { passive: true },
      );

      // scroll reveal
      const revealObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              revealObserver.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.1 },
      );

      document
        .querySelectorAll(".reveal")
        .forEach((el) => revealObserver.observe(el));
    })();
  </script>
</body>

</html>