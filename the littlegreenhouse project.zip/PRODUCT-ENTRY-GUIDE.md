# Product entry guide

Use **Admin → Products → Add product** to create a catalog item. Product records and inventory belong in this store's database; Shiprocket/Fastrr receive the catalog or checkout data through the existing integration. Do not create a duplicate product in Shiprocket to make the product page or cart work.

## Required values

- **Product name**: shopper-facing name.
- **Category**: choose an existing active category.
- **SKU code**: unique stock keeping code.
- **Price (₹)**: selling price, greater than zero.
- **Online stock quantity**: units available for the online checkout. The product page and API refuse checkout when this is zero.
- **In-store stock quantity**: units reserved for store sales.
- **Weight in grams**: packed/shipping weight used by the shipping integration.

## Optional values

- **Compare price (₹)**: original price, if the item is on sale.
- **Dimensions**: customer-facing size, for example `15 cm H × 14 cm W`.
- **Tag / badge**: short label such as `Handcrafted`.
- **Description**: materials, craft details and care notes. Keep it accurate and useful to shoppers.

## Product photos and videos

Select one or more media files in the product form. The first uploaded image becomes the primary catalog image if the product does not already have one. Additional uploads are appended to the product detail gallery. Video files remain gallery media and are not used as the checkout/catalog thumbnail.

- Images accepted: JPEG, PNG, WebP and GIF; up to 10 MB each; maximum 10,000 pixels per side.
- Videos accepted: MP4 and WebM; up to 50 MB each.
- Maximum: 12 files per save/upload. Choose optimized, clear product media with permission to publish it.
- The hosting account must permit PHP uploads and have enough space. For the maximum supported video upload, set `upload_max_filesize` to at least `50M`, `post_max_size` to at least `65M`, and `max_file_uploads` to at least `12` in cPanel's PHP INI settings.

## After saving

1. Open the public product page and confirm price, stock, photos/video and product URL.
2. Add the item to the cart and verify its quantity and subtotal.
3. Use Buy Now or the cart checkout only when ready to place a real order. Fastrr checkout and its order confirmation flow are unchanged by product media uploads.
4. Confirm a successfully verified order appears in Admin → Orders. Only verified Fastrr completion or a completed manual/admin order creates a dashboard order.
