<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Track your order | The Little Green House</title>
    <meta name="description" content="Check the payment and delivery status of your order from The Little Green House.">
    <link rel="canonical" href="https://thelittlegreenhouse.in/order/">
    <link rel="stylesheet" href="../styles.css">
    <style>
        main {
            max-width: 720px;
            margin: 8vh auto;
            padding: 24px
        }

        form {
            display: grid;
            gap: 14px
        }

        input {
            padding: 14px;
            border: 1px solid #c9c0b3;
            border-radius: 8px;
            font: inherit
        }

        .result {
            margin-top: 24px;
            padding: 20px;
            background: #f5ecdf;
            border-radius: 12px;
            line-height: 1.8
        }
    </style>
  <meta name="robots" content="noindex, nofollow" />
</head>

<body>
    <main><a href="../">← home</a>
        <h1>Track your order</h1>
        <p>Enter the order number from your confirmation and the email used at checkout.</p>
        <form id="track"><label>Order number<input name="order_number" required autocomplete="off"
                    placeholder="TLGH-20260924-ABCD"></label><label>Order email<input type="email" name="email" required
                    autocomplete="email"></label><button class="btn btn-primary">find my order</button></form>
        <div id="result" role="status" aria-live="polite"></div>
        <p>Need help? <a href="../support/">Contact customer support</a>.</p>
    </main>
    <script>document.getElementById('track').addEventListener('submit', async e => { e.preventDefault(); const f = new FormData(e.currentTarget), box = document.getElementById('result'); box.className = 'result'; box.textContent = 'Looking up your order…'; try { const q = new URLSearchParams({ order_number: f.get('order_number').trim(), email: f.get('email').trim() }); const r = await fetch('../api/orders/track?' + q); const d = await r.json(); if (!r.ok) throw Error(d.error || 'Order lookup failed'); const o = d.order; box.replaceChildren(); const rows = [['Order', o.order_number], ['Order status', (o.order_status || '').replaceAll('_', ' ')], ['Payment', (o.payment_status || '').replaceAll('_', ' ')], ['Courier', o.courier_name || 'Not assigned yet'], ['Shipment status', o.shiprocket_status || 'Awaiting dispatch']]; for (const [k, v] of rows) { const p = document.createElement('p'); p.textContent = k + ': ' + v; box.append(p) } if (o.tracking_url) { const a = document.createElement('a'); a.href = o.tracking_url; a.textContent = 'Track with Shiprocket'; a.rel = 'noopener'; a.target = '_blank'; box.append(a) } } catch (err) { box.textContent = err.message } })</script>
</body>

</html>