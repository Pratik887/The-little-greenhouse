<?php
$appConfig = require __DIR__ . '/api/config/config.php';
$canonicalBase = rtrim((string) ($appConfig['app']['url'] ?? ''), '/');
$canonicalParts = parse_url($canonicalBase);
$requestHost = (string) (parse_url('//' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST) ?: '');
$canonicalHost = (string) ($canonicalParts['host'] ?? '');
$requestScheme = strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO']
    ?? ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http')));
$canonicalScheme = strtolower((string) ($canonicalParts['scheme'] ?? 'https'));
if ($canonicalBase !== '' && $canonicalHost !== ''
    && (strcasecmp($requestHost, $canonicalHost) !== 0 || $requestScheme !== $canonicalScheme)) {
    $returnQuery = array_intersect_key($_GET, array_flip(['ref', 'oid', 'order_id']));
    $returnUrl = $canonicalBase . '/fastrr-return.php';
    if ($returnQuery) {
        $returnUrl .= '?' . http_build_query($returnQuery);
    }
    header('Location: ' . $returnUrl, true, 302);
    exit;
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Confirming your order | The Little Green House</title>
    <meta name="description" content="Securely verifying your Little Green House checkout with Shiprocket Fastrr." />
    <meta name="robots" content="noindex, nofollow">
    <link rel="stylesheet" href="styles.css">
    <style>
        main {
            max-width: 680px;
            margin: 12vh auto;
            padding: 28px
        }
    </style>
</head>

<body>
    <main><a href="./">The Little Green House</a>
        <h1>Confirming your order</h1>
        <p id="message" role="status" aria-live="polite">Checking the payment securely with Shiprocket Fastrr…</p>
        <p id="number"></p><a id="track" href="order/" hidden>track this order</a>
        <script src="cart.js"></script>
        <script>
            (async () => {
                const q = new URLSearchParams(location.search);
                const ref = q.get('ref');
                const orderId = q.get('oid') || q.get('order_id');
                const message = document.getElementById('message');
                if (!ref || !orderId) {
                    message.textContent = 'We could not find this checkout session. If payment was taken, please contact support with your payment reference.';
                    return;
                }
                // Determine API path relative to the current site root
                const basePath = window.location.pathname.replace(/\/fastrr-return\.php.*$/, '').replace(/\/$/, '');
                const apiEndpoint = (basePath ? basePath : '') + '/api/fastrr/verify';

                try {
                    const r = await fetch(apiEndpoint, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                        body: JSON.stringify({ ref, order_id: orderId })
                    });
                    const d = await r.json();
                    if (!r.ok) throw new Error(d.error || 'Order verification is pending');
                    
                    message.textContent = d.order.payment_status === 'PAID'
                        ? 'Payment confirmed. Thank you for your order!'
                        : 'Order confirmed. Payment will be collected on delivery.';
                    document.getElementById('number').textContent = 'Order number: ' + d.order.order_number;
                    document.getElementById('track').hidden = false;
                    try {
                        if (window.TLGHCart) window.TLGHCart.clear();
                        localStorage.removeItem('tlgh_cart');
                        localStorage.removeItem('tlgh_cart_count');
                    } catch (_) {}
                } catch (e) {
                    message.textContent = e.message + ' You can retry order confirmation or contact support.';
                }
            })();
        </script>
    </main>
</body>

</html>
