<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — my favourites</title>
  <meta name="description"
    content="your saved favourites from the little green house – handmade pots, candles, and décor you love." />
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>❤️</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1180px;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
      letter-spacing: 0.01em;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    ul {
      list-style: none;
    }

    img {
      display: block;
      max-width: 100%;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 9999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    .reveal {
      opacity: 0;
      transform: translateY(24px);
      transition:
        opacity 0.8s var(--ease-hand),
        transform 0.8s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 14px 26px;
      border-radius: 100px;
      font-size: 0.9rem;
      font-weight: 500;
      letter-spacing: 0.02em;
      white-space: nowrap;
      transition: all 0.3s var(--ease-hand);
      min-height: 44px;
      touch-action: manipulation;
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      background: var(--c-900);
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
    }

    .btn-outline {
      border: 1.5px solid var(--c-700);
      color: var(--ink);
      background: transparent;
    }

    .btn-outline:hover {
      background: var(--c-800);
      color: var(--c-50);
      border-color: var(--c-800);
      transform: translateY(-3px);
    }

    /* header */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 600;
      background: rgba(251, 247, 241, 0.86);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 80px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.35rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
      transition: color 0.3s;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active {
      color: var(--ink);
    }

    .main-nav a.is-active::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s,
        color 0.3s;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .profile-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: var(--c-600);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition: 0.3s;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* favourites hero */
    .favourites-hero {
      padding: 50px 0 30px;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .favourites-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 16px;
    }

    .favourites-title h1 {
      font-size: clamp(2rem, 4vw, 3rem);
      line-height: 1.1;
      margin-bottom: 8px;
    }

    .favourites-title h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .favourites-title p {
      color: var(--muted);
      font-size: 1rem;
    }

    .favourites-count {
      background: var(--c-600);
      color: white;
      padding: 8px 20px;
      border-radius: 50px;
      font-size: 0.9rem;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .favourites-count svg {
      width: 18px;
      height: 18px;
    }

    /* favourites main */
    .favourites-main {
      padding: 40px 0 80px;
    }

    /* filter bar */
    .filter-bar {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      margin-bottom: 30px;
    }

    .filter-btn {
      padding: 10px 22px;
      border-radius: 50px;
      background: transparent;
      border: 1px solid var(--c-300);
      color: var(--c-800);
      font-size: 0.85rem;
      transition: 0.2s;
      letter-spacing: 0.03em;
      min-height: 40px;
    }

    .filter-btn:hover {
      border-color: var(--c-600);
      color: var(--c-600);
    }

    .filter-btn.active {
      background: var(--ink);
      color: var(--c-100);
      border-color: var(--ink);
    }

    /* product grid */
    .favourites-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
      gap: 24px;
    }

    .favourite-card {
      background: var(--surface);
      border-radius: var(--radius-md);
      overflow: hidden;
      border: 1px solid var(--line);
      transition:
        transform 0.35s var(--ease-hand),
        box-shadow 0.35s;
      display: flex;
      flex-direction: column;
      position: relative;
    }

    .favourite-card:hover {
      transform: translateY(-8px);
      box-shadow: var(--shadow-lift);
    }

    .favourite-media {
      position: relative;
      width: 100%;
      aspect-ratio: 4/3;
      background: var(--surface-2);
      overflow: hidden;
    }

    .favourite-media img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.6s var(--ease-hand);
    }

    .favourite-card:hover .favourite-media img {
      transform: scale(1.04);
    }

    .remove-favourite {
      position: absolute;
      top: 12px;
      right: 12px;
      width: 36px;
      height: 36px;
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(4px);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: 0.2s;
      color: #e74c3c;
      z-index: 2;
    }

    .remove-favourite:hover {
      transform: scale(1.15);
      background: #e74c3c;
      color: white;
    }

    .badge {
      position: absolute;
      top: 12px;
      left: 12px;
      background: var(--c-600);
      color: white;
      padding: 4px 12px;
      border-radius: 30px;
      font-size: 0.7rem;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      z-index: 2;
    }

    .favourite-info {
      padding: 18px 18px 20px;
      flex: 1;
      display: flex;
      flex-direction: column;
    }

    .favourite-category {
      font-size: 0.7rem;
      letter-spacing: 0.08em;
      color: var(--c-600);
      text-transform: uppercase;
      margin-bottom: 6px;
    }

    .favourite-title {
      font-family: var(--font-display);
      font-size: 1.2rem;
      font-weight: 500;
      margin-bottom: 4px;
    }

    .favourite-price {
      font-size: 1.1rem;
      font-weight: 500;
      color: var(--c-700);
      margin-bottom: 14px;
    }

    .favourite-actions {
      margin-top: auto;
      display: flex;
      gap: 10px;
    }

    .add-to-cart-btn {
      flex: 1;
      background: var(--ink);
      color: var(--c-100);
      border-radius: 30px;
      padding: 10px 16px;
      font-size: 0.85rem;
      transition: 0.2s;
      min-height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }

    .add-to-cart-btn:hover {
      background: var(--c-700);
    }

    .added-to-cart {
      background: #4caf50 !important;
    }

    /* empty state */
    .empty-favourites {
      text-align: center;
      padding: 60px 20px;
      background: var(--surface);
      border: 2px dashed var(--line);
      border-radius: var(--radius-lg);
    }

    .empty-favourites svg {
      margin: 0 auto 20px;
      color: var(--c-400);
    }

    .empty-favourites h3 {
      font-size: 1.5rem;
      margin-bottom: 10px;
      font-family: var(--font-display);
    }

    .empty-favourites p {
      color: var(--muted);
      margin-bottom: 24px;
    }

    /* footer */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 70px 0 0;
      margin-top: 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.8fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 50px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand p {
      margin: 14px 0 20px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 12px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      transition: 0.3s;
    }

    .socials a:hover {
      background: var(--c-600);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 16px;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.2s;
    }

    .footer-col a:hover {
      color: white;
    }

    .footer-bottom {
      padding: 24px 0;
      text-align: center;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
    }

    /* toast notification */
    .toast {
      position: fixed;
      bottom: 30px;
      right: 30px;
      background: var(--ink);
      color: var(--c-100);
      padding: 16px 24px;
      border-radius: var(--radius-sm);
      font-size: 0.9rem;
      box-shadow: var(--shadow-lift);
      z-index: 3000;
      transform: translateY(100px);
      opacity: 0;
      transition:
        transform 0.4s var(--ease-hand),
        opacity 0.4s;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .toast.show {
      transform: translateY(0);
      opacity: 1;
    }

    .toast svg {
      width: 18px;
      height: 18px;
    }

    /* responsive */
    @media (max-width: 1024px) {
      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 16px;
      }

      .header-inner {
        height: 64px;
      }

      .logo-text {
        font-size: 1.1rem;
      }

      .main-nav {
        position: fixed;
        top: 64px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 16px 28px 28px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition: 0.4s var(--ease-hand);
        z-index: 500;
        max-height: calc(100vh - 64px);
        overflow-y: auto;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 16px 0;
        border-bottom: 1px solid var(--line);
        font-size: 1rem;
      }

      .menu-toggle {
        display: flex;
      }

      .profile-avatar {
        width: 32px;
        height: 32px;
        font-size: 0.8rem;
      }

      .favourites-hero {
        padding: 30px 0 20px;
      }

      .favourites-title h1 {
        font-size: 1.8rem;
      }

      .favourites-title p {
        font-size: 0.9rem;
      }

      .favourites-count {
        padding: 6px 14px;
        font-size: 0.8rem;
      }

      .favourites-main {
        padding: 24px 0 60px;
      }

      .favourites-grid {
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 16px;
      }

      .favourite-info {
        padding: 12px 12px 16px;
      }

      .favourite-title {
        font-size: 1rem;
      }

      .favourite-price {
        font-size: 0.95rem;
      }

      .add-to-cart-btn {
        padding: 8px 12px;
        font-size: 0.75rem;
        min-height: 36px;
      }

      .filter-btn {
        padding: 8px 16px;
        font-size: 0.75rem;
        min-height: 36px;
      }

      .toast {
        bottom: 20px;
        right: 20px;
        left: 20px;
        text-align: center;
        justify-content: center;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 30px;
        padding-bottom: 30px;
      }

      .site-footer {
        padding: 50px 0 0;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <meta name="robots" content="noindex, nofollow" />
</head>

<body>
  <a class="skip-link" href="#main">skip to favourites</a>
  <div class="grain" aria-hidden="true"></div>

  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo" aria-label="the little green house home">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="30" height="30">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products"><svg width="19" height="19" viewBox="0 0 24 24"
            fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg></a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="menu" aria-expanded="false" aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <!-- favourites hero -->
    <section class="favourites-hero">
      <div class="wrap">
        <div class="favourites-header">
          <div class="favourites-title">
            <h1>my <em>favourites</em></h1>
            <p>pieces you've saved for later — ready when you are.</p>
          </div>
          <div class="favourites-count">
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path
                d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z" />
            </svg>
            <span id="favouriteCount">0 items</span>
          </div>
        </div>
      </div>
    </section>

    <section class="favourites-main">
      <div class="wrap">
        <!-- filter bar -->
        <div class="filter-bar" id="filterBar">
          <button class="filter-btn active" data-filter="all">
            all items
          </button>
          <button class="filter-btn" data-filter="pots">
            pots & planters
          </button>
          <button class="filter-btn" data-filter="candles">candles</button>
          <button class="filter-btn" data-filter="decor">home décor</button>
          <button class="filter-btn" data-filter="plants">plants</button>
        </div>

        <!-- favourites grid -->
        <div class="favourites-grid" id="favouritesGrid">
          <!-- dynamically populated -->
        </div>

        <!-- empty state (hidden by default) -->
        <div class="empty-favourites" id="emptyState" style="display: none">
          <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2">
            <path
              d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z" />
          </svg>
          <h3>no favourites yet</h3>
          <p>tap the heart icon on any product to save it here for later.</p>
          <a href="../shop/" class="btn btn-primary">browse the shop</a>
        </div>
      </div>
    </section>
  </main>

  <!-- toast notification -->
  <div class="toast" id="toast">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M20 6L9 17l-5-5" />
    </svg>
    <span id="toastMessage">added to cart</span>
  </div>

  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>handmade pots, candles & home décor — made slowly, on purpose.</p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    (function () {
      // favourites data (simulated)
      let favourites = [
        {
          id: 1,
          title: "terracotta clay pot",
          category: "pots",
          price: "₹2,400",
          img: "https://placehold.co/600x450/E5CDAE/633B2B?text=terracotta+pot",
          badge: "bestseller",
        },
        {
          id: 3,
          title: "vanilla smoke candle",
          category: "candles",
          price: "₹1,200",
          img: "https://placehold.co/600x450/C3804C/F5ECDF?text=vanilla+candle",
          badge: "new",
        },
        {
          id: 5,
          title: "terracotta incense holder",
          category: "decor",
          price: "₹950",
          img: "https://placehold.co/600x450/CE9969/633B2B?text=incense+holder",
          badge: "",
        },
        {
          id: 7,
          title: "jade in clay",
          category: "plants",
          price: "₹1,600",
          img: "https://placehold.co/600x450/638A55/F5ECDF?text=jade+plant",
          badge: "green",
        },
        {
          id: 6,
          title: "speckled bowl pot",
          category: "pots",
          price: "₹2,100",
          img: "https://placehold.co/600x450/C3804C/F5ECDF?text=speckled+pot",
          badge: "",
        },
        {
          id: 4,
          title: "sandalwood + moss",
          category: "candles",
          price: "₹1,350",
          img: "https://placehold.co/600x450/7A4632/E5CDAE?text=sandalwood+candle",
          badge: "",
        },
      ];

      let activeFilter = "all";
      const grid = document.getElementById("favouritesGrid");
      const emptyState = document.getElementById("emptyState");
      const filterBar = document.getElementById("filterBar");
      const favouriteCount = document.getElementById("favouriteCount");

      function updateFavouriteCount() {
        favouriteCount.textContent = `${favourites.length} ${favourites.length === 1 ? "item" : "items"}`;
      }

      function showToast(message) {
        const toast = document.getElementById("toast");
        const toastMessage = document.getElementById("toastMessage");
        toastMessage.textContent = message;
        toast.classList.add("show");
        setTimeout(() => {
          toast.classList.remove("show");
        }, 2500);
      }

      function renderFavourites(filter) {
        const filtered =
          filter === "all"
            ? favourites
            : favourites.filter((f) => f.category === filter);

        if (favourites.length === 0) {
          grid.style.display = "none";
          emptyState.style.display = "block";
          filterBar.style.display = "none";
          updateFavouriteCount();
          return;
        }

        grid.style.display = "grid";
        emptyState.style.display = "none";
        filterBar.style.display = "flex";

        if (filtered.length === 0) {
          grid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--muted);">
              no items in this category yet.
            </div>
          `;
        } else {
          grid.innerHTML = filtered
            .map(
              (item) => `
            <article class="favourite-card" data-id="${item.id}">
              <div class="favourite-media">
                <img src="${item.img}" alt="${item.title}" loading="lazy" />
                ${item.badge ? `<span class="badge">${item.badge}</span>` : ""}
                <button class="remove-favourite" aria-label="remove from favourites" data-remove="${item.id}">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z"/></svg>
                </button>
              </div>
              <div class="favourite-info">
                <span class="favourite-category">${item.category}</span>
                <h3 class="favourite-title">${item.title}</h3>
                <span class="favourite-price">${item.price}</span>
                <div class="favourite-actions">
                  <button class="add-to-cart-btn" data-add="${item.id}">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"/></svg>
                    add to cart
                  </button>
                </div>
              </div>
            </article>
          `,
            )
            .join("");
        }

        updateFavouriteCount();

        // attach event listeners
        grid.querySelectorAll("[data-remove]").forEach((btn) => {
          btn.addEventListener("click", () => {
            const id = parseInt(btn.dataset.remove);
            favourites = favourites.filter((f) => f.id !== id);
            renderFavourites(activeFilter);
            showToast("removed from favourites");
          });
        });

        grid.querySelectorAll("[data-add]").forEach((btn) => {
          btn.addEventListener("click", () => {
            const id = parseInt(btn.dataset.add);
            btn.textContent = "✓ added";
            btn.classList.add("added-to-cart");
            showToast("added to cart");
            setTimeout(() => {
              btn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"/></svg>
                add to cart
              `;
              btn.classList.remove("added-to-cart");
            }, 2000);
          });
        });
      }

      // filter buttons
      filterBar.addEventListener("click", (e) => {
        const btn = e.target.closest(".filter-btn");
        if (!btn) return;

        filterBar
          .querySelectorAll(".filter-btn")
          .forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        activeFilter = btn.dataset.filter;
        renderFavourites(activeFilter);
      });

      // initial render
      renderFavourites("all");

      // menu toggle
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) =>
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }),
        );
      }

      // close mobile nav on outside click
      document.addEventListener("click", (e) => {
        if (mainNav && mainNav.classList.contains("is-open")) {
          if (
            !e.target.closest(".main-nav") &&
            !e.target.closest(".menu-toggle")
          ) {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }
        }
      });

      // header shadow
      const header = document.querySelector(".site-header");
      window.addEventListener(
        "scroll",
        () => {
          header.style.boxShadow =
            window.scrollY > 20
              ? "0 8px 24px -18px rgba(53,29,21,0.35)"
              : "none";
        },
        { passive: true },
      );

      // scroll reveal
      const revealObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              revealObserver.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.1 },
      );

      document
        .querySelectorAll(".reveal")
        .forEach((el) => revealObserver.observe(el));
    })();
  </script>
</body>

</html>