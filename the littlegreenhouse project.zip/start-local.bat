@echo off
cd /d "%~dp0"
where php >nul 2>nul
if errorlevel 1 (
  echo PHP nahi mila. PHP 8.1+ install karo (ya XAMPP) aur PATH mein jodo, phir dobara chalao.
  pause
  exit /b 1
)
set PHP_MYSQL_FLAG=
php -r "exit(extension_loaded('pdo_mysql') ? 0 : 1);"
if errorlevel 1 (
  php -d extension=php_pdo_mysql.dll -r "exit(extension_loaded('pdo_mysql') ? 0 : 1);"
  if errorlevel 1 (
    echo MySQL PDO extension missing. Enable pdo_mysql in php.ini before using the cPanel database.
    pause
    exit /b 1
  )
  set PHP_MYSQL_FLAG=-d extension=php_pdo_mysql.dll
)
echo.
echo === The Little Green House - local server ===
echo Admin account banana hai? Password likho (14+ characters, % aur " mat use karo).
echo Skip karne ke liye bas Enter dabao.
set /p ADMINPASS=Password: 
if not "%ADMINPASS%"=="" php %PHP_MYSQL_FLAG% api\setup-admin.php admin@truelokal.com "%ADMINPASS%"
echo.
echo Site:   http://localhost:3000/
echo Admin:  http://localhost:3000/admin/   (email: admin@truelokal.com)
echo Server band karne ke liye is window mein Ctrl+C dabao.
start "" http://localhost:3000/admin/
php %PHP_MYSQL_FLAG% -S localhost:3000 router.php
pause
