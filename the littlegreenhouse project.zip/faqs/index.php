<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — frequently asked questions</title>
  <meta name="description"
    content="find answers about handmade pots, candles, shipping, care, and studio visits at the little green house." />
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>💭</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1180px;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
      letter-spacing: 0.01em;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    ul {
      list-style: none;
    }

    img {
      display: block;
      max-width: 100%;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 9999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    .reveal {
      opacity: 0;
      transform: translateY(24px);
      transition:
        opacity 0.8s var(--ease-hand),
        transform 0.8s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 14px 26px;
      border-radius: 100px;
      font-size: 0.9rem;
      font-weight: 500;
      letter-spacing: 0.02em;
      white-space: nowrap;
      transition: all 0.3s var(--ease-hand);
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      background: var(--c-900);
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
    }

    .btn-outline {
      border: 1.5px solid var(--c-700);
      color: var(--ink);
      background: transparent;
    }

    .btn-outline:hover {
      background: var(--c-800);
      color: var(--c-50);
      border-color: var(--c-800);
      transform: translateY(-3px);
    }

    /* header */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 600;
      background: rgba(251, 247, 241, 0.86);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 80px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.35rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
      transition: color 0.3s;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active {
      color: var(--ink);
    }

    .main-nav a.is-active::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s,
        color 0.3s;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition: 0.3s;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* FAQ hero */
    .faq-hero {
      padding: 60px 0 30px;
      text-align: center;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .faq-hero h1 {
      font-size: clamp(2.2rem, 4.5vw, 3.5rem);
      line-height: 1.1;
      margin-bottom: 10px;
    }

    .faq-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .faq-hero p {
      color: var(--muted);
      font-size: 1.1rem;
      max-width: 600px;
      margin: 0 auto;
    }

    /* FAQ main */
    .faq-main {
      padding: 50px 0 80px;
    }

    .faq-categories {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 12px;
      margin-bottom: 40px;
    }

    .category-btn {
      padding: 10px 22px;
      border-radius: 50px;
      background: transparent;
      border: 1px solid var(--c-300);
      color: var(--c-800);
      font-size: 0.85rem;
      transition: 0.2s;
      letter-spacing: 0.03em;
    }

    .category-btn:hover {
      border-color: var(--c-600);
      color: var(--c-600);
    }

    .category-btn.active {
      background: var(--ink);
      color: var(--c-100);
      border-color: var(--ink);
    }

    .faq-list {
      max-width: 800px;
      margin: 0 auto;
    }

    .faq-item {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      margin-bottom: 16px;
      overflow: hidden;
      transition:
        box-shadow 0.3s,
        transform 0.3s var(--ease-hand);
    }

    .faq-item:hover {
      box-shadow: var(--shadow-soft);
    }

    .faq-question {
      width: 100%;
      padding: 20px 24px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      text-align: left;
      font-size: 1rem;
      font-weight: 500;
      transition: background 0.2s;
    }

    .faq-question:hover {
      background: var(--surface-2);
    }

    .faq-question .icon {
      flex-shrink: 0;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      border: 1px solid var(--c-400);
      display: flex;
      align-items: center;
      justify-content: center;
      transition:
        transform 0.3s var(--ease-hand),
        background 0.3s,
        color 0.3s;
      font-size: 1.2rem;
      color: var(--c-600);
    }

    .faq-item.active .faq-question .icon {
      transform: rotate(45deg);
      background: var(--c-600);
      color: white;
      border-color: var(--c-600);
    }

    .faq-answer {
      max-height: 0;
      overflow: hidden;
      transition:
        max-height 0.4s var(--ease-hand),
        padding 0.4s;
      padding: 0 24px;
    }

    .faq-item.active .faq-answer {
      max-height: 300px;
      padding: 0 24px 24px;
    }

    .faq-answer p {
      color: var(--muted);
      font-size: 0.95rem;
      line-height: 1.7;
    }

    .contact-section {
      text-align: center;
      margin-top: 50px;
      padding: 40px 20px;
      background: var(--surface-2);
      border-radius: var(--radius-lg);
    }

    .contact-section h3 {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }

    .contact-section p {
      color: var(--muted);
      margin-bottom: 20px;
    }

    .contact-actions {
      display: flex;
      gap: 12px;
      justify-content: center;
      flex-wrap: wrap;
    }

    /* footer */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 70px 0 0;
      margin-top: 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.8fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 50px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand p {
      margin: 14px 0 20px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 12px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      transition: 0.3s;
    }

    .socials a:hover {
      background: var(--c-600);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 16px;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.2s;
    }

    .footer-col a:hover {
      color: white;
    }

    .footer-bottom {
      padding: 24px 0;
      text-align: center;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
    }

    /* responsive */
    @media (max-width: 1024px) {
      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 18px;
      }

      .main-nav {
        position: fixed;
        top: 80px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 16px 28px 28px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition: 0.4s var(--ease-hand);
        z-index: 500;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 14px 0;
        border-bottom: 1px solid var(--line);
      }

      .menu-toggle {
        display: flex;
      }

      .faq-question {
        padding: 16px 18px;
        font-size: 0.9rem;
      }

      .faq-answer {
        padding: 0 18px;
      }

      .faq-item.active .faq-answer {
        padding: 0 18px 18px;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 30px;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <link rel="canonical" href="https://thelittlegreenhouse.in/faqs/" />
  <meta property="og:title" content="the little green house — frequently asked questions" />
  <meta property="og:description" content="find answers about handmade pots, candles, shipping, care, and studio visits at the little green house." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/faqs/" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
  <a class="skip-link" href="#main">skip to FAQ</a>
  <div class="grain" aria-hidden="true"></div>

  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo" aria-label="the little green house home">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="34" height="34">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products"><svg width="19" height="19" viewBox="0 0 24 24"
            fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg></a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="menu" aria-expanded="false" aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <section class="faq-hero">
      <div class="wrap">
        <h1>frequently <em>asked</em></h1>
        <p>
          everything you need to know about our pieces, process, and policies.
        </p>
      </div>
    </section>

    <section class="faq-main" aria-label="frequently asked questions">
      <div class="wrap">
        <div class="faq-categories" id="faqCategories">
          <button class="category-btn active" data-category="all">
            all questions
          </button>
          <button class="category-btn" data-category="shipping">
            shipping & delivery
          </button>
          <button class="category-btn" data-category="care">
            product care
          </button>
          <button class="category-btn" data-category="orders">
            orders & returns
          </button>
          <button class="category-btn" data-category="studio">
            studio & visits
          </button>
        </div>

        <div class="faq-list" id="faqList">
          <!-- FAQ items will be injected here -->
        </div>

        <div class="contact-section reveal">
          <h3>still have questions?</h3>
          <p>
            we're always happy to chat — reach out and we'll get back within a
            day.
          </p>
          <div class="contact-actions">
            <a href="mailto:hello@thelittlegreenhouse.com" class="btn btn-primary">email us</a>
            <a href="../visit/" class="btn btn-outline">visit the studio</a>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>handmade pots, candles & home décor — made slowly, on purpose.</p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    (function () {
      // FAQ data
      const faqs = [
        {
          category: "shipping",
          question: "how long does shipping take?",
          answer:
            "we ship within 3-5 business days from bhubaneswar. domestic orders typically arrive in 5-8 business days. international orders may take 2-3 weeks depending on your location.",
        },
        {
          category: "shipping",
          question: "do you offer free shipping?",
          answer:
            "yes! we offer free standard shipping on all domestic orders over ₹2,500. for orders below that, a flat rate of ₹150 applies.",
        },
        {
          category: "shipping",
          question: "do you ship internationally?",
          answer:
            "yes, we ship worldwide. international shipping costs are calculated at checkout based on your location and order weight.",
        },
        {
          category: "care",
          question: "how do I care for my terracotta pot?",
          answer:
            "terracotta is porous and needs to breathe. avoid harsh chemicals. for cleaning, use a soft brush and warm water. allow to dry completely before use. a light coating of mineral oil can restore its natural sheen.",
        },
        {
          category: "care",
          question: "are your candles made with natural ingredients?",
          answer:
            "absolutely. we use 100% soy wax, cotton wicks, and phthalate-free fragrance oils. no paraffin, no synthetic additives — just clean, slow-burning candles.",
        },
        {
          category: "care",
          question: "how long do your candles burn?",
          answer:
            "our standard candles burn for approximately 45-50 hours. always trim the wick to 1/4 inch before each burn and allow the wax to melt to the edges for an even burn.",
        },
        {
          category: "orders",
          question: "can I modify or cancel my order?",
          answer:
            "you can modify or cancel your order within 24 hours of placing it. after that, we may have already started preparing your piece for shipment. please contact us immediately at hello@thelittlegreenhouse.com.",
        },
        {
          category: "orders",
          question: "what is your return policy?",
          answer:
            "we accept returns within 14 days of delivery for unused, undamaged items. because each piece is handmade, small variations are part of the charm and not considered defects. custom orders are final sale.",
        },
        {
          category: "orders",
          question: "how do I track my order?",
          answer:
            "once your order ships, you will receive a confirmation email with tracking information. you can also check your order status by contacting us directly.",
        },
        {
          category: "studio",
          question: "can I visit the studio?",
          answer:
            "yes! visits are by appointment only. you can book a 45-minute appointment through our visit page. come see the wheel, smell the candles, and take home something special.",
        },
        {
          category: "studio",
          question: "do you offer workshops?",
          answer:
            "we occasionally host small workshops for pottery and candle-making. join our mailing list or follow us on instagram to hear about upcoming sessions.",
        },
        {
          category: "studio",
          question: "where are you located?",
          answer:
            "our studio is in the heart of bhubaneswar, odisha. the exact address is shared upon appointment confirmation to ensure a quiet, personal experience for each visitor.",
        },
      ];

      const faqList = document.getElementById("faqList");
      const categoryBtns = document.getElementById("faqCategories");
      let activeCategory = "all";
      let openIndex = null;

      function renderFAQs(category) {
        const filtered =
          category === "all"
            ? faqs
            : faqs.filter((faq) => faq.category === category);

        faqList.innerHTML = filtered
          .map(
            (faq, index) => `
          <div class="faq-item ${openIndex === index ? "active" : ""}" data-index="${index}">
            <button class="faq-question" aria-expanded="${openIndex === index ? "true" : "false"}">
              <span>${faq.question}</span>
              <span class="icon" aria-hidden="true">+</span>
            </button>
            <div class="faq-answer">
              <p>${faq.answer}</p>
            </div>
          </div>
        `,
          )
          .join("");

        // attach click handlers
        faqList.querySelectorAll(".faq-question").forEach((btn) => {
          btn.addEventListener("click", () => {
            const item = btn.closest(".faq-item");
            const index = parseInt(item.dataset.index);

            if (openIndex === index) {
              openIndex = null;
              item.classList.remove("active");
              btn.setAttribute("aria-expanded", "false");
            } else {
              // close previously open item
              if (openIndex !== null) {
                const prevOpen = faqList.querySelector(
                  `.faq-item[data-index="${openIndex}"]`,
                );
                if (prevOpen) {
                  prevOpen.classList.remove("active");
                  prevOpen
                    .querySelector(".faq-question")
                    .setAttribute("aria-expanded", "false");
                }
              }
              openIndex = index;
              item.classList.add("active");
              btn.setAttribute("aria-expanded", "true");
            }
          });
        });
      }

      // initialize with all FAQs
      renderFAQs("all");

      // category filter
      categoryBtns.addEventListener("click", (e) => {
        const btn = e.target.closest(".category-btn");
        if (!btn) return;

        categoryBtns
          .querySelectorAll(".category-btn")
          .forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        activeCategory = btn.dataset.category;
        openIndex = null;
        renderFAQs(activeCategory);
      });

      // menu toggle
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) =>
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }),
        );
      }

      // header shadow
      const header = document.querySelector(".site-header");
      window.addEventListener(
        "scroll",
        () => {
          header.style.boxShadow =
            window.scrollY > 20
              ? "0 8px 24px -18px rgba(53,29,21,0.35)"
              : "none";
        },
        { passive: true },
      );

      // scroll reveal
      const revealObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              revealObserver.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.1 },
      );

      document
        .querySelectorAll(".reveal")
        .forEach((el) => revealObserver.observe(el));
    })();
  </script>
</body>

</html>