/**
 * The Little Green House — Studio Admin Dashboard
 *
 * Features:
 * - Real JWT Authentication & Session Persistence
 * - REST API Communication with PHP Backend (../api)
 * - Complete Product Catalog & Inventory CRUD with Shiprocket weights
 * - Order Lifecycle Management with Customer Email Updates
 * - Shiprocket Logistics Tracking & AWB Management
 * - Transaction & Refund Processing
 * - Admin Security (Change Password with Email Alert, Audit Logs)
 * - Staff Account Management (Owner JWT enforced + Email Alerts)
 * - Shiprocket Pincode Serviceability Verification
 * - Offline / Standalone Fallback Mirror if Web Server is offline
 */

// ====================================================================
// 1. Constants, Formatters & Utilities
// ====================================================================
const TOKEN_KEY = "tlgh_admin_jwt";
const USER_KEY = "tlgh_admin_user";
const API_BASE_KEY = "tlgh_api_base";
const LOCAL_DB_KEY = "tlgh_admin_local_db";

// Escape API/database values before placing them into HTML templates.
function escapeHtml(value) {
  return String(value ?? "").replace(
    /[&<>"']/g,
    (char) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
      })[char],
  );
}

function safeHttpsUrl(value) {
  try {
    const url = new URL(String(value || ""), window.location.origin);
    return url.protocol === "https:" ? url.href : "";
  } catch (_) {
    return "";
  }
}

function getApiBase() {
  return localStorage.getItem(API_BASE_KEY) || "../api";
}

const CURRENCY = (v) =>
  "₹" + Number(v || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 });
const uid = (p = "id") => p + "_" + Math.random().toString(36).slice(2, 9);
const todayISO = () => new Date().toISOString().slice(0, 10);
const nowISO = () => new Date().toISOString();
const fmtDate = (iso) => {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
  } catch (e) {
    return iso;
  }
};
const fmtDateTime = (iso) => {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("en-IN", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch (e) {
    return iso;
  }
};

let currentUser = null;
let currentToken = null;
let currentPage = "overview";
let isLiveApi = false;
let overviewChart = null;

// ====================================================================
// 2. Client-side Fallback Mock DB (for offline preview / static testing)
// ====================================================================
function getFallbackDB() {
  try {
    const raw = localStorage.getItem(LOCAL_DB_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}

  const initial = {
    products: [
      {
        id: 1,
        name: "Amber Stoneware Planter",
        category_id: 1,
        category_name: "Pots & Planters",
        category_slug: "pots",
        sku: "POT-AMB-001",
        price: 1450,
        stock_quantity: 18,
        online_stock_quantity: 18,
        local_stock_quantity: 12,
        weight_grams: 1200,
        dimensions: "16cm H x 14cm W",
        tag: "Best Seller",
        primary_image:
          "https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=400&q=80",
        is_active: 1,
      },
      {
        id: 2,
        name: "Clay Rim Terracotta Pot",
        category_id: 1,
        category_name: "Pots & Planters",
        category_slug: "pots",
        sku: "POT-TER-002",
        price: 980,
        stock_quantity: 4,
        online_stock_quantity: 4,
        local_stock_quantity: 16,
        weight_grams: 900,
        dimensions: "14cm H x 13cm W",
        tag: "Hand-thrown",
        primary_image:
          "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=400&q=80",
        is_active: 1,
      },
      {
        id: 3,
        name: "Sandalwood Pillar Candle",
        category_id: 2,
        category_name: "Candles",
        category_slug: "candles",
        sku: "CND-SAN-001",
        price: 620,
        compare_at_price: 750,
        stock_quantity: 30,
        online_stock_quantity: 30,
        local_stock_quantity: 25,
        weight_grams: 450,
        dimensions: "10cm H x 7cm Dia",
        tag: "Sale",
        primary_image:
          "https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=400&q=80",
        is_active: 1,
      },
      {
        id: 4,
        name: "Smoked Vanilla Jar Candle",
        category_id: 2,
        category_name: "Candles",
        category_slug: "candles",
        sku: "CND-VAN-002",
        price: 720,
        stock_quantity: 22,
        online_stock_quantity: 22,
        local_stock_quantity: 8,
        weight_grams: 500,
        dimensions: "9cm H x 8cm Dia",
        tag: "New",
        primary_image:
          "https://images.unsplash.com/photo-1572726729437-373264770020?auto=format&fit=crop&w=400&q=80",
        is_active: 1,
      },
      {
        id: 5,
        name: "Trailing Pothos",
        category_id: 3,
        category_name: "Plants",
        category_slug: "plants",
        sku: "PLT-POT-001",
        price: 540,
        stock_quantity: 15,
        online_stock_quantity: 15,
        local_stock_quantity: 5,
        weight_grams: 800,
        dimensions: "Vine length ~35cm",
        tag: "Low Light",
        primary_image:
          "https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=400&q=80",
        is_active: 1,
      },
      {
        id: 6,
        name: "Snake Plant",
        category_id: 3,
        category_name: "Plants",
        category_slug: "plants",
        sku: "PLT-SNK-002",
        price: 690,
        stock_quantity: 2,
        online_stock_quantity: 2,
        local_stock_quantity: 0,
        weight_grams: 1100,
        dimensions: "Height ~40cm",
        tag: "Air Purifying",
        primary_image:
          "https://images.unsplash.com/photo-1593482892290-f54927ae1bf6?auto=format&fit=crop&w=400&q=80",
        is_active: 1,
      },
      {
        id: 7,
        name: "Woven Rattan Wall Mirror",
        category_id: 4,
        category_name: "Home Décor",
        category_slug: "decor",
        sku: "DEC-RAT-001",
        price: 2100,
        stock_quantity: 8,
        online_stock_quantity: 8,
        local_stock_quantity: 3,
        weight_grams: 1500,
        dimensions: "50cm Diameter",
        tag: "Artisanal",
        primary_image:
          "https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&w=400&q=80",
        is_active: 1,
      },
      {
        id: 8,
        name: "Hand-Carved Wooden Tray",
        category_id: 4,
        category_name: "Home Décor",
        category_slug: "decor",
        sku: "DEC-TRY-002",
        price: 890,
        stock_quantity: 14,
        online_stock_quantity: 14,
        local_stock_quantity: 20,
        weight_grams: 750,
        dimensions: "32cm L x 18cm W",
        tag: "Handcrafted",
        primary_image:
          "https://images.unsplash.com/photo-1534349762230-e0cadf78f5da?auto=format&fit=crop&w=400&q=80",
        is_active: 1,
      },
    ],
    orders: [
      {
        id: 101,
        order_number: "TLGH-2026-901",
        customer_name: "Ananya Sharma",
        customer_email: "ananya.s@example.com",
        customer_phone: "+91 98765 43210",
        shipping_address:
          "B-402, Garden View Apartments, Indiranagar, Bengaluru, Karnataka - 560038",
        subtotal: 2070,
        shipping_cost: 0,
        total_amount: 2070,
        payment_method: "ONLINE",
        payment_status: "PAID",
        order_status: "PROCESSING",
        courier_name: "Bluedart Express",
        shiprocket_awb: "BLD-94821038",
        shiprocket_status: "PICKED_UP",
        tracking_url: "https://shiprocket.co/tracking/BLD-94821038",
        items: [
          {
            id: 1,
            product_id: 1,
            product_name: "Amber Stoneware Planter",
            sku: "POT-AMB-001",
            unit_price: 1450,
            quantity: 1,
          },
          {
            id: 2,
            product_id: 3,
            product_name: "Sandalwood Pillar Candle",
            sku: "CND-SAN-001",
            unit_price: 620,
            quantity: 1,
          },
        ],
        created_at: new Date(Date.now() - 3600000 * 4).toISOString(),
      },
      {
        id: 102,
        order_number: "TLGH-2026-902",
        customer_name: "Vikram Malhotra",
        customer_email: "vikram.m@example.com",
        customer_phone: "+91 98112 23344",
        shipping_address:
          "Flat 12A, Sea Green Towers, Bandra West, Mumbai, Maharashtra - 400050",
        subtotal: 980,
        shipping_cost: 99,
        total_amount: 1079,
        payment_method: "COD",
        payment_status: "PENDING",
        order_status: "PENDING",
        courier_name: "Delhivery Surface",
        shiprocket_awb: "DLV-83749210",
        shiprocket_status: "AWB_ASSIGNED",
        tracking_url: "https://shiprocket.co/tracking/DLV-83749210",
        items: [
          {
            id: 3,
            product_id: 2,
            product_name: "Clay Rim Terracotta Pot",
            sku: "POT-TER-002",
            unit_price: 980,
            quantity: 1,
          },
        ],
        created_at: new Date(Date.now() - 3600000 * 18).toISOString(),
      },
      {
        id: 103,
        order_number: "TLGH-2026-903",
        customer_name: "Roshni Sen",
        customer_email: "roshni.sen@example.com",
        customer_phone: "+91 99031 55667",
        shipping_address: "48 Lake Gardens, Kolkata, West Bengal - 700045",
        subtotal: 2790,
        shipping_cost: 0,
        total_amount: 2790,
        payment_method: "ONLINE",
        payment_status: "PAID",
        order_status: "DELIVERED",
        courier_name: "Bluedart Air",
        shiprocket_awb: "BLD-72619401",
        shiprocket_status: "DELIVERED",
        tracking_url: "https://shiprocket.co/tracking/BLD-72619401",
        items: [
          {
            id: 4,
            product_id: 7,
            product_name: "Woven Rattan Wall Mirror",
            sku: "DEC-RAT-001",
            unit_price: 2100,
            quantity: 1,
          },
          {
            id: 5,
            product_id: 6,
            product_name: "Snake Plant",
            sku: "PLT-SNK-002",
            unit_price: 690,
            quantity: 1,
          },
        ],
        created_at: new Date(Date.now() - 3600000 * 48).toISOString(),
      },
    ],
    staff: [
      {
        id: 1,
        full_name: "Store Owner",
        email: "owner@thelittlegreenhouse.com",
        role: "OWNER",
        is_active: 1,
        created_at: "2026-01-01",
      },
      {
        id: 2,
        full_name: "Ritu Potter",
        email: "ritu@thelittlegreenhouse.com",
        role: "STAFF",
        is_active: 1,
        created_at: "2026-02-15",
      },
    ],
    logs: [
      {
        id: 1,
        admin_email: "owner@thelittlegreenhouse.com",
        action: "ADMIN_LOGIN",
        ip_address: "127.0.0.1",
        created_at: nowISO(),
      },
      {
        id: 2,
        admin_email: "owner@thelittlegreenhouse.com",
        action: "ORDER_PROCESSED",
        ip_address: "127.0.0.1",
        created_at: new Date(Date.now() - 3600000).toISOString(),
      },
    ],
    subscribers: [
      {
        id: 1,
        email: "ananya.s@example.com",
        is_active: 1,
        created_at: new Date(Date.now() - 86400000 * 12).toISOString(),
      },
      {
        id: 2,
        email: "roshni.sen@example.com",
        is_active: 1,
        created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
      },
      {
        id: 3,
        email: "vikram.m@example.com",
        is_active: 1,
        created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
      },
    ],
  };

  saveFallbackDB(initial);
  return initial;
}

function saveFallbackDB(data) {
  try {
    localStorage.setItem(LOCAL_DB_KEY, JSON.stringify(data));
  } catch (e) {}
}

// ====================================================================
// 3. Robust REST API Client with JWT
// ====================================================================
// Builds the request URL. Normal bases are path prefixes ("../api"). A base that
// ends with "?__route=" targets the plain-file fallback ("../api/index.php?__route=").
function buildApiUrl(base, endpoint) {
  const clean = endpoint.replace(/^\//, "");
  if (/\?__route=$/.test(base)) {
    const [path, query] = clean.split(/\?(.*)/s);
    return base + "/" + path + (query ? "&" + query : "");
  }
  return base.replace(/\/$/, "") + "/" + clean;
}

async function apiFetch(endpoint, options = {}) {
  const base = getApiBase();
  const url = buildApiUrl(base, endpoint);
  const headers = {
    Accept: "application/json",
    ...(options.headers || {}),
  };

  const token = currentToken || localStorage.getItem(TOKEN_KEY);
  // Login is the operation that replaces a prior session. Do not send a stale
  // token alongside credentials; proxies and auth middleware may reject it.
  if (token && endpoint !== "/auth/admin/login") {
    headers["Authorization"] = "Bearer " + token;
  }

  if (
    options.body &&
    typeof options.body === "object" &&
    !(options.body instanceof FormData)
  ) {
    headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(options.body);
  }

  try {
    const parseBody = (text) => {
      try {
        return JSON.parse(text.replace(/^\uFEFF/, ""));
      } catch (_) {
        return null;
      }
    };
    let res = await fetch(url, { ...options, headers });
    let contentType = res.headers.get("content-type") || "";
    // Some shared hosts/proxies mislabel a valid JSON response as text/html.
    // Parse the body first; Content-Type is advisory and must not block login
    // before we can inspect a valid token response.
    let responseText = await res.text();
    let json = parseBody(responseText);

    // If the host is not applying api/.htaccess (hidden file missing, or
    // rewriting disabled), the pretty URL returns an HTML page. Try the URL forms
    // that need no rewriting, in order, and remember the first one that answers
    // with JSON. The plain-file form works even when PATH_INFO is not supported.
    if (!json || typeof json !== "object") {
      const root = base.replace(/\/index\.php.*$/, "").replace(/\/$/, "");
      const candidates = [
        root + "/index.php?__route=",
        root + "/index.php",
      ].filter((c) => c !== base);
      for (const altBase of candidates) {
        try {
          const altRes = await fetch(buildApiUrl(altBase, endpoint), {
            ...options,
            headers,
          });
          const altText = await altRes.text();
          const altJson = parseBody(altText);
          if (altJson && typeof altJson === "object" && !Array.isArray(altJson)) {
            localStorage.setItem(API_BASE_KEY, altBase);
            res = altRes;
            contentType = altRes.headers.get("content-type") || "";
            responseText = altText;
            json = altJson;
            break;
          }
        } catch (_) {}
      }
    }

    if (res.status === 401) {
      // Token expired or invalid
      if (currentToken) {
        toast("Session expired. Please sign in again.", true);
        logout();
      }
      throw new Error(json?.error || "Authentication required");
    }

    if (!res.ok) {
      throw new Error(json?.error || `HTTP error ${res.status}`);
    }

    if (!json || typeof json !== "object" || Array.isArray(json)) {
      throw new Error(
        `The API endpoint returned an invalid JSON response (HTTP ${res.status}, content type: ${contentType || "missing"}). Check the admin API base URL (${url}) and PHP routing. Response started with: ${responseText.replace(/\s+/g, " ").slice(0, 160) || "(empty)"}`,
      );
    }

    isLiveApi = true;
    updateApiStatusBadge(true);
    return json;
  } catch (err) {
    // If request failed due to network / CORS / server offline
    if (
      err.name === "TypeError" ||
      err.message.includes("Failed to fetch") ||
      err.message.includes("NetworkError")
    ) {
      isLiveApi = false;
      updateApiStatusBadge(false);
      return handleOfflineFallback(endpoint, options);
    }
    throw err;
  }
}

// Check health of backend web server
async function checkApiConnection() {
  try {
    const base = getApiBase();
    const url = buildApiUrl(base, "/health");
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    const contentType = res.headers.get("content-type") || "";
    const responseText = await res.text();
    let data = null;
    try {
      data = JSON.parse(responseText.replace(/^\uFEFF/, ""));
    } catch (_) {}
    if (res.ok && data && typeof data === "object") {
      isLiveApi = true;
      updateApiStatusBadge(true, data.database);
      return true;
    }
    if (data && typeof data === "object") {
      // The API can be reachable while its database is unavailable. Report that
      // state accurately instead of claiming the entire API is offline.
      isLiveApi = true;
      updateApiStatusBadge(true, "unavailable");
    }
  } catch (e) {}

  isLiveApi = false;
  updateApiStatusBadge(false);
  return false;
}

function updateApiStatusBadge(online, dbStatus = "connected") {
  const badge = document.getElementById("apiStatusBadge");
  if (!badge) return;
  if (online) {
    const safeDbStatus = String(dbStatus || "unknown").replace(/[<>]/g, "");
    badge.innerHTML =
      safeDbStatus.toLowerCase() === "unavailable"
        ? `<span class="api-dot offline"></span> API Online · Database Error`
        : `<span class="api-dot online"></span> API Connected`;
    badge.title = `Connected to web server API. Database: ${safeDbStatus}`;
  } else {
    badge.innerHTML = `<span class="api-dot offline"></span> Standalone Mode (Offline)`;
    badge.title = "Web server not reachable. Running on local state.";
  }
}

// Seamless mock router for offline development / previewing
function handleOfflineFallback(endpoint, options = {}) {
  console.warn(
    `[TLGH Admin] API offline. Handling fallback for ${options.method || "GET"} ${endpoint}`,
  );
  const method = (options.method || "GET").toUpperCase();
  endpoint = endpoint.replace(/^\/admin\/(products|categories|orders)(?=\/|$)/, "/$1");
  const db = getFallbackDB();

  // /health
  if (endpoint.includes("health")) {
    return {
      success: true,
      app: "The Little Green House API (Mock)",
      status: "healthy",
      database: "local",
    };
  }

  // /auth/admin/login
  if (endpoint === "/auth/admin/login" && method === "POST") {
    throw new Error(
      "Admin sign-in requires the PHP API. Start the local web server and configure an admin password first.",
    );
  }

  // /auth/admin/change-password
  if (endpoint === "/auth/admin/change-password" && method === "POST") {
    return {
      success: true,
      message:
        "Password updated successfully. Security confirmation email sent.",
    };
  }

  // /admin/dashboard
  if (endpoint === "/admin/dashboard") {
    const revenue = db.orders
      .filter((o) => o.payment_status === "PAID")
      .reduce((sum, o) => sum + (o.total_amount || 0), 0);
    const lowStock = db.products.filter(
      (p) => (p.online_stock_quantity ?? p.stock_quantity ?? 0) <= 5,
    ).length;
    return {
      success: true,
      metrics: {
        total_revenue: revenue,
        total_orders: db.orders.length,
        pending_orders: db.orders.filter((o) => o.order_status === "PENDING")
          .length,
        low_stock: lowStock,
      },
      recent_orders: db.orders.slice(0, 5),
      activity_logs: db.logs.slice(0, 8),
    };
  }

  // /products single item GET
  if (endpoint.startsWith("/products/") && method === "GET") {
    const id = parseInt(endpoint.split("/")[2]);
    const p = db.products.find((x) => x.id === id);
    if (!p) throw new Error("Product not found");
    return { success: true, product: p };
  }

  // /products list
  if (endpoint.startsWith("/products") && method === "GET") {
    return { success: true, products: db.products };
  }

  // POST /products
  if (endpoint === "/products" && method === "POST") {
    const p =
      typeof options.body === "string"
        ? JSON.parse(options.body)
        : options.body;
    p.id = Date.now();
    p.online_stock_quantity = Number(
      p.online_stock_quantity ?? p.stock_quantity ?? 0,
    );
    p.local_stock_quantity = Number(p.local_stock_quantity ?? 0);
    p.stock_quantity = p.online_stock_quantity;
    p.price = Number(p.price || 0);
    p.weight_grams = Number(p.weight_grams || 500);
    p.primary_image =
      p.image_url ||
      "https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=400&q=80";
    db.products.unshift(p);
    saveFallbackDB(db);
    return { success: true, product_id: p.id, message: "Product created" };
  }

  // PUT /products/{id}
  if (endpoint.startsWith("/products/") && method === "PUT") {
    const id = parseInt(endpoint.split("/")[2]);
    const p =
      typeof options.body === "string"
        ? JSON.parse(options.body)
        : options.body;
    const idx = db.products.findIndex((x) => x.id === id);
    if (idx !== -1) {
      if (p.online_stock_quantity !== undefined)
        p.stock_quantity = Number(p.online_stock_quantity);
      db.products[idx] = { ...db.products[idx], ...p };
      if (p.image_url) db.products[idx].primary_image = p.image_url;
      saveFallbackDB(db);
    }
    return { success: true, message: "Product updated" };
  }

  // DELETE /products/{id}
  if (endpoint.startsWith("/products/") && method === "DELETE") {
    const id = parseInt(endpoint.split("/")[2]);
    db.products = db.products.filter((x) => x.id !== id);
    saveFallbackDB(db);
    return { success: true, message: "Product deleted" };
  }

  // /orders
  if (endpoint === "/orders" && method === "GET") {
    return { success: true, orders: db.orders };
  }

  // GET /orders/{id}
  if (
    endpoint.startsWith("/orders/") &&
    !endpoint.includes("status") &&
    !endpoint.includes("track") &&
    method === "GET"
  ) {
    const id = parseInt(endpoint.split("/")[2]);
    const ord = db.orders.find((x) => x.id === id);
    if (!ord) throw new Error("Order not found");
    return { success: true, order: ord };
  }

  // PUT /orders/{id}/status
  if (endpoint.includes("/status") && method === "PUT") {
    const id = parseInt(endpoint.split("/")[2]);
    const b =
      typeof options.body === "string"
        ? JSON.parse(options.body)
        : options.body;
    const ord = db.orders.find((x) => x.id === id);
    if (ord) {
      if (b.order_status) ord.order_status = b.order_status;
      if (b.payment_status) ord.payment_status = b.payment_status;
      if (b.courier_name) ord.courier_name = b.courier_name;
      if (b.shiprocket_awb || b.awb)
        ord.shiprocket_awb = b.shiprocket_awb || b.awb;
      if (b.tracking_url) ord.tracking_url = b.tracking_url;
      if (b.notes) ord.notes = b.notes;
      saveFallbackDB(db);
    }
    return {
      success: true,
      message: "Order status updated and customer notified.",
    };
  }

  // GET /orders/{id}/track
  if (endpoint.includes("/track") && method === "GET") {
    const id = parseInt(endpoint.split("/")[2]);
    const ord = db.orders.find((x) => x.id === id);
    return {
      success: true,
      awb_code: ord?.shiprocket_awb || "BLD-94821038",
      tracking_url: ord?.tracking_url || "https://shiprocket.co/tracking",
      tracking: {
        courier_name: ord?.courier_name || "Bluedart",
        current_status: ord?.shiprocket_status || "In Transit",
        destination: "Bengaluru, KA",
        checkpoints: [
          {
            time: "Today 10:30 AM",
            location: "Bengaluru Hub",
            status: "Out for Delivery",
          },
          {
            time: "Yesterday 08:15 PM",
            location: "Transit Center, Mumbai",
            status: "Departed Facility",
          },
          {
            time: "2 days ago 04:00 PM",
            location: "New Delhi Studio",
            status: "Picked Up by Courier",
          },
        ],
      },
    };
  }

  // /admin/staff
  if (endpoint === "/admin/staff") {
    if (method === "GET") return { success: true, staff: db.staff };
    if (method === "POST") {
      const b =
        typeof options.body === "string"
          ? JSON.parse(options.body)
          : options.body;
      const s = {
        id: Date.now(),
        full_name: b.full_name,
        email: b.email,
        role: b.role || "STAFF",
        is_active: 1,
        created_at: todayISO(),
      };
      db.staff.push(s);
      saveFallbackDB(db);
      return { success: true, message: "Staff member created", staff_id: s.id };
    }
  }

  if (endpoint.startsWith("/admin/staff/") && method === "DELETE") {
    const id = parseInt(endpoint.split("/")[3]);
    db.staff = db.staff.filter((x) => x.id !== id);
    saveFallbackDB(db);
    return { success: true, message: "Staff member removed" };
  }

  // /shiprocket/serviceability
  if (endpoint.includes("/shiprocket/serviceability")) {
    return {
      success: true,
      data: {
        status: 200,
        available_courier_companies: [
          { courier_name: "Bluedart Air", etd: "2-3 Days", rate: 110, cod: 1 },
          {
            courier_name: "Delhivery Surface",
            etd: "4-5 Days",
            rate: 75,
            cod: 1,
          },
          {
            courier_name: "Shadowfax Express",
            etd: "3-4 Days",
            rate: 85,
            cod: 1,
          },
        ],
      },
    };
  }

  // /admin/subscribers
  if (endpoint === "/admin/subscribers" && method === "GET") {
    return {
      success: true,
      count: (db.subscribers || []).length,
      subscribers: db.subscribers || [],
    };
  }

  // /newsletter
  if (endpoint === "/newsletter" && method === "POST") {
    const b =
      typeof options.body === "string"
        ? JSON.parse(options.body)
        : options.body;
    const em = (b?.email || "").trim().toLowerCase();
    if (em) {
      if (!db.subscribers) db.subscribers = [];
      const found = db.subscribers.find((s) => s.email === em);
      if (found) {
        found.is_active = 1;
        found.unsubscribed_at = null;
      } else {
        db.subscribers.unshift({
          id: Date.now(),
          email: em,
          is_active: 1,
          created_at: nowISO(),
        });
      }
      saveFallbackDB(db);
    }
    return {
      success: true,
      message:
        "Thank you for joining our newsletter list! A welcome note has been sent to your email.",
    };
  }

  return { success: true };
}

// ====================================================================
// 4. Authentication Management
// ====================================================================
async function handleLogin(e) {
  e.preventDefault();
  const errorEl = document.getElementById("loginError");
  const submitBtn = e.target.querySelector('button[type="submit"]');
  errorEl.style.display = "none";

  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPass").value;

  if (!email || !password) {
    errorEl.textContent = "Please enter both email and password.";
    errorEl.style.display = "block";
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = "Verifying credentials…";

  try {
    const data = await apiFetch("/auth/admin/login", {
      method: "POST",
      body: { email, password },
    });

    let payload = data;
    for (let depth = 0; depth < 3; depth++) {
      const wrapped = payload?.data || payload?.result || payload?.payload;
      if (!wrapped || typeof wrapped !== "object") break;
      payload = wrapped;
    }
    const tokenValue =
      payload?.token ||
      payload?.access_token ||
      payload?.jwt ||
      payload?.jwt_token;
    const token =
      typeof tokenValue === "string"
        ? tokenValue.trim().replace(/^Bearer\s+/i, "")
        : "";
    const adminValue =
      payload?.admin || payload?.user || data?.admin || data?.user;
    const admin =
      adminValue && typeof adminValue === "object" ? adminValue : {};
    if (!token) {
      throw new Error(
        `The admin login API returned no access token (response fields: ${Object.keys(payload || {}).join(", ") || "none"}). Confirm the login endpoint and response format.`,
      );
    }

    currentToken = token;
    const loginEmail = String(admin.email || email);
    currentUser = {
      ...admin,
      full_name: getAdminDisplayName({ ...admin, email: loginEmail }),
      email: loginEmail,
      role: String(admin.role || "ADMIN"),
    };

    try {
      localStorage.setItem(TOKEN_KEY, currentToken);
      localStorage.setItem(USER_KEY, JSON.stringify(currentUser));
    } catch (storageError) {
      // Keep the active session usable for this page lifetime when browser
      // storage is disabled or full. The user can sign in again after reload.
      console.warn(
        "Could not persist the admin session in browser storage.",
        storageError,
      );
    }

    applyUserSession(currentUser);
    toast(`Welcome back, ${getAdminDisplayName(currentUser)}!`);
    document.getElementById("loginScreen").style.display = "none";
    document.getElementById("app").style.display = "block";
    navigate("overview");
  } catch (err) {
    console.error("Login failed:", err);
    errorEl.textContent = err.message || "Invalid email or password.";
    errorEl.style.display = "block";
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = "Sign In";
  }
}

function applyUserSession(user) {
  if (!user) return;
  const displayName = getAdminDisplayName(user);
  document.getElementById("whoName").textContent = displayName;
  document.getElementById("whoRole").textContent =
    (user.role || "ADMIN").toLowerCase() + " account";
  document.getElementById("whoAvatar").textContent = displayName
    .charAt(0)
    .toUpperCase();
}

function getAdminDisplayName(user) {
  if (!user || typeof user !== "object") return "Admin";
  return String(user.full_name || user.name || user.email || "Admin");
}

function logout() {
  currentToken = null;
  currentUser = null;
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);

  document.getElementById("app").style.display = "none";
  document.getElementById("loginScreen").style.display = "flex";
  document.getElementById("loginForm").reset();
  toast("Signed out successfully");
}

// Restore session on boot
async function restoreSession() {
  const savedToken = localStorage.getItem(TOKEN_KEY);
  const savedUser = localStorage.getItem(USER_KEY);

  if (savedToken && savedUser) {
    try {
      currentToken = savedToken;
      currentUser = JSON.parse(savedUser);
      if (!currentUser || typeof currentUser !== "object")
        throw new Error("Invalid saved admin session");
      currentUser.full_name = getAdminDisplayName(currentUser);
      applyUserSession(currentUser);

      document.getElementById("loginScreen").style.display = "none";
      document.getElementById("app").style.display = "block";

      // Check connection asynchronously
      checkApiConnection();
      navigate("overview");
      return;
    } catch (e) {
      console.error("Session restoration error:", e);
      currentToken = null;
      currentUser = null;
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    }
  }

  // Not authenticated
  document.getElementById("app").style.display = "none";
  document.getElementById("loginScreen").style.display = "flex";
  checkApiConnection();
}

// ====================================================================
// 5. Navigation & UI Wire-up
// ====================================================================
const PAGE_TITLES = {
  overview: "dashboard",
  instore: "in-store inventory",
  online: "online store inventory",
  orders: "orders",
  deliveries: "deliveries & logistics",
  payments: "payments & transactions",
  refunds: "refunds",
  settings: "settings & security",
};

function navigate(page) {
  currentPage = page;
  closeMobileNav();
  document.getElementById("pageTitle").textContent = PAGE_TITLES[page] || page;

  document
    .querySelectorAll(".nav-item[data-page], .bottom-nav button[data-page]")
    .forEach((b) => {
      b.classList.toggle("active", b.dataset.page === page);
    });

  const renderers = {
    overview: renderOverview,
    instore: renderInstore,
    online: renderOnline,
    orders: renderOrders,
    deliveries: renderDeliveries,
    payments: renderPayments,
    refunds: renderRefunds,
    settings: renderSettings,
  };

  document.getElementById("topbarActions").innerHTML = "";
  renderApiStatusPill();

  const fn = renderers[page] || renderOverview;
  fn();
}

function closeMobileNav() {
  document.getElementById("sidebar").classList.remove("mobile-open");
  document.getElementById("scrim").classList.remove("show");
}

function renderApiStatusPill() {
  const actions = document.getElementById("topbarActions");
  let pill = document.getElementById("apiStatusBadge");
  if (!pill) {
    pill = document.createElement("div");
    pill.id = "apiStatusBadge";
    pill.className = "api-badge";
    actions.appendChild(pill);
  }
  updateApiStatusBadge(isLiveApi);
}

// Modal helper
function openModal(html) {
  document.getElementById("modalBody").innerHTML = html;
  document.getElementById("overlay").classList.add("show");
}

function closeModal() {
  document.getElementById("overlay").classList.remove("show");
}

// Toast helper
function toast(msg, isError = false) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.style.background = isError ? "var(--danger-dark)" : "var(--brown-deep)";
  t.classList.add("show");
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove("show"), 3000);
}

function statusPill(status) {
  const map = {
    PAID: ["pill-sage", "Paid"],
    PENDING: ["pill-amber", "Pending"],
    REFUND_PENDING: ["pill-amber", "Refund Pending"],
    REFUNDED: ["pill-gray", "Refunded"],
    FAILED: ["pill-danger", "Failed"],
    CONFIRMED: ["pill-sage", "Confirmed"],
    PROCESSING: ["pill-clay", "Processing"],
    SHIPPED: ["pill-clay", "Shipped"],
    OUT_FOR_DELIVERY: ["pill-amber", "Out for Delivery"],
    DELIVERED: ["pill-sage", "Delivered"],
    CANCELLED: ["pill-danger", "Cancelled"],
    // lowercase fallbacks
    paid: ["pill-sage", "Paid"],
    pending: ["pill-amber", "Pending"],
    refunded: ["pill-gray", "Refunded"],
    shipped: ["pill-clay", "Shipped"],
    delivered: ["pill-sage", "Delivered"],
  };
  const [cls, label] = map[status] || ["pill-gray", status];
  return `<span class="pill ${escapeHtml(cls)}">${escapeHtml(label)}</span>`;
}

// ====================================================================
// 6. OVERVIEW / DASHBOARD
// ====================================================================
async function renderOverview() {
  const content = document.getElementById("content");
  content.innerHTML = `<div class="empty-state"><h4>Loading dashboard data…</h4></div>`;

  let dashData;
  try {
    dashData = await apiFetch("/admin/dashboard");
  } catch (err) {
    toast("Failed to load dashboard data: " + err.message, true);
    dashData = {
      metrics: {
        total_revenue: 0,
        total_orders: 0,
        pending_orders: 0,
        low_stock: 0,
      },
      recent_orders: [],
      activity_logs: [],
    };
  }

  const m = dashData.metrics || {};
  const orders = dashData.recent_orders || [];
  const logs = dashData.activity_logs || [];

  content.innerHTML = `
    <!-- KPI Row -->
    <div class="kpi-row">
      <div class="kpi-card">
        <div class="kpi-label">total revenue</div>
        <div class="kpi-val">${CURRENCY(m.total_revenue || 0)}</div>
        <div class="kpi-sub">from completed orders</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">total orders</div>
        <div class="kpi-val">${m.total_orders || 0}</div>
        <div class="kpi-sub">all time volume</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">pending orders</div>
        <div class="kpi-val" style="color: ${m.pending_orders > 0 ? "var(--amber-dark)" : "var(--sage-dark)"}">${m.pending_orders || 0}</div>
        <div class="kpi-sub">need packing & dispatch</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">low stock items</div>
        <div class="kpi-val" style="color: ${m.low_stock > 0 ? "var(--danger)" : "var(--ink)"}">${m.low_stock || 0}</div>
        <div class="kpi-sub">≤ 5 units remaining</div>
      </div>
    </div>

    <!-- Chart & Quick Actions -->
    <div class="grid-2" style="margin-top: 24px;">
      <div class="section-card">
        <div class="card-head">
          <h3>studio sales trend</h3>
          <span style="font-size:12px; color:var(--ink-soft);">monthly overview</span>
        </div>
        <div style="height: 240px; position: relative;">
          <canvas id="revenueChart"></canvas>
        </div>
      </div>

      <div class="section-card">
        <div class="card-head">
          <h3>quick actions</h3>
        </div>
        <div style="display: flex; flex-direction: column; gap: 10px;">
          <button class="btn btn-primary" onclick="openAddProductModal()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            add new product to catalog
          </button>
          <button class="btn btn-ghost" onclick="navigate('orders')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h8M8 17h5"/></svg>
            view & process pending orders
          </button>
          <button class="btn btn-ghost" onclick="navigate('deliveries')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="7" width="14" height="10" rx="1.5"/><path d="M15 10h4l3 3v4h-7z"/><circle cx="6" cy="19" r="1.8"/><circle cx="17.5" cy="19" r="1.8"/></svg>
            shiprocket delivery dispatches
          </button>
          <button class="btn btn-ghost" onclick="navigate('settings')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/></svg>
            check pincode serviceability
          </button>
        </div>
      </div>
    </div>

    <!-- Recent Orders Table -->
    <div class="section-card" style="margin-top: 24px;">
      <div class="card-head">
        <h3>recent orders</h3>
        <button class="btn btn-ghost btn-sm" onclick="navigate('orders')">view all</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Order</th>
              <th>Customer</th>
              <th>Amount</th>
              <th>Payment</th>
              <th>Status</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${
              orders.length
                ? orders
                    .map(
                      (o) => `
              <tr>
                <td><strong>#${escapeHtml(o.order_number)}</strong></td>
                <td>${escapeHtml(o.customer_name)}</td>
                <td class="mono"><strong>${CURRENCY(o.total_amount)}</strong></td>
                <td>${statusPill(o.payment_status)}</td>
                <td>${statusPill(o.order_status)}</td>
                <td>${fmtDate(o.created_at)}</td>
                <td>
                  <button class="btn btn-ghost btn-sm" onclick="openOrderDetail(${o.id})">inspect</button>
                </td>
              </tr>
            `,
                    )
                    .join("")
                : `
              <tr>
                <td colspan="7" style="text-align:center; padding:24px; color:var(--ink-soft);">No recent orders recorded.</td>
              </tr>
            `
            }
          </tbody>
        </table>
      </div>
    </div>

    <!-- Admin Activity Audit Log -->
    ${
      logs.length
        ? `
      <div class="section-card" style="margin-top: 24px;">
        <div class="card-head">
          <h3>security audit trail</h3>
          <span style="font-size:12px; color:var(--ink-soft);">authenticated admin activities</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Admin</th>
                <th>Operation / Action</th>
                <th>IP Address</th>
                <th>Timestamp</th>
              </tr>
            </thead>
            <tbody>
              ${logs
                .map(
                  (l) => `
                <tr>
                  <td><strong>${escapeHtml(l.admin_email)}</strong></td>
                  <td><span class="pill pill-clay">${escapeHtml(l.action)}</span></td>
                  <td class="mono">${escapeHtml(l.ip_address || "127.0.0.1")}</td>
                  <td>${fmtDateTime(l.created_at)}</td>
                </tr>
              `,
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </div>
    `
        : ""
    }
  `;

  // Draw chart
  initRevenueChart();
}

function initRevenueChart() {
  const ctx = document.getElementById("revenueChart");
  if (!ctx || typeof Chart === "undefined") return;

  if (overviewChart) {
    overviewChart.destroy();
  }

  const months = ["Apr", "May", "Jun", "Jul", "Aug", "Sep"];
  const revenueData = [48500, 62000, 58400, 79200, 91500, 114200];

  overviewChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: months,
      datasets: [
        {
          label: "Monthly Revenue (₹)",
          data: revenueData,
          borderColor: "#c3804c",
          backgroundColor: "rgba(195, 128, 76, 0.12)",
          fill: true,
          tension: 0.35,
          borderWidth: 2.5,
          pointBackgroundColor: "#7a4632",
          pointRadius: 4,
          pointHoverRadius: 6,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => ` ₹${ctx.parsed.y.toLocaleString("en-IN")}`,
          },
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: "#e3d3bd", borderDash: [4, 4] },
          ticks: {
            callback: (v) => "₹" + v / 1000 + "k",
            font: { family: "Jost", size: 11 },
          },
        },
        x: {
          grid: { display: false },
          ticks: { font: { family: "Jost", size: 12 } },
        },
      },
    },
  });
}

// ====================================================================
// 7. INVENTORY MANAGEMENT (In-Store & Online Channels)
// ====================================================================
const invState = {
  instore: {
    categoryFilter: "all",
    searchTerm: "",
    sortBy: "name",
    sortOrder: "asc",
  },
  online: {
    categoryFilter: "all",
    searchTerm: "",
    sortBy: "name",
    sortOrder: "asc",
  },
};

async function renderInstore() {
  renderInventory("instore");
}
async function renderOnline() {
  renderInventory("online");
}

async function renderInventory(mode = "online") {
  const content = document.getElementById("content");
  const actions = document.getElementById("topbarActions");

  actions.innerHTML = `
    <div id="apiStatusBadge" class="api-badge"></div>
    <button class="btn btn-ghost btn-sm" onclick="openTransferStockModal(null, '${mode === "instore" ? "instore" : "online"}')">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 16V4M7 4L3 8M7 4L11 8M17 8v12M17 20l4-4M17 20l-4-4"/></svg>
      transfer stock
    </button>
    <button class="btn btn-primary btn-sm" onclick="openAddProductModal()">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      add product
    </button>
  `;
  updateApiStatusBadge(isLiveApi);

  content.innerHTML = `<div class="empty-state"><h4>Loading ${mode === "instore" ? "in-store" : "online"} inventory…</h4></div>`;

  let products = [];
  try {
    const res = await apiFetch("/admin/products");
    products = res.products || [];
  } catch (err) {
    toast("Failed to load products: " + err.message, true);
    products = getFallbackDB().products;
  }

  const isInstore = mode === "instore";
  const state = invState[mode];

  // Channel Metrics Calculations
  let totalUnits = 0;
  let totalValuation = 0;
  let lowStockCount = 0;
  let outOfStockCount = 0;
  let activeSkuCount = 0;

  products.forEach((p) => {
    const qty = Number(
      isInstore
        ? (p.local_stock_quantity ?? 0)
        : (p.online_stock_quantity ?? p.stock_quantity ?? 0),
    );
    const price = Number(p.price || 0);
    totalUnits += qty;
    totalValuation += qty * price;
    if (qty === 0) outOfStockCount++;
    else if (qty <= 5) lowStockCount++;
    if (qty > 0) activeSkuCount++;
  });

  // Filter products
  let filtered = [...products];
  if (state.categoryFilter !== "all") {
    filtered = filtered.filter(
      (p) =>
        (p.category_slug || "").toLowerCase() === state.categoryFilter ||
        (p.category_name || "").toLowerCase().includes(state.categoryFilter),
    );
  }
  if (state.searchTerm) {
    const q = state.searchTerm.toLowerCase();
    filtered = filtered.filter(
      (p) =>
        (p.name || "").toLowerCase().includes(q) ||
        (p.sku || "").toLowerCase().includes(q) ||
        (p.tag || "").toLowerCase().includes(q),
    );
  }

  // Sort products
  filtered.sort((a, b) => {
    const qtyA = Number(
      isInstore
        ? (a.local_stock_quantity ?? 0)
        : (a.online_stock_quantity ?? a.stock_quantity ?? 0),
    );
    const qtyB = Number(
      isInstore
        ? (b.local_stock_quantity ?? 0)
        : (b.online_stock_quantity ?? b.stock_quantity ?? 0),
    );
    if (state.sortBy === "stock_asc") return qtyA - qtyB;
    if (state.sortBy === "stock_desc") return qtyB - qtyA;
    if (state.sortBy === "price_asc") return (a.price || 0) - (b.price || 0);
    if (state.sortBy === "price_desc") return (b.price || 0) - (a.price || 0);
    return (a.name || "").localeCompare(b.name || "");
  });

  content.innerHTML = `
    <!-- Channel Context Banner -->
    <div class="inv-channel-header">
      <div class="inv-channel-info">
        <div class="inv-channel-icon">
          ${
            isInstore
              ? `
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <path d="M3 9l1.5-5h15L21 9M3 9v10a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V9M3 9h18M9 13h6" />
            </svg>
          `
              : `
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <circle cx="12" cy="12" r="9" />
              <path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18" />
            </svg>
          `
          }
        </div>
        <div>
          <h3>${isInstore ? "studio walk-in inventory" : "online store inventory"}</h3>
          <p>${
            isInstore
              ? "Stock physically on display at the studio for in-person shoppers, workshops & local counter sales."
              : "Dedicated warehouse stock for web orders, Fastrr express checkout & Shiprocket courier dispatches."
          }</p>
        </div>
      </div>
      <div class="inv-channel-actions">
        <button class="btn btn-ghost btn-sm" onclick="navigate('${isInstore ? "online" : "instore"}')">
          switch to ${isInstore ? "online stock 🌐" : "in-store stock 🏪"}
        </button>
        <button class="btn btn-primary btn-sm" onclick="openTransferStockModal(null, '${mode}')">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 16V4M7 4L3 8M7 4L11 8M17 8v12M17 20l4-4M17 20l-4-4"/></svg>
          move units
        </button>
      </div>
    </div>

    <!-- Channel Dynamic KPIs -->
    <div class="kpi-row">
      <div class="kpi-card">
        <div class="kpi-label">${isInstore ? "in-store units" : "online web units"}</div>
        <div class="kpi-value">${totalUnits}</div>
        <div class="kpi-delta">${isInstore ? "physically available at studio" : "available for web buyers"}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">${isInstore ? "in-store valuation" : "online catalog value"}</div>
        <div class="kpi-value">${CURRENCY(totalValuation)}</div>
        <div class="kpi-delta">${isInstore ? "retail value at shop" : "total web merchandise"}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">low stock items</div>
        <div class="kpi-value" style="color: ${lowStockCount > 0 ? "var(--amber-dark)" : "var(--ink)"}">${lowStockCount}</div>
        <div class="kpi-delta">${isInstore ? "≤ 5 units in studio" : "≤ 5 units online"}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">${isInstore ? "out of stock at studio" : "fastrr checkout ready"}</div>
        <div class="kpi-value" style="color: ${isInstore && outOfStockCount > 0 ? "var(--danger)" : "var(--sage-dark)"}">
          ${isInstore ? outOfStockCount : activeSkuCount + " SKUs"}
        </div>
        <div class="kpi-delta">${isInstore ? "needs transfer or restock" : "instantly buyable online"}</div>
      </div>
    </div>

    <!-- Main Table Card -->
    <div class="section-card">
      <div class="card-head">
        <div class="chip-filter">
          <button class="chip ${state.categoryFilter === "all" ? "active" : ""}" onclick="setInvFilter('all', '${mode}')">All Items</button>
          <button class="chip ${state.categoryFilter === "pots" ? "active" : ""}" onclick="setInvFilter('pots', '${mode}')">Pots & Planters</button>
          <button class="chip ${state.categoryFilter === "candles" ? "active" : ""}" onclick="setInvFilter('candles', '${mode}')">Candles</button>
          <button class="chip ${state.categoryFilter === "plants" ? "active" : ""}" onclick="setInvFilter('plants', '${mode}')">Plants</button>
          <button class="chip ${state.categoryFilter === "decor" ? "active" : ""}" onclick="setInvFilter('decor', '${mode}')">Home Décor</button>
        </div>
        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
          <div class="search-wrap">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input class="search-input" placeholder="Search name, SKU, tag..." value="${state.searchTerm}" oninput="setInvSearch(this.value, '${mode}')" />
          </div>
          <select class="sort-select" onchange="setInvSort(this.value, '${mode}')">
            <option value="name" ${state.sortBy === "name" ? "selected" : ""}>Sort: Name (A-Z)</option>
            <option value="stock_asc" ${state.sortBy === "stock_asc" ? "selected" : ""}>Sort: Stock (Low to High)</option>
            <option value="stock_desc" ${state.sortBy === "stock_desc" ? "selected" : ""}>Sort: Stock (High to Low)</option>
            <option value="price_asc" ${state.sortBy === "price_asc" ? "selected" : ""}>Sort: Price (Low to High)</option>
            <option value="price_desc" ${state.sortBy === "price_desc" ? "selected" : ""}>Sort: Price (High to Low)</option>
          </select>
        </div>
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Item Details</th>
              <th>Category</th>
              <th>SKU Code</th>
              <th>Unit Price</th>
              <th>Weight</th>
              <th>${isInstore ? "In-Store Stock" : "Online Stock"}</th>
              <th>Other Channel</th>
              <th style="text-align: right;">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${
              filtered.length
                ? filtered
                    .map((p) => {
                      const currentStock = Number(
                        isInstore
                          ? (p.local_stock_quantity ?? 0)
                          : (p.online_stock_quantity ?? p.stock_quantity ?? 0),
                      );
                      const otherStock = Number(
                        isInstore
                          ? (p.online_stock_quantity ?? p.stock_quantity ?? 0)
                          : (p.local_stock_quantity ?? 0),
                      );
                      const isLow = currentStock > 0 && currentStock <= 5;
                      const isOut = currentStock === 0;
                      const img =
                        p.primary_image ||
                        (p.images && p.images[0]?.image_url) ||
                        "https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=120&q=80";

                      return `
                <tr>
                  <td>
                    <div style="display: flex; align-items: center; gap: 12px;">
                      <img src="${safeHttpsUrl(img) || "https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=120&q=80"}" alt="${escapeHtml(p.name)}" style="width: 44px; height: 44px; border-radius: 9px; object-fit: cover; border: 1px solid var(--border);" onerror="this.src='https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=120&q=80'" />
                      <div>
                        <strong>${escapeHtml(p.name)}</strong>
                        ${p.tag ? `<br><span style="font-size:11.5px; color:var(--clay-dark); font-weight:500;">${escapeHtml(p.tag)}</span>` : ""}
                      </div>
                    </div>
                  </td>
                  <td><span class="pill pill-clay">${escapeHtml(p.category_name || "Artisanal")}</span></td>
                  <td class="mono" style="font-size:13px; color:var(--ink-soft);">${escapeHtml(p.sku || "—")}</td>
                  <td class="mono"><strong>${CURRENCY(p.price)}</strong></td>
                  <td class="mono" style="font-size:13px;">${p.weight_grams ? p.weight_grams + " g" : "500 g"}</td>
                  <td>
                    <div class="stock-adjust-group">
                      <button class="stock-btn" title="Decrease ${isInstore ? "in-store" : "online"} stock by 1" onclick="quickStockChange(${p.id}, -1, '${mode}')">−</button>
                      <strong class="mono" style="min-width: 32px; text-align: center; font-size: 14.5px; color: ${isOut ? "var(--danger-dark)" : isLow ? "var(--amber-dark)" : "inherit"}">${currentStock}</strong>
                      <button class="stock-btn" title="Increase ${isInstore ? "in-store" : "online"} stock by 1" onclick="quickStockChange(${p.id}, 1, '${mode}')">+</button>
                      ${
                        isOut
                          ? `<span class="pill pill-danger" style="margin-left: 6px;">Out of Stock</span>`
                          : isLow
                            ? `<span class="pill pill-amber" style="margin-left: 6px;">Low Stock</span>`
                            : `<span class="pill pill-sage" style="margin-left: 6px;">In Stock</span>`
                      }
                    </div>
                  </td>
                  <td>
                    <span class="other-stock-tag" title="Stock in the alternative channel">
                      ${isInstore ? `🌐 Online: <strong>${otherStock}</strong>` : `🏪 In-Store: <strong>${otherStock}</strong>`}
                    </span>
                  </td>
                  <td style="text-align: right; white-space: nowrap;">
                    <button class="icon-btn" title="Transfer Stock Between Channels" onclick="openTransferStockModal(${p.id}, '${mode}')">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 16V4M7 4L3 8M7 4L11 8M17 8v12M17 20l4-4M17 20l-4-4"/></svg>
                    </button>
                    <button class="icon-btn" title="Edit Item Details" onclick="openEditProduct(${p.id})">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
                    </button>
                    <button class="icon-btn" title="Delete Item" onclick="confirmDeleteProduct(${Number(p.id)}, decodeURIComponent('${encodeURIComponent(p.name).replace(/'/g, "%27")}'))">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    </button>
                  </td>
                </tr>
              `;
                    })
                    .join("")
                : `
              <tr>
                <td colspan="8" style="text-align:center; padding:36px; color:var(--ink-soft);">
                  No items found matching the selected filter or search keyword.
                </td>
              </tr>
            `
            }
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function setInvFilter(cat, mode) {
  if (invState[mode]) invState[mode].categoryFilter = cat;
  renderInventory(mode);
}

function setInvSearch(val, mode) {
  if (invState[mode]) invState[mode].searchTerm = val;
  renderInventory(mode);
}

function setInvSort(val, mode) {
  if (invState[mode]) invState[mode].sortBy = val;
  renderInventory(mode);
}

async function quickStockChange(productId, delta, mode) {
  try {
    const res = await apiFetch(`/admin/products/${productId}`);
    const product =
      res.product ||
      (res.products && res.products.find((p) => p.id === productId));
    if (!product) throw new Error("Product not found");

    const stockField =
      mode === "instore" ? "local_stock_quantity" : "online_stock_quantity";
    const currentStock = Number(
      product[stockField] ?? (mode === "online" ? product.stock_quantity : 0),
    );
    const newStock = Math.max(0, currentStock + delta);

    await apiFetch(`/admin/products/${productId}`, {
      method: "PUT",
      body: { [stockField]: newStock },
    });

    toast(
      `${mode === "instore" ? "In-store" : "Online"} stock updated to ${newStock}`,
    );
    renderInventory(mode);
  } catch (err) {
    toast("Stock update failed: " + err.message, true);
  }
}

// Transfer Stock Modal (In-Store ⇄ Online)
async function openTransferStockModal(
  productId = null,
  defaultMode = "online",
) {
  let products = [];
  try {
    const res = await apiFetch("/admin/products");
    products = res.products || [];
  } catch (e) {
    products = getFallbackDB().products || [];
  }

  if (!products.length) {
    toast("No products available to transfer", true);
    return;
  }

  const selectedProduct = productId
    ? products.find((p) => p.id === productId)
    : products[0];
  const initialDirection =
    defaultMode === "instore" ? "instore_to_online" : "online_to_instore";

  openModal(`
    <button class="modal-close" onclick="closeModal()">✕</button>
    <h3>transfer inventory between channels</h3>
    <p style="font-size:13px; color:var(--ink-soft); margin-top:-10px; margin-bottom:16px;">
      Reallocate units between your physical studio in-store stock and online web store.
    </p>

    <form id="transferStockForm" onsubmit="handleStockTransfer(event)">
      <div class="field">
        <label>select product *</label>
        <select id="tfProductSelect" onchange="updateTransferModalPreview()" required>
          ${products
            .map(
              (p) => `
            <option value="${Number(p.id)}" ${selectedProduct && selectedProduct.id === p.id ? "selected" : ""}>
              ${escapeHtml(p.name)} (SKU: ${escapeHtml(p.sku || "—")})
            </option>
          `,
            )
            .join("")}
        </select>
      </div>

      <div class="field">
        <label>transfer direction *</label>
        <select id="tfDirection" onchange="updateTransferModalPreview()" required>
          <option value="online_to_instore" ${initialDirection === "online_to_instore" ? "selected" : ""}>
            Online Web Store ➔ Studio In-Store Stock
          </option>
          <option value="instore_to_online" ${initialDirection === "instore_to_online" ? "selected" : ""}>
            Studio In-Store Stock ➔ Online Web Store
          </option>
        </select>
      </div>

      <div id="transferVisualContainer"></div>

      <div class="field">
        <label>number of units to transfer *</label>
        <div style="display: flex; gap: 8px; align-items: center;">
          <input type="number" id="tfQty" min="1" value="1" required style="width: 100%;" oninput="updateTransferModalPreview()" />
        </div>
        <div class="quick-preset-chips" id="transferPresetChips"></div>
      </div>

      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" onclick="closeModal()">cancel</button>
        <button type="submit" class="btn btn-primary" id="tfSubmitBtn">complete transfer</button>
      </div>
    </form>
  `);

  window._allProductsCache = products;
  updateTransferModalPreview();
}

function updateTransferModalPreview() {
  const pId = parseInt(document.getElementById("tfProductSelect")?.value);
  const dir = document.getElementById("tfDirection")?.value;
  const qtyInput = document.getElementById("tfQty");
  const qty = parseInt(qtyInput?.value || 0);
  const container = document.getElementById("transferVisualContainer");
  const chips = document.getElementById("transferPresetChips");
  const submitBtn = document.getElementById("tfSubmitBtn");
  if (!container || !window._allProductsCache) return;

  const product = window._allProductsCache.find((p) => p.id === pId);
  if (!product) return;

  const onlineStock = Number(
    product.online_stock_quantity ?? product.stock_quantity ?? 0,
  );
  const instoreStock = Number(product.local_stock_quantity ?? 0);

  const isOnlineToInstore = dir === "online_to_instore";
  const sourceStock = isOnlineToInstore ? onlineStock : instoreStock;
  const destStock = isOnlineToInstore ? instoreStock : onlineStock;

  const newSource = Math.max(0, sourceStock - qty);
  const newDest = destStock + qty;
  const isValid = qty > 0 && qty <= sourceStock;

  if (qtyInput) {
    qtyInput.max = sourceStock;
  }

  container.innerHTML = `
    <div class="transfer-box">
      <div class="transfer-visual">
        <div class="transfer-node">
          <div class="transfer-node-label">${isOnlineToInstore ? "🌐 Online Store" : "🏪 Studio In-Store"} (Source)</div>
          <div class="transfer-node-val">${sourceStock}</div>
          <div style="font-size: 11.5px; color: ${isValid ? "var(--clay-dark)" : "var(--danger)"};">
            ➔ ${isValid ? newSource : "Insufficient"}
          </div>
        </div>
        <div class="transfer-arrow">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </div>
        <div class="transfer-node">
          <div class="transfer-node-label">${isOnlineToInstore ? "🏪 Studio In-Store" : "🌐 Online Store"} (Destination)</div>
          <div class="transfer-node-val">${destStock}</div>
          <div style="font-size: 11.5px; color: var(--sage-dark);">
            ➔ ${isValid ? newDest : destStock}
          </div>
        </div>
      </div>
      <div style="font-size: 12px; text-align: center; color: var(--ink-soft);">
        Available in source channel: <strong>${sourceStock} units</strong>
      </div>
    </div>
  `;

  if (chips) {
    chips.innerHTML = `
      <button type="button" class="preset-chip" onclick="setTransferQty(1)">1 unit</button>
      ${sourceStock >= 5 ? `<button type="button" class="preset-chip" onclick="setTransferQty(5)">5 units</button>` : ""}
      ${sourceStock >= 10 ? `<button type="button" class="preset-chip" onclick="setTransferQty(10)">10 units</button>` : ""}
      ${sourceStock > 1 ? `<button type="button" class="preset-chip" onclick="setTransferQty(Math.floor(${sourceStock} / 2))">Half (${Math.floor(sourceStock / 2)})</button>` : ""}
      <button type="button" class="preset-chip" onclick="setTransferQty(${sourceStock})">All Available (${sourceStock})</button>
    `;
  }

  if (submitBtn) {
    submitBtn.disabled = !isValid;
    submitBtn.textContent = isValid
      ? `Transfer ${qty} Units`
      : sourceStock === 0
        ? "No Units Available"
        : "Invalid Quantity";
  }
}

function setTransferQty(val) {
  const input = document.getElementById("tfQty");
  if (input) {
    input.value = Math.max(1, val);
    updateTransferModalPreview();
  }
}

async function handleStockTransfer(e) {
  e.preventDefault();
  const pId = parseInt(document.getElementById("tfProductSelect")?.value);
  const dir = document.getElementById("tfDirection")?.value;
  const qty = parseInt(document.getElementById("tfQty")?.value || 0);
  const btn = document.getElementById("tfSubmitBtn");

  if (!pId || qty <= 0) return;

  btn.disabled = true;
  btn.textContent = "Processing Transfer…";

  try {
    const res = await apiFetch(`/admin/products/${pId}`);
    const product =
      res.product || (res.products && res.products.find((p) => p.id === pId));
    if (!product) throw new Error("Product not found");

    const currentOnline = Number(
      product.online_stock_quantity ?? product.stock_quantity ?? 0,
    );
    const currentInstore = Number(product.local_stock_quantity ?? 0);

    let newOnline = currentOnline;
    let newInstore = currentInstore;

    if (dir === "online_to_instore") {
      if (currentOnline < qty)
        throw new Error(`Online stock only has ${currentOnline} units`);
      newOnline = currentOnline - qty;
      newInstore = currentInstore + qty;
    } else {
      if (currentInstore < qty)
        throw new Error(`In-store stock only has ${currentInstore} units`);
      newInstore = currentInstore - qty;
      newOnline = currentOnline + qty;
    }

    await apiFetch(`/admin/products/${pId}`, {
      method: "PUT",
      body: {
        online_stock_quantity: newOnline,
        local_stock_quantity: newInstore,
      },
    });

    toast(`Successfully transferred ${qty} units of ${product.name}!`);
    closeModal();
    renderInventory(currentPage === "instore" ? "instore" : "online");
  } catch (err) {
    toast("Transfer failed: " + err.message, true);
    btn.disabled = false;
    btn.textContent = "complete transfer";
  }
}

// Add Product Modal
function openAddProductModal() {
  openModal(`
    <button class="modal-close" onclick="closeModal()">✕</button>
    <h3>add new catalog product</h3>
    <form id="newProductForm" onsubmit="handleSaveNewProduct(event)">
      <div class="field">
        <label>product name *</label>
        <input id="npName" required placeholder="e.g. Terracotta Planter with Tray" />
      </div>
      <div class="form-row">
        <div class="field">
          <label>category *</label>
          <select id="npCategory" required>
            <option value="1">Pots & Planters</option>
            <option value="2">Candles</option>
            <option value="3">Plants</option>
            <option value="4">Home Décor</option>
          </select>
        </div>
        <div class="field">
          <label>SKU code *</label>
          <input id="npSku" required placeholder="e.g. POT-TER-099" />
        </div>
      </div>
      <div class="form-row">
        <div class="field">
          <label>price (₹) *</label>
          <input id="npPrice" type="number" step="0.01" required placeholder="1250" />
        </div>
        <div class="field">
          <label>compare price (₹)</label>
          <input id="npComparePrice" type="number" step="0.01" placeholder="Optional" />
        </div>
      </div>
      <div class="form-row">
        <div class="field">
          <label>online stock quantity *</label>
          <input id="npOnlineStock" type="number" min="0" required value="10" />
        </div>
        <div class="field">
          <label>in-store stock quantity *</label>
          <input id="npLocalStock" type="number" min="0" required value="0" />
        </div>
      </div>
      <div class="form-row">
        <div class="field">
          <label>weight in grams (for Shiprocket) *</label>
          <input id="npWeight" type="number" required value="800" placeholder="e.g. 800" />
        </div>
      </div>
      <div class="form-row">
        <div class="field">
          <label>dimensions</label>
          <input id="npDimensions" placeholder="e.g. 15cm H x 14cm W" />
        </div>
        <div class="field">
          <label>tag / badge</label>
          <input id="npTag" placeholder="e.g. Best Seller, Handcrafted" />
        </div>
      </div>
      <div class="field">
        <label>product photos and videos</label>
        <input id="npMedia" type="file" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm" multiple required />
        <small>Upload up to 12 photos or videos. Images: 10 MB each; videos: 50 MB each.</small>
      </div>
      <div class="field">
        <label>description</label>
        <textarea id="npDesc" placeholder="Craftsmanship details, materials, care notes..."></textarea>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" onclick="closeModal()">cancel</button>
        <button type="submit" class="btn btn-primary">save product</button>
      </div>
    </form>
  `);
  populateProductCategorySelects();
}

async function populateProductCategorySelects(selectedId = null) {
  try {
    const { categories = [] } = await apiFetch("/admin/categories");
    for (const id of ["npCategory", "epCategory"]) {
      const select = document.getElementById(id);
      if (!select) continue;
      const selected = selectedId ?? select.value;
      select.replaceChildren();
      categories.forEach((category) => {
        const option = document.createElement("option");
        option.value = category.id;
        option.textContent = category.name;
        option.selected = String(category.id) === String(selected);
        select.append(option);
      });
    }
  } catch (err) {
    console.warn("Could not load product categories", err);
  }
}

async function handleSaveNewProduct(e) {
  e.preventDefault();
  const mediaFiles = document.getElementById("npMedia").files;
  if (!Array.from(mediaFiles).some((file) => file.type.startsWith("image/"))) {
    toast("Upload at least one product image. You can add videos as well.", true);
    return;
  }
  if (mediaFiles.length && !isLiveApi) {
    toast("Connect the PHP API before creating a product with uploaded media.", true);
    return;
  }
  const btn = e.target.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.textContent = "Saving…";

  const payload = {
    name: document.getElementById("npName").value.trim(),
    category_id: parseInt(document.getElementById("npCategory").value),
    sku: document.getElementById("npSku").value.trim(),
    price: parseFloat(document.getElementById("npPrice").value),
    compare_at_price: document.getElementById("npComparePrice").value
      ? parseFloat(document.getElementById("npComparePrice").value)
      : null,
    online_stock_quantity: parseInt(
      document.getElementById("npOnlineStock").value,
    ),
    local_stock_quantity: parseInt(
      document.getElementById("npLocalStock").value,
    ),
    weight_grams: parseInt(document.getElementById("npWeight").value),
    dimensions: document.getElementById("npDimensions").value.trim() || null,
    tag: document.getElementById("npTag").value.trim() || null,
    description: document.getElementById("npDesc").value.trim() || null,
  };

  try {
    const result = await apiFetch("/admin/products", {
      method: "POST",
      body: payload,
    });
    try {
      await uploadProductMedia(result.product_id, mediaFiles);
    } catch (mediaError) {
      toast(`Product was created, but media upload failed: ${mediaError.message}`, true);
      closeModal();
      navigate(currentPage === "instore" ? "instore" : "online");
      return;
    }
    toast("Product created successfully");
    closeModal();
    navigate(currentPage === "instore" ? "instore" : "online");
  } catch (err) {
    toast("Failed to create product: " + err.message, true);
    btn.disabled = false;
    btn.textContent = "save product";
  }
}

// Edit Product Modal
async function openEditProduct(productId) {
  try {
    const res = await apiFetch(`/admin/products/${productId}`);
    const p =
      res.product ||
      (res.products && res.products.find((x) => x.id === productId));
    if (!p) throw new Error("Product details not found");

    openModal(`
      <button class="modal-close" onclick="closeModal()">✕</button>
      <h3>edit product: ${escapeHtml(p.name)}</h3>
      <form id="editProductForm" onsubmit="handleSaveEditProduct(event, ${p.id})">
        <div class="field">
          <label>product name *</label>
          <input id="epName" required value="${escapeHtml(p.name)}" />
        </div>
        <div class="form-row">
          <div class="field">
            <label>category *</label>
            <select id="epCategory" required>
              <option value="1" ${p.category_id == 1 ? "selected" : ""}>Pots & Planters</option>
              <option value="2" ${p.category_id == 2 ? "selected" : ""}>Candles</option>
              <option value="3" ${p.category_id == 3 ? "selected" : ""}>Plants</option>
              <option value="4" ${p.category_id == 4 ? "selected" : ""}>Home Décor</option>
            </select>
          </div>
          <div class="field">
            <label>SKU code *</label>
            <input id="epSku" required value="${escapeHtml(p.sku || "")}" />
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label>price (₹) *</label>
            <input id="epPrice" type="number" step="0.01" required value="${p.price}" />
          </div>
          <div class="field">
            <label>compare price (₹)</label>
            <input id="epComparePrice" type="number" step="0.01" value="${p.compare_at_price || ""}" />
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label>online stock quantity *</label>
            <input id="epOnlineStock" type="number" min="0" required value="${p.online_stock_quantity ?? p.stock_quantity ?? 0}" />
          </div>
          <div class="field">
            <label>in-store stock quantity *</label>
            <input id="epLocalStock" type="number" min="0" required value="${p.local_stock_quantity ?? 0}" />
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label>weight in grams (Shiprocket) *</label>
            <input id="epWeight" type="number" required value="${p.weight_grams || 500}" />
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label>dimensions</label>
            <input id="epDimensions" value="${escapeHtml(p.dimensions || "")}" />
          </div>
          <div class="field">
            <label>tag / badge</label>
            <input id="epTag" value="${escapeHtml(p.tag || "")}" />
          </div>
        </div>
        <div class="field">
          <label>add product photos or videos</label>
          <input id="epMedia" type="file" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm" multiple />
          <small>${(p.images || []).length} media item(s) currently attached. New uploads are added to the gallery.</small>
        </div>
        <div class="field">
          <label>description</label>
          <textarea id="epDesc">${escapeHtml(p.description || "")}</textarea>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" onclick="closeModal()">cancel</button>
          <button type="submit" class="btn btn-primary">save changes</button>
        </div>
      </form>
    `);
    populateProductCategorySelects(p.category_id);
  } catch (err) {
    toast("Failed to load product details: " + err.message, true);
  }
}

async function handleSaveEditProduct(e, productId) {
  e.preventDefault();
  const mediaFiles = document.getElementById("epMedia").files;
  if (mediaFiles.length && !isLiveApi) {
    toast("Connect the PHP API before uploading product media.", true);
    return;
  }
  const btn = e.target.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.textContent = "Updating…";

  const payload = {
    name: document.getElementById("epName").value.trim(),
    category_id: parseInt(document.getElementById("epCategory").value),
    sku: document.getElementById("epSku").value.trim(),
    price: parseFloat(document.getElementById("epPrice").value),
    compare_at_price: document.getElementById("epComparePrice").value
      ? parseFloat(document.getElementById("epComparePrice").value)
      : null,
    online_stock_quantity: parseInt(
      document.getElementById("epOnlineStock").value,
    ),
    local_stock_quantity: parseInt(
      document.getElementById("epLocalStock").value,
    ),
    weight_grams: parseInt(document.getElementById("epWeight").value),
    dimensions: document.getElementById("epDimensions").value.trim() || null,
    tag: document.getElementById("epTag").value.trim() || null,
    description: document.getElementById("epDesc").value.trim() || null,
  };

  try {
    await apiFetch(`/admin/products/${productId}`, {
      method: "PUT",
      body: payload,
    });
    try {
      await uploadProductMedia(productId, mediaFiles);
    } catch (mediaError) {
      toast(`Product was updated, but media upload failed: ${mediaError.message}`, true);
      closeModal();
      navigate(currentPage === "instore" ? "instore" : "online");
      return;
    }
    toast("Product updated successfully");
    closeModal();
    navigate(currentPage === "instore" ? "instore" : "online");
  } catch (err) {
    toast("Failed to update product: " + err.message, true);
    btn.disabled = false;
    btn.textContent = "save changes";
  }
}

async function uploadProductMedia(productId, files) {
  if (!files || files.length === 0) return;
  if (files.length > 12) throw new Error("Choose no more than 12 media files at a time.");
  const form = new FormData();
  Array.from(files).forEach((file) => form.append("media[]", file));
  await apiFetch(`/admin/products/${productId}/media`, { method: "POST", body: form });
}

function confirmDeleteProduct(id, name) {
  openModal(`
    <button class="modal-close" onclick="closeModal()">✕</button>
    <h3>delete product</h3>
    <p style="color:var(--ink-soft); margin-bottom: 20px;">
      Are you sure you want to delete <strong>${escapeHtml(name)}</strong>? This action cannot be undone.
    </p>
    <div class="modal-actions">
      <button class="btn btn-ghost" onclick="closeModal()">cancel</button>
      <button class="btn btn-danger" onclick="executeDeleteProduct(${id})">delete item</button>
    </div>
  `);
}

async function executeDeleteProduct(id) {
  try {
    await apiFetch(`/admin/products/${id}`, { method: "DELETE" });
    toast("Product deleted");
    closeModal();
    navigate(currentPage === "instore" ? "instore" : "online");
  } catch (err) {
    toast("Delete failed: " + err.message, true);
  }
}

// ====================================================================
// 8. ORDERS MANAGEMENT
// ====================================================================
let orderFilter = "all";
let orderSearch = "";

async function renderOrders() {
  const content = document.getElementById("content");
  const actions = document.getElementById("topbarActions");

  actions.innerHTML = `
    <div id="apiStatusBadge" class="api-badge"></div>
    <button class="btn btn-primary btn-sm" onclick="openNewOrderModal()">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      manual order
    </button>
    <button class="btn btn-ghost btn-sm" onclick="exportOrdersReport()">download orders CSV</button>
  `;
  updateApiStatusBadge(isLiveApi);

  content.innerHTML = `<div class="empty-state"><h4>Loading customer orders…</h4></div>`;

  let orders = [];
  try {
    const res = await apiFetch("/admin/orders");
    orders = res.orders || [];
  } catch (err) {
    toast("Failed to load orders: " + err.message, true);
    orders = getFallbackDB().orders;
  }

  // Filter
  let filtered = orders;
  if (orderFilter !== "all") {
    filtered = filtered.filter(
      (o) => (o.order_status || "").toLowerCase() === orderFilter.toLowerCase(),
    );
  }
  if (orderSearch) {
    const q = orderSearch.toLowerCase();
    filtered = filtered.filter(
      (o) =>
        (o.order_number || "").toLowerCase().includes(q) ||
        (o.customer_name || "").toLowerCase().includes(q) ||
        (o.customer_email || "").toLowerCase().includes(q) ||
        (o.customer_phone || "").toLowerCase().includes(q),
    );
  }

  content.innerHTML = `
    <div class="section-card">
      <div class="card-head">
        <div class="tabs">
          <button class="tab-btn ${orderFilter === "all" ? "active" : ""}" onclick="setOrderTab('all')">All Orders (${orders.length})</button>
          <button class="tab-btn ${orderFilter === "pending" ? "active" : ""}" onclick="setOrderTab('pending')">Pending</button>
          <button class="tab-btn ${orderFilter === "processing" ? "active" : ""}" onclick="setOrderTab('processing')">Processing</button>
          <button class="tab-btn ${orderFilter === "shipped" ? "active" : ""}" onclick="setOrderTab('shipped')">Shipped</button>
          <button class="tab-btn ${orderFilter === "delivered" ? "active" : ""}" onclick="setOrderTab('delivered')">Delivered</button>
          <button class="tab-btn ${orderFilter === "cancelled" ? "active" : ""}" onclick="setOrderTab('cancelled')">Cancelled</button>
        </div>
        <div class="search-wrap">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input class="search-input" placeholder="Search orders..." value="${orderSearch}" oninput="setOrderSearchInput(this.value)" />
        </div>
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Order Number</th>
              <th>Customer</th>
              <th>Items</th>
              <th>Total</th>
              <th>Payment</th>
              <th>Order Status</th>
              <th>Date</th>
              <th style="text-align: right;">Action</th>
            </tr>
          </thead>
          <tbody>
            ${
              filtered.length
                ? filtered
                    .map(
                      (o) => `
              <tr>
                <td><strong>#${escapeHtml(o.order_number)}</strong></td>
                <td>
                  <strong>${escapeHtml(o.customer_name)}</strong>
                  <br><span style="font-size:12px; color:var(--ink-soft);">${escapeHtml(o.customer_phone || o.customer_email)}</span>
                </td>
                <td class="mono">${o.items ? o.items.length : "—"}</td>
                <td class="mono"><strong>${CURRENCY(o.total_amount)}</strong></td>
                <td>${statusPill(o.payment_status)}</td>
                <td>${statusPill(o.order_status)}</td>
                <td>${fmtDate(o.created_at)}</td>
                <td style="text-align: right;">
                  <button class="btn btn-ghost btn-sm" onclick="openOrderDetail(${o.id})">view details</button>
                </td>
              </tr>
            `,
                    )
                    .join("")
                : `
              <tr>
                <td colspan="8" style="text-align:center; padding:36px; color:var(--ink-soft);">
                  No orders found in this category.
                </td>
              </tr>
            `
            }
          </tbody>
        </table>
      </div>
    </div>
  `;
}

async function exportOrdersReport() {
  try {
    const { orders = [] } = await apiFetch("/admin/orders");
    const columns = [
      "order_number",
      "customer_name",
      "customer_email",
      "customer_phone",
      "total_amount",
      "payment_method",
      "payment_status",
      "order_status",
      "created_at",
    ];
    const csv = [columns, ...orders.map((o) => columns.map((k) => o[k] ?? ""))]
      .map((row) =>
        row
          .map((value) => '"' + String(value).replace(/"/g, '""') + '"')
          .join(","),
      )
      .join("\r\n");
    const url = URL.createObjectURL(
      new Blob([csv], { type: "text/csv;charset=utf-8" }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = `tlgh-orders-${todayISO()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  } catch (err) {
    toast("Report export failed: " + err.message, true);
  }
}

function setOrderTab(tab) {
  orderFilter = tab;
  renderOrders();
}

function setOrderSearchInput(val) {
  orderSearch = val;
  renderOrders();
}

// Order Detail Modal
async function openOrderDetail(orderId) {
  try {
    const res = await apiFetch(`/admin/orders/${orderId}`);
    const ord = res.order;
    if (!ord) throw new Error("Order not found");

    const items = ord.items || [];

    openModal(`
      <button class="modal-close" onclick="closeModal()">✕</button>
      <div style="display: flex; align-items: baseline; gap: 10px; margin-bottom: 6px;">
        <h3>order #${escapeHtml(ord.order_number)}</h3>
        <span style="font-size:13px; color:var(--ink-soft);">${fmtDateTime(ord.created_at)}</span>
      </div>

      <!-- Customer & Delivery Address -->
      <div style="background:var(--cream); padding:14px; border-radius:12px; border:1px solid var(--border); margin:14px 0;">
        <strong style="font-size:14.5px;">${escapeHtml(ord.customer_name)}</strong>
        <div style="font-size:13px; color:var(--ink-soft); margin-top:2px;">
          ${escapeHtml(ord.customer_email)} · ${escapeHtml(ord.customer_phone)}
        </div>
        <div style="font-size:13px; margin-top:8px; line-height:1.4;">
          <strong>Shipping to:</strong> ${escapeHtml(ord.shipping_address || "Studio Store Pickup")}
        </div>
      </div>

      <!-- Items Table -->
      <h4 style="font-size:14px; margin: 16px 0 8px;">ordered items</h4>
      <div class="table-wrap" style="margin-bottom:14px;">
        <table>
          <thead>
            <tr>
              <th>Product</th>
              <th>Qty</th>
              <th>Price</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            ${
              items.length
                ? items
                    .map(
                      (item) => `
              <tr>
                <td><strong>${escapeHtml(item.product_name)}</strong><br><span class="mono" style="font-size:11.5px; color:var(--ink-soft);">${escapeHtml(item.sku || "")}</span></td>
                <td class="mono">${item.quantity}</td>
                <td class="mono">${CURRENCY(item.unit_price)}</td>
                <td class="mono"><strong>${CURRENCY(item.unit_price * item.quantity)}</strong></td>
              </tr>
            `,
                    )
                    .join("")
                : `
              <tr><td colspan="4">No items listed.</td></tr>
            `
            }
          </tbody>
        </table>
      </div>

      <!-- Order Financials -->
      <div style="text-align:right; font-size:13.5px; border-top:1px solid var(--border); padding-top:10px; margin-bottom:18px;">
        <div>Subtotal: <strong>${CURRENCY(ord.subtotal || ord.total_amount)}</strong></div>
        <div>Shipping: <strong>${CURRENCY(ord.shipping_cost || 0)}</strong></div>
        <div style="font-size:16px; margin-top:6px;">Total Amount: <strong style="color:var(--brown-deep);">${CURRENCY(ord.total_amount)}</strong></div>
      </div>

      <!-- Shiprocket Logistics Box -->
      <div style="background:#f4efe6; border:1px dashed var(--clay); border-radius:12px; padding:12px 14px; margin-bottom:18px;">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <strong style="color:var(--brown-deep); font-size:13.5px;">Shiprocket Logistics Tracking</strong>
          ${ord.shiprocket_awb ? `<button class="btn btn-ghost btn-sm" onclick="trackDelivery(${ord.id})">Track Live</button>` : ""}
        </div>
        <div style="font-size:13px; margin-top:6px; color:var(--ink);">
          Courier: <strong>${escapeHtml(ord.courier_name || "Not assigned yet")}</strong><br>
          AWB Code: <strong class="mono">${escapeHtml(ord.shiprocket_awb || "Pending generation")}</strong>
          ${safeHttpsUrl(ord.tracking_url) ? `<br><a href="${escapeHtml(safeHttpsUrl(ord.tracking_url))}" target="_blank" rel="noopener noreferrer" style="color:var(--clay-dark); text-decoration:underline;">Public Tracking URL</a>` : ""}
        </div>
      </div>

      <!-- Update Status Controls -->
      <form onsubmit="handleUpdateOrderStatus(event, ${ord.id})">
        <div class="form-row">
          <div class="field">
            <label>order status</label>
            <select id="uoOrderStatus">
              <option value="PENDING" ${ord.order_status === "PENDING" ? "selected" : ""}>PENDING</option>
              <option value="CONFIRMED" ${ord.order_status === "CONFIRMED" ? "selected" : ""}>CONFIRMED</option>
              <option value="PROCESSING" ${ord.order_status === "PROCESSING" ? "selected" : ""}>PROCESSING</option>
              <option value="SHIPPED" ${ord.order_status === "SHIPPED" ? "selected" : ""}>SHIPPED</option>
              <option value="OUT_FOR_DELIVERY" ${ord.order_status === "OUT_FOR_DELIVERY" ? "selected" : ""}>OUT_FOR_DELIVERY</option>
              <option value="DELIVERED" ${ord.order_status === "DELIVERED" ? "selected" : ""}>DELIVERED</option>
              <option value="CANCELLED" ${ord.order_status === "CANCELLED" ? "selected" : ""}>CANCELLED</option>
            </select>
          </div>
          <div class="field">
            <label>payment status</label>
            <select id="uoPaymentStatus" ${
              String(ord.payment_method || "").toUpperCase() === "FASTRR" ||
              currentUser?.role !== "OWNER" ||
              ["REFUND_PENDING", "REFUNDED"].includes(ord.payment_status)
                ? "disabled"
                : ""
            }>
              ${
                ["REFUND_PENDING", "REFUNDED"].includes(ord.payment_status)
                  ? `<option value="${escapeHtml(ord.payment_status)}" selected>${escapeHtml(ord.payment_status)}</option>`
                  : `
                    <option value="PENDING" ${ord.payment_status === "PENDING" ? "selected" : ""}>PENDING</option>
                    <option value="PAID" ${ord.payment_status === "PAID" ? "selected" : ""}>PAID</option>
                    <option value="FAILED" ${ord.payment_status === "FAILED" ? "selected" : ""}>FAILED</option>
                  `
              }
            </select>
            ${String(ord.payment_method || "").toUpperCase() === "FASTRR" ? `<small style="color:var(--ink-soft);">Payment state is verified by Shiprocket.</small>` : ""}
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label>courier partner</label>
            <input id="uoCourier" value="${escapeHtml(ord.courier_name || "")}" placeholder="e.g. Bluedart Express" />
          </div>
          <div class="field">
            <label>Shiprocket AWB number</label>
            <input id="uoAwb" value="${escapeHtml(ord.shiprocket_awb || "")}" placeholder="e.g. BLD-8941203" />
          </div>
        </div>
        <p style="font-size:12px; color:var(--ink-soft); margin-top:-6px;">
          Updating order status will automatically dispatch transactional email updates to <strong>${escapeHtml(ord.customer_email)}</strong>.
        </p>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" onclick="closeModal()">close</button>
          <button type="submit" class="btn btn-primary">save & update customer</button>
        </div>
      </form>
    `);
  } catch (err) {
    toast("Failed to load order details: " + err.message, true);
  }
}

async function handleUpdateOrderStatus(e, orderId) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.textContent = "Updating…";

  const orderStatus = document.getElementById("uoOrderStatus").value;
  const paymentStatusField = document.getElementById("uoPaymentStatus");
  const paymentStatus = paymentStatusField?.disabled ? null : paymentStatusField?.value;
  const courierName = document.getElementById("uoCourier").value.trim();
  const awb = document.getElementById("uoAwb").value.trim();

  try {
    await apiFetch(`/admin/orders/${orderId}/status`, {
      method: "PUT",
      body: {
        order_status: orderStatus,
        payment_status: paymentStatus,
        courier_name: courierName || null,
        shiprocket_awb: awb || null,
      },
    });

    toast("Order updated successfully & notification sent");
    closeModal();
    navigate(currentPage === "deliveries" ? "deliveries" : "orders");
  } catch (err) {
    toast("Failed to update status: " + err.message, true);
    btn.disabled = false;
    btn.textContent = "save & update customer";
  }
}

// Manual New Order Modal
function openNewOrderModal() {
  const products = getFallbackDB().products;

  openModal(`
    <button class="modal-close" onclick="closeModal()">✕</button>
    <h3>create manual / studio order</h3>
    <form id="manualOrderForm" onsubmit="handleCreateManualOrder(event)">
      <div class="form-row">
        <div class="field">
          <label>customer name *</label>
          <input id="moName" required placeholder="Full Name" />
        </div>
        <div class="field">
          <label>customer email *</label>
          <input id="moEmail" type="email" required placeholder="customer@example.com" />
        </div>
      </div>
      <div class="form-row">
        <div class="field">
          <label>customer phone *</label>
          <input id="moPhone" required placeholder="+91 98765 43210" />
        </div>
        <div class="field">
          <label>payment method</label>
          <select id="moPaymentMethod">
            <option value="ONLINE">Online / Razorpay / UPI</option>
            <option value="COD">Cash on Delivery (COD)</option>
          </select>
        </div>
      </div>
      <div class="field">
        <label>shipping address *</label>
        <textarea id="moAddress" required placeholder="Full street address, city, state, postal code"></textarea>
      </div>

      <h4 style="font-size:14px; margin: 16px 0 8px;">select product</h4>
      <div class="form-row">
        <div class="field">
          <label>item</label>
          <select id="moProduct">
            ${products
              .map(
                (p) => `
              <option value="${Number(p.id)}" data-price="${Number(p.price)}">${escapeHtml(p.name)} — ${CURRENCY(p.price)} (Stock: ${Number(p.stock_quantity)})</option>
            `,
              )
              .join("")}
          </select>
        </div>
        <div class="field">
          <label>quantity</label>
          <input id="moQty" type="number" value="1" min="1" required />
        </div>
      </div>

      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" onclick="closeModal()">cancel</button>
        <button type="submit" class="btn btn-primary">create order</button>
      </div>
    </form>
  `);
}

async function handleCreateManualOrder(e) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.textContent = "Creating order…";

  const pSelect = document.getElementById("moProduct");
  const productId = parseInt(pSelect.value);
  const qty = parseInt(document.getElementById("moQty").value);

  const payload = {
    customer_name: document.getElementById("moName").value.trim(),
    customer_email: document.getElementById("moEmail").value.trim(),
    customer_phone: document.getElementById("moPhone").value.trim(),
    payment_method: document.getElementById("moPaymentMethod").value,
    shipping_address: document.getElementById("moAddress").value.trim(),
    items: [{ product_id: productId, quantity: qty }],
  };

  try {
    await apiFetch("/admin/orders", {
      method: "POST",
      body: payload,
    });
    toast("Order created successfully");
    closeModal();
    navigate("orders");
  } catch (err) {
    toast("Failed to create order: " + err.message, true);
    btn.disabled = false;
    btn.textContent = "create order";
  }
}

// ====================================================================
// 9. DELIVERIES & SHIPROCKET LOGISTICS
// ====================================================================
let delFilter = "all";

async function renderDeliveries() {
  const content = document.getElementById("content");
  const actions = document.getElementById("topbarActions");

  actions.innerHTML = `<div id="apiStatusBadge" class="api-badge"></div>`;
  updateApiStatusBadge(isLiveApi);

  content.innerHTML = `<div class="empty-state"><h4>Loading logistics & shipments…</h4></div>`;

  let orders = [];
  try {
    const res = await apiFetch("/admin/orders");
    orders = res.orders || [];
  } catch (err) {
    orders = getFallbackDB().orders;
  }

  // Filter deliveries
  let filtered = orders;
  if (delFilter === "dispatch") {
    filtered = filtered.filter(
      (o) => o.order_status === "CONFIRMED" || o.order_status === "PROCESSING",
    );
  } else if (delFilter === "transit") {
    filtered = filtered.filter(
      (o) =>
        o.order_status === "SHIPPED" || o.order_status === "OUT_FOR_DELIVERY",
    );
  } else if (delFilter === "delivered") {
    filtered = filtered.filter((o) => o.order_status === "DELIVERED");
  }

  content.innerHTML = `
    <div class="section-card">
      <div class="card-head">
        <div class="tabs">
          <button class="tab-btn ${delFilter === "all" ? "active" : ""}" onclick="setDelFilter('all')">All Shipments (${orders.length})</button>
          <button class="tab-btn ${delFilter === "dispatch" ? "active" : ""}" onclick="setDelFilter('dispatch')">Ready for Dispatch</button>
          <button class="tab-btn ${delFilter === "transit" ? "active" : ""}" onclick="setDelFilter('transit')">In Transit</button>
          <button class="tab-btn ${delFilter === "delivered" ? "active" : ""}" onclick="setDelFilter('delivered')">Delivered</button>
        </div>
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Order</th>
              <th>Customer & Destination</th>
              <th>Assigned Courier</th>
              <th>Shiprocket AWB</th>
              <th>Status</th>
              <th style="text-align: right;">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${
              filtered.length
                ? filtered
                    .map(
                      (o) => `
              <tr>
                <td><strong>#${escapeHtml(o.order_number)}</strong></td>
                <td>
                  <strong>${escapeHtml(o.customer_name)}</strong>
                  <div style="font-size:12px; color:var(--ink-soft); max-width:260px; white-space:normal;">
                    ${escapeHtml(o.shipping_address || "Pickup")}
                  </div>
                </td>
                <td>
                  <strong>${escapeHtml(o.courier_name || "Shiprocket Partner")}</strong>
                </td>
                <td>
                  ${o.shiprocket_awb ? `<span class="mono" style="background:#eee8dd; padding:3px 7px; border-radius:4px;">${escapeHtml(o.shiprocket_awb)}</span>` : `<span style="color:var(--ink-soft); font-size:12px;">Unassigned</span>`}
                </td>
                <td>${statusPill(o.order_status)}</td>
                <td style="text-align: right;">
                  <button class="btn btn-ghost btn-sm" onclick="trackDelivery(${o.id})">track live</button>
                  <button class="btn btn-ghost btn-sm" onclick="openOrderDetail(${o.id})">update</button>
                </td>
              </tr>
            `,
                    )
                    .join("")
                : `
              <tr>
                <td colspan="6" style="text-align:center; padding:36px; color:var(--ink-soft);">No shipments in this category.</td>
              </tr>
            `
            }
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function setDelFilter(f) {
  delFilter = f;
  renderDeliveries();
}

// Live Track Modal with Shiprocket API Checkpoints
async function trackDelivery(orderId) {
  openModal(`
    <button class="modal-close" onclick="closeModal()">✕</button>
    <h3>Shiprocket Live Shipment Tracking</h3>
    <div style="padding:20px; text-align:center; color:var(--ink-soft);">
      Fetching real-time tracking data from Shiprocket…
    </div>
  `);

  try {
    const res = await apiFetch(`/admin/orders/${orderId}/track`);
    const track = res.tracking || {};
    const checkpoints = track.checkpoints || [
      {
        time: "Today 10:30 AM",
        location: "Delivery Hub",
        status: "Out for Delivery",
      },
      {
        time: "Yesterday 04:00 PM",
        location: "New Delhi Studio",
        status: "Picked Up by Courier",
      },
    ];

    openModal(`
      <button class="modal-close" onclick="closeModal()">✕</button>
      <h3>Shiprocket Live Tracking</h3>
      <div style="background:var(--cream); padding:12px 16px; border-radius:12px; border:1px solid var(--border); margin: 14px 0;">
        <div>AWB Number: <strong class="mono">${escapeHtml(res.awb_code || "Pending")}</strong></div>
        <div>Assigned Courier: <strong>${escapeHtml(track.courier_name || "Shiprocket Courier")}</strong></div>
        <div>Current Status: <strong style="color:var(--clay-dark);">${escapeHtml(track.current_status || "In Transit")}</strong></div>
      </div>

      <h4 style="font-size:14px; margin: 16px 0 8px;">tracking timeline</h4>
      <div class="tracking-timeline">
        ${checkpoints
          .map(
            (cp, idx) => `
          <div class="tracking-checkpoint ${idx === 0 ? "latest" : ""}">
            <div style="font-weight:600; font-size:13.5px; color:${idx === 0 ? "var(--clay-dark)" : "var(--ink)"};">${escapeHtml(cp.status)}</div>
            <div style="font-size:12.5px; color:var(--ink-soft);">${escapeHtml(cp.location || "Hub")} · ${escapeHtml(cp.time)}</div>
          </div>
        `,
          )
          .join("")}
      </div>

      ${
        res.tracking_url
          ? `
        <div style="margin-top:16px;">
          <a href="${escapeHtml(safeHttpsUrl(res.tracking_url))}" target="_blank" rel="noopener noreferrer" class="btn btn-primary" style="width:100%; justify-content:center;">
            Open Public Tracking Portal
          </a>
        </div>
      `
          : ""
      }
    `);
  } catch (err) {
    openModal(`
      <button class="modal-close" onclick="closeModal()">✕</button>
      <h3>Tracking Info</h3>
      <p style="color:var(--danger); margin:16px 0;">
        Shiprocket tracking unavailable: ${escapeHtml(err.message)}
      </p>
      <div class="modal-actions">
        <button class="btn btn-ghost" onclick="closeModal()">Close</button>
      </div>
    `);
  }
}

// ====================================================================
// 10. PAYMENTS & REFUNDS
// ====================================================================
async function renderPayments() {
  const content = document.getElementById("content");
  const actions = document.getElementById("topbarActions");

  actions.innerHTML = `<div id="apiStatusBadge" class="api-badge"></div>`;
  updateApiStatusBadge(isLiveApi);

  content.innerHTML = `<div class="empty-state"><h4>Loading payments…</h4></div>`;

  let orders = [];
  try {
    const res = await apiFetch("/admin/orders");
    orders = res.orders || [];
  } catch (err) {
    orders = getFallbackDB().orders;
  }

  content.innerHTML = `
    <div class="section-card">
      <div class="card-head">
        <h3>transactions & payment records</h3>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Order #</th>
              <th>Customer</th>
              <th>Amount</th>
              <th>Method</th>
              <th>Status</th>
              <th>Date</th>
              <th style="text-align: right;">Action</th>
            </tr>
          </thead>
          <tbody>
            ${orders
              .map(
                (o) => `
              <tr>
                <td><strong>#${escapeHtml(o.order_number)}</strong></td>
                <td>${escapeHtml(o.customer_name)}</td>
                <td class="mono"><strong>${CURRENCY(o.total_amount)}</strong></td>
                <td><span class="pill pill-clay">${escapeHtml(o.payment_method || "ONLINE")}</span></td>
                <td>${statusPill(o.payment_status)}</td>
                <td>${fmtDate(o.created_at)}</td>
                <td style="text-align: right;">
                  ${
                    o.payment_status === "PAID" &&
                    String(o.payment_method || "").toUpperCase() === "FASTRR" &&
                    currentUser?.role === "OWNER"
                      ? `
                    <button class="btn btn-ghost btn-sm" onclick="openRefundModal(${o.id}, ${Number(o.total_amount) || 0})">request refund</button>
                  `
                      : o.payment_status !== "PAID" &&
                          !["REFUNDED", "REFUND_PENDING", "FAILED"].includes(o.payment_status) &&
                          String(o.payment_method || "").toUpperCase() !== "FASTRR" &&
                          currentUser?.role === "OWNER"
                        ? `
                    <button class="btn btn-primary btn-sm" onclick="markPaymentPaid(${o.id})">mark paid</button>
                  `
                        : `<span style="color:var(--ink-soft);font-size:12px;">—</span>`
                  }
                </td>
              </tr>
            `,
              )
              .join("")}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

async function markPaymentPaid(orderId) {
  try {
    await apiFetch(`/admin/orders/${orderId}/status`, {
      method: "PUT",
      body: { payment_status: "PAID" },
    });
    toast("Payment marked as PAID");
    renderPayments();
  } catch (err) {
    toast("Update failed: " + err.message, true);
  }
}

async function renderRefunds() {
  const content = document.getElementById("content");
  content.innerHTML = `<div class="empty-state"><h4>Loading refunds…</h4></div>`;

  let orders = [];
  try {
    const res = await apiFetch("/admin/orders");
    orders = (res.orders || []).filter((o) =>
      ["REFUNDED", "REFUND_PENDING"].includes(o.payment_status),
    );
  } catch (err) {
    orders = (getFallbackDB().orders || []).filter(
      (o) => ["REFUNDED", "REFUND_PENDING"].includes(o.payment_status),
    );
  }

  content.innerHTML = `
    <div class="section-card">
      <div class="card-head">
        <h3>refunded orders</h3>
        ${currentUser?.role === "OWNER" ? `<button class="btn btn-ghost btn-sm" onclick="syncFastrrRefunds()">sync Shiprocket refunds</button>` : ""}
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Order #</th>
              <th>Customer</th>
              <th>Refund Amount</th>
              <th>Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${
              orders.length
                ? orders
                    .map(
                      (o) => `
              <tr>
                <td><strong>#${escapeHtml(o.order_number)}</strong></td>
                <td>${escapeHtml(o.customer_name)}</td>
                <td class="mono"><strong>${CURRENCY(o.total_amount)}</strong></td>
                <td>${fmtDate(o.created_at)}</td>
                <td>${statusPill(o.payment_status)}</td>
              </tr>
            `,
                    )
                    .join("")
                : `
              <tr>
                <td colspan="5" style="text-align:center; padding:36px; color:var(--ink-soft);">
                  No refunded transactions on record.
                </td>
              </tr>
            `
            }
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function openRefundModal(orderId, amount) {
  openModal(`
    <button class="modal-close" onclick="closeModal()">✕</button>
    <h3>process refund</h3>
    <p style="color:var(--ink-soft); margin-bottom:16px;">
      Request a full refund of <strong>${CURRENCY(amount)}</strong> through Shiprocket Checkout. The order stays refund pending until Shiprocket confirms it.
    </p>
    <div class="field">
      <label>refund reason</label>
      <input id="refReason" placeholder="e.g. Customer request, Damaged in transit" />
    </div>
    <div class="modal-actions">
      <button class="btn btn-ghost" onclick="closeModal()">cancel</button>
      <button class="btn btn-danger" onclick="executeRefund(${orderId}, ${Number(amount) || 0})">request refund</button>
    </div>
  `);
}

async function executeRefund(orderId, amount) {
  const reason = document.getElementById("refReason").value.trim();
  try {
    const result = await apiFetch(`/admin/orders/${orderId}/refund`, {
      method: "POST",
      body: { amount, reason },
    });
    toast(result.message || "Shiprocket refund request submitted");
    closeModal();
    navigate("payments");
  } catch (err) {
    toast("Refund failed: " + err.message, true);
  }
}

async function syncFastrrRefunds() {
  try {
    const result = await apiFetch("/admin/fastrr/refunds/sync", { method: "POST" });
    toast(result.message || `Updated ${result.updated || 0} refund statuses`);
    navigate("refunds");
  } catch (err) {
    toast("Refund sync failed: " + err.message, true);
  }
}

// ====================================================================
// 11. SETTINGS, SECURITY & STAFF ACCOUNTS
// ====================================================================
async function renderSettings() {
  const content = document.getElementById("content");
  const actions = document.getElementById("topbarActions");

  actions.innerHTML = `<div id="apiStatusBadge" class="api-badge"></div>`;
  updateApiStatusBadge(isLiveApi);

  content.innerHTML = `<div class="empty-state"><h4>Loading settings…</h4></div>`;

  let staffList = [];
  try {
    const res = await apiFetch("/admin/staff");
    staffList = res.staff || [];
  } catch (err) {
    staffList = getFallbackDB().staff;
  }

  content.innerHTML = `
    <!-- 1. Change Admin Password (JWT Enforced + Security Email) -->
    <div class="section-card">
      <div class="card-head">
        <h3>admin security & password</h3>
        <span class="pill pill-clay">JWT Auth & Email Alerts Active</span>
      </div>
      <p style="color:var(--ink-soft); font-size:13.5px; margin-bottom:14px;">
        Updating your password will immediately enforce new bcrypt hash verification and dispatch a security alert to your registered admin email address (<strong>${currentUser?.email || "owner@thelittlegreenhouse.com"}</strong>).
      </p>
      <form id="changePasswordForm" onsubmit="handleChangePassword(event)">
        <div class="form-row">
          <div class="field">
            <label>current password *</label>
            <input type="password" id="currentPass" required placeholder="enter current password" />
          </div>
          <div class="field">
            <label>new password (min. 8 characters) *</label>
            <input type="password" id="newPass" required placeholder="enter new strong password" minlength="8" />
          </div>
        </div>
        <button type="submit" class="btn btn-primary btn-sm">update password & send email alert</button>
      </form>
    </div>

    <!-- 2. Staff Management (Owner JWT Enforced) -->
    <div class="section-card">
      <div class="card-head">
        <h3>staff & team accounts</h3>
        <span style="font-size:12px; color:var(--ink-soft);">owner access only</span>
      </div>
      <p style="color:var(--ink-soft); font-size:13.5px; margin-bottom:14px;">
        Give studio apprentices and dispatch assistants individual logins. All actions are logged under their email address.
      </p>
      
      <div class="bank-list" id="staffContainer">
        ${staffList
          .map(
            (s) => `
          <div class="bank-row">
            <div>
            <strong style="font-size:14px;">${escapeHtml(s?.full_name || s?.name || "Staff member")}</strong>
              <div style="font-size:12.5px; color:var(--ink-soft);">${escapeHtml(s.email)} · <span class="pill pill-clay" style="font-size:10px; padding:2px 6px;">${escapeHtml(s.role)}</span></div>
            </div>
            ${
              s.role !== "OWNER" && currentUser?.role === "OWNER"
                ? `
              <button class="icon-btn" title="Remove staff login" onclick="confirmDeleteStaff(${Number(s.id)}, decodeURIComponent('${encodeURIComponent(s.email).replace(/'/g, "%27")}'))">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6h14Z"/></svg>
              </button>
            `
                : ""
            }
          </div>
        `,
          )
          .join("")}
      </div>

      <div style="margin-top:20px; border-top:1px solid var(--border); padding-top:16px;">
        <h4 style="font-size:14px; margin-bottom:12px;">add new staff member</h4>
        <form id="addStaffForm" onsubmit="handleAddStaff(event)">
          <div class="form-row">
            <div class="field">
              <label>staff full name *</label>
              <input id="stfName" required placeholder="e.g. Priya Nair" />
            </div>
            <div class="field">
              <label>staff email address *</label>
              <input type="email" id="stfEmail" required placeholder="priya@thelittlegreenhouse.com" />
            </div>
          </div>
          <div class="form-row">
            <div class="field">
              <label>role</label>
              <select id="stfRole">
                <option value="STAFF">STAFF (Studio & Orders)</option>
                <option value="OWNER">OWNER (Full Permissions)</option>
              </select>
            </div>
            <div class="field">
              <label>temporary password *</label>
              <input type="password" id="stfPass" required placeholder="set temporary password" minlength="6" />
            </div>
          </div>
          <button type="submit" class="btn btn-ghost btn-sm">add staff member</button>
        </form>
      </div>
    </div>

    <!-- Catalog categories -->
    <div class="section-card">
      <div class="card-head"><h3>product categories</h3></div>
      <p style="color:var(--ink-soft);font-size:13.5px;margin-bottom:14px">Create a category for products. Use a short URL slug such as “planters”.</p>
      <form onsubmit="handleCreateCategory(event)">
        <div class="form-row"><div class="field"><label>category name *</label><input id="newCategoryName" required maxlength="100"></div><div class="field"><label>URL slug</label><input id="newCategorySlug" maxlength="100" placeholder="created from name if blank"></div></div>
        <div class="field"><label>description</label><input id="newCategoryDescription" maxlength="500"></div>
        <button type="submit" class="btn btn-primary btn-sm">create category</button>
      </form><div id="categoryList" style="margin-top:14px"></div>
    </div>

    <!-- Newsletter Subscribers -->
    <div class="section-card">
      <div class="card-head">
        <h3>newsletter & studio email subscribers</h3>
        <div style="display:flex; gap:8px;">
          <button class="btn btn-ghost btn-sm" onclick="copySubscribersList()">copy all emails</button>
          <button class="btn btn-ghost btn-sm" onclick="exportSubscribersCSV()">export csv</button>
        </div>
      </div>
      <p style="color:var(--ink-soft); font-size:13.5px; margin-bottom:14px;">
        Subscribers who have opted in to receive small-batch drop announcements, kiln notes, and care rituals.
      </p>
      <div id="subscriberListContainer">
        <div style="color:var(--ink-soft); font-size:13px;">Loading subscribers…</div>
      </div>
    </div>

    ${currentUser?.role === "OWNER" ? `
    <!-- Public page photography (owner-only API) -->
    <div class="section-card">
      <div class="card-head"><h3>public page photos</h3><span class="pill pill-sage">owner only</span></div>
      <p style="color:var(--ink-soft);font-size:13.5px;margin-bottom:14px">Upload a photo for the home, our story, or visit page. JPEG, PNG, WebP and GIF are supported (up to 10 MB).</p>
      <div class="form-row">
        ${[
          ["home_hero", "home page hero"],
          ["home_story", "home page story section"],
          ["about_hero", "our story hero"],
          ["visit_hero", "visit us hero"],
        ].map(([slot, label]) => `
          <div class="field">
            <label for="sitePhoto-${slot}">${label}</label>
            <img id="sitePhotoPreview-${slot}" alt="${label} preview" hidden style="display:none;width:100%;max-height:180px;object-fit:cover;border-radius:12px;margin:8px 0;" />
            <input id="sitePhoto-${slot}" type="file" accept="image/jpeg,image/png,image/webp,image/gif" onchange="uploadSitePhoto('${slot}', this)" />
          </div>
        `).join("")}
      </div>
      <div id="sitePhotoStatus" role="status" style="color:var(--ink-soft);font-size:13px;margin-top:8px"></div>
    </div>` : ""}

    <!-- 3. Shiprocket Logistics Integration & Serviceability -->
    <div class="section-card">
      <div class="card-head">
        <h3>Shiprocket logistics & shipping</h3>
        <span class="pill pill-sage">Integration Active</span>
      </div>
      <p style="color:var(--ink-soft); font-size:13.5px; margin-bottom:14px;">
        Pickup Hub: <strong>TLGH Studio Delhi (Pincode: 110001)</strong>. Check live courier serviceability and estimated delivery times for customer pincodes.
      </p>
      <div style="display:flex; gap:10px; align-items:flex-end; max-width:460px;">
        <div class="field" style="flex:1; margin-bottom:0;">
          <label>check destination pincode</label>
          <input id="srvPincode" placeholder="e.g. 560038, 400050, 110001" maxlength="6" />
        </div>
        <button class="btn btn-primary btn-sm" style="height:42px;" onclick="checkServiceability()">check courier</button>
      </div>
      <div id="serviceabilityResult" style="margin-top:14px;"></div>
    </div>

    <!-- 4. Web Server & API Diagnostics -->
    <div class="section-card">
      <div class="card-head">
        <h3>web server & REST API diagnostics</h3>
      </div>
      <p style="color:var(--ink-soft); font-size:13.5px; margin-bottom:14px;">
        The admin panel connects via REST to the PHP backend at <code>${escapeHtml(getApiBase())}</code>.
      </p>
      <div class="form-row">
        <div class="field">
          <label>API base URL</label>
          <input id="cfgApiBase" value="${escapeHtml(getApiBase())}" />
        </div>
        <div class="field" style="display:flex; align-items:flex-end;">
          <button class="btn btn-ghost" onclick="saveApiBase()">save URL & test health</button>
        </div>
      </div>
      <div id="healthResult"></div>
    </div>
  `;
  loadAdminCategories();
  loadAdminSubscribers();
  if (currentUser?.role === "OWNER") loadAdminSitePhotos();
}

async function loadAdminSitePhotos() {
  try {
    const { media = {} } = await apiFetch("/admin/site-media");
    Object.entries(media).forEach(([slot, url]) => {
      const preview = document.getElementById(`sitePhotoPreview-${slot}`);
      if (preview && url) { preview.src = url; preview.hidden = false; preview.style.display = "block"; }
    });
  } catch (err) {
    const status = document.getElementById("sitePhotoStatus");
    if (status) status.textContent = err.message;
  }
}

async function uploadSitePhoto(slot, input) {
  const file = input?.files?.[0];
  if (!file) return;
  const status = document.getElementById("sitePhotoStatus");
  if (status) status.textContent = "Uploading photo…";
  const form = new FormData();
  form.append("slot", slot);
  form.append("photo", file);
  try {
    const result = await apiFetch("/admin/site-media", { method: "POST", body: form });
    const preview = document.getElementById(`sitePhotoPreview-${slot}`);
    if (preview) { preview.src = result.image_url + `?v=${Date.now()}`; preview.hidden = false; preview.style.display = "block"; }
    if (status) status.textContent = "Photo saved. Refresh the public page to see the change.";
    input.value = "";
  } catch (err) {
    if (status) status.textContent = err.message;
  }
}

async function loadAdminSubscribers() {
  const container = document.getElementById("subscriberListContainer");
  if (!container) return;

  try {
    const res = await apiFetch("/admin/subscribers");
    const subscribers = res.subscribers || [];
    window._subscribersCache = subscribers;

    if (!subscribers.length) {
      container.innerHTML = `<div style="padding:16px; text-align:center; color:var(--ink-soft);">No subscribers registered yet.</div>`;
      return;
    }

    container.innerHTML = `
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Subscriber Email</th>
              <th>Joined Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${subscribers
              .map(
                (s) => `
              <tr>
                <td><strong>${escapeHtml(s.email)}</strong></td>
                <td style="font-size:13px;">${fmtDateTime(s.created_at)}</td>
                <td>
                  ${s.is_active ? `<span class="pill pill-sage">Active Subscriber</span>` : `<span class="pill pill-gray">Unsubscribed</span>`}
                </td>
              </tr>
            `,
              )
              .join("")}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div style="color:var(--ink-soft); font-size:13px;">Subscribers list: ${escapeHtml(err.message)}</div>`;
  }
}

function copySubscribersList() {
  const list = (window._subscribersCache || [])
    .filter((s) => s.is_active)
    .map((s) => s.email);
  if (!list.length) {
    toast("No active subscribers to copy", true);
    return;
  }
  navigator.clipboard
    .writeText(list.join(", "))
    .then(() => {
      toast(`Copied ${list.length} subscriber emails to clipboard!`);
    })
    .catch(() => {
      toast("Clipboard access denied", true);
    });
}

function exportSubscribersCSV() {
  const list = window._subscribersCache || [];
  if (!list.length) {
    toast("No subscribers to export", true);
    return;
  }
  const rows = [["Email", "Active", "Joined At"]];
  list.forEach((s) =>
    rows.push([s.email, s.is_active ? "Yes" : "No", s.created_at]),
  );
  const csvContent =
    "data:text/csv;charset=utf-8," + rows.map((e) => e.join(",")).join("\n");
  const link = document.createElement("a");
  link.setAttribute("href", encodeURI(csvContent));
  link.setAttribute("download", `tlgh_subscribers_${todayISO()}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  toast("Subscribers CSV exported!");
}

async function loadAdminCategories() {
  const node = document.getElementById("categoryList");
  if (!node) return;
  try {
    const res = await apiFetch("/admin/categories");
    node.replaceChildren();
    for (const category of res.categories || []) {
      const row = document.createElement("div");
      row.style.cssText = "padding:7px 0;border-bottom:1px solid var(--border)";
      const name = document.createElement("strong");
      name.textContent = category.name;
      const slug = document.createElement("span");
      slug.style.color = "var(--ink-soft)";
      slug.textContent = " /" + category.slug;
      row.append(name, slug);
      node.append(row);
    }
    if (!node.childElementCount) node.textContent = "No categories yet.";
  } catch (err) {
    node.textContent = "Could not load categories: " + err.message;
  }
}

async function handleCreateCategory(event) {
  event.preventDefault();
  const name = document.getElementById("newCategoryName").value.trim();
  const slug = document.getElementById("newCategorySlug").value.trim();
  const description = document
    .getElementById("newCategoryDescription")
    .value.trim();
  try {
    await apiFetch("/admin/categories", {
      method: "POST",
      body: { name, slug, description },
    });
    event.currentTarget.reset();
    toast("Category created");
    await loadAdminCategories();
  } catch (err) {
    toast(err.message, true);
  }
}

// Password Change Submit
async function handleChangePassword(e) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.textContent = "Updating…";

  const currentPassword = document.getElementById("currentPass").value;
  const newPassword = document.getElementById("newPass").value;

  try {
    const res = await apiFetch("/auth/admin/change-password", {
      method: "POST",
      body: { current_password: currentPassword, new_password: newPassword },
    });

    toast(
      res.message ||
        "Password updated successfully. Security confirmation email sent.",
    );
    document.getElementById("changePasswordForm").reset();
  } catch (err) {
    toast("Password update failed: " + err.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = "update password & send email alert";
  }
}

// Add Staff Submit
async function handleAddStaff(e) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.textContent = "Adding…";

  const fullName = document.getElementById("stfName").value.trim();
  const email = document.getElementById("stfEmail").value.trim();
  const role = document.getElementById("stfRole").value;
  const password = document.getElementById("stfPass").value;

  try {
    await apiFetch("/admin/staff", {
      method: "POST",
      body: { full_name: fullName, email, role, password },
    });

    toast(`Staff member ${fullName} created successfully.`);
    renderSettings();
  } catch (err) {
    toast("Failed to add staff: " + err.message, true);
    btn.disabled = false;
    btn.textContent = "add staff member";
  }
}

function confirmDeleteStaff(id, email) {
  openModal(`
    <button class="modal-close" onclick="closeModal()">✕</button>
    <h3>remove staff account</h3>
    <p style="color:var(--ink-soft); margin-bottom:18px;">
      Revoke access for <strong>${escapeHtml(email)}</strong>? They will no longer be able to log in to this admin portal.
    </p>
    <div class="modal-actions">
      <button class="btn btn-ghost" onclick="closeModal()">cancel</button>
      <button class="btn btn-danger" onclick="executeDeleteStaff(${id})">remove account</button>
    </div>
  `);
}

async function executeDeleteStaff(id) {
  try {
    await apiFetch(`/admin/staff/${id}`, { method: "DELETE" });
    toast("Staff access revoked.");
    closeModal();
    renderSettings();
  } catch (err) {
    toast("Failed: " + err.message, true);
  }
}

// Shiprocket Pincode Check
async function checkServiceability() {
  const pin = (document.getElementById("srvPincode").value || "").trim();
  const resEl = document.getElementById("serviceabilityResult");

  if (!pin || pin.length < 6) {
    toast("Please enter a valid 6-digit postal code", true);
    return;
  }

  resEl.innerHTML = `<span style="font-size:13px; color:var(--ink-soft);">Querying Shiprocket API…</span>`;

  try {
    const res = await apiFetch(
      `/shiprocket/serviceability?delivery_pincode=${pin}`,
    );
    const couriers = res?.data?.available_courier_companies || [];

    if (couriers.length) {
      resEl.innerHTML = `
        <div style="background:var(--cream); padding:12px; border-radius:10px; border:1px solid var(--border);">
          <strong style="color:var(--sage-dark);">✓ Deliverable to ${escapeHtml(pin)}</strong>
          <div style="font-size:12.5px; margin-top:6px; color:var(--ink-soft);">
            Available couriers: ${couriers.map((c) => `<strong>${escapeHtml(c.courier_name)}</strong> (ETD: ${escapeHtml(c.etd || "3-4 days")})`).join(", ")}
          </div>
        </div>
      `;
    } else {
      resEl.innerHTML = `
        <div style="background:#fdf2f2; padding:12px; border-radius:10px; border:1px solid #f5c6cb; color:#721c24; font-size:13px;">
          Pincode ${escapeHtml(pin)} is outside direct standard courier serviceability or remote location.
        </div>
      `;
    }
  } catch (err) {
    resEl.innerHTML = `
      <div style="font-size:13px; color:var(--danger);">
        Serviceability check failed: ${escapeHtml(err.message)}
      </div>
    `;
  }
}

function saveApiBase() {
  const url = document.getElementById("cfgApiBase").value.trim();
  localStorage.setItem(API_BASE_KEY, url);
  toast("API endpoint updated. Testing health…");
  checkApiConnection().then((online) => {
    const result = document.getElementById("healthResult");
    if (!result) return;
    result.innerHTML = online
      ? `<div style="margin-top:10px; color:var(--sage-dark); font-size:13px;">✓ API and database are healthy.</div>`
      : isLiveApi
        ? `<div style="margin-top:10px; color:var(--danger); font-size:13px;">⚠ API responded, but the MySQL database is unavailable. Check DB_HOST and network access from the PHP server.</div>`
        : `<div style="margin-top:10px; color:var(--amber-dark); font-size:13px;">⚠ Server unreachable at this URL. Check the API base URL and PHP routing.</div>`;
  });
}

// ====================================================================
// 12. App Initialization
// ====================================================================
document.addEventListener("DOMContentLoaded", () => {
  // Wire login form
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", handleLogin);
  }

  // Wire logout
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", logout);
  }

  // Wire nav items
  document
    .querySelectorAll(".nav-item[data-page], .bottom-nav button[data-page]")
    .forEach((btn) => {
      btn.addEventListener("click", () => navigate(btn.dataset.page));
    });

  // Mobile menu
  const mobileMenuBtn = document.getElementById("mobileMenuBtn");
  if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener("click", () => {
      document.getElementById("sidebar").classList.add("mobile-open");
      document.getElementById("scrim").classList.add("show");
    });
  }

  const scrim = document.getElementById("scrim");
  if (scrim) {
    scrim.addEventListener("click", closeMobileNav);
  }

  // Modal overlay click to dismiss
  const overlay = document.getElementById("overlay");
  if (overlay) {
    overlay.addEventListener("click", (e) => {
      if (e.target.id === "overlay") closeModal();
    });
  }

  // Boot session
  restoreSession();
});
