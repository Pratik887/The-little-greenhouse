<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>the little green house — studio dashboard</title>
    <meta
      name="description"
      content="Private store administration dashboard."
    />
    <meta name="robots" content="noindex, nofollow" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
      rel="stylesheet"
    />
    <style>
      :root {
        --clay: #c3804c;
        --clay-dark: #975637;
        --brown: #7a4632;
        --brown-deep: #4a1b0c;
        --cream: #fbf7f1;
        --tan: #f5ecdf;
        --tan-2: #e5cdae;
        --sage: #8a9a6b;
        --sage-dark: #5c6b42;
        --amber: #e6a95c;
        --amber-dark: #a06a1f;
        --danger: #a5423a;
        --danger-dark: #712b13;
        --ink: #3b2c22;
        --ink-soft: #6b5847;
        --border: #e3d3bd;
        --white: #fffdfa;
        --radius: 14px;
        --shadow:
          0 2px 10px rgba(122, 70, 50, 0.07), 0 1px 2px rgba(122, 70, 50, 0.06);
      }

      * {
        box-sizing: border-box;
      }

      html,
      body {
        margin: 0;
        padding: 0;
      }

      body {
        font-family: "Jost", sans-serif;
        background: var(--cream);
        color: var(--ink);
        -webkit-font-smoothing: antialiased;
      }

      h1,
      h2,
      h3,
      h4 {
        font-family: "Fraunces", serif;
        font-weight: 500;
        color: var(--brown-deep);
        margin: 0;
      }

      button {
        font-family: "Jost", sans-serif;
        cursor: pointer;
      }

      input,
      select,
      textarea {
        font-family: "Jost", sans-serif;
      }

      ::selection {
        background: var(--tan-2);
      }

      /* ---------- login ---------- */
      #loginScreen {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background:
          radial-gradient(
            circle at 20% 20%,
            rgba(195, 128, 76, 0.1),
            transparent 45%
          ),
          radial-gradient(
            circle at 85% 80%,
            rgba(138, 154, 107, 0.12),
            transparent 40%
          ),
          var(--cream);
        padding: 24px;
      }

      .login-card {
        background: var(--white);
        border: 1px solid var(--border);
        border-radius: 20px;
        padding: 44px 40px;
        width: 100%;
        max-width: 380px;
        box-shadow: var(--shadow);
        text-align: center;
      }

      .login-mark {
        width: 52px;
        height: 52px;
        margin: 0 auto 14px;
        color: var(--clay-dark);
      }

      .login-card h1 {
        font-size: 26px;
        margin-bottom: 4px;
      }

      .login-card p.sub {
        color: var(--ink-soft);
        font-size: 14px;
        margin-bottom: 28px;
      }

      .field {
        text-align: left;
        margin-bottom: 16px;
      }

      .field label {
        display: block;
        font-size: 12.5px;
        color: var(--ink-soft);
        margin-bottom: 6px;
        letter-spacing: 0.02em;
      }

      .field input {
        width: 100%;
        padding: 11px 13px;
        border-radius: 10px;
        border: 1.5px solid var(--border);
        background: var(--cream);
        font-size: 14.5px;
        color: var(--ink);
        outline: none;
        transition: border-color 0.15s;
      }

      .field input:focus {
        border-color: var(--clay);
        background: var(--white);
      }

      .btn {
        border: none;
        border-radius: 10px;
        padding: 12px 18px;
        font-size: 14.5px;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition:
          transform 0.12s ease,
          opacity 0.12s ease;
        letter-spacing: 0.01em;
      }

      .btn:active {
        transform: scale(0.97);
      }

      .btn-primary {
        background: var(--clay);
        color: var(--white);
        width: 100%;
      }

      .btn-primary:hover {
        background: var(--clay-dark);
      }

      .btn-ghost {
        background: transparent;
        color: var(--brown);
        border: 1.5px solid var(--border);
      }

      .btn-ghost:hover {
        border-color: var(--clay);
      }

      .btn-danger {
        background: var(--danger);
        color: var(--white);
      }

      .btn-danger:hover {
        background: var(--danger-dark);
      }

      .btn-sm {
        padding: 7px 12px;
        font-size: 13px;
        border-radius: 8px;
      }

      .login-note {
        margin-top: 18px;
        font-size: 12px;
        color: var(--ink-soft);
        line-height: 1.6;
      }

      .login-error {
        background: #fbeceb;
        color: var(--danger-dark);
        border: 1px solid #f0cfc9;
        border-radius: 8px;
        padding: 9px 12px;
        font-size: 13px;
        margin-bottom: 14px;
        display: none;
      }

      /* ---------- app shell ---------- */
      #app {
        display: none;
        min-height: 100vh;
      }

      .shell {
        display: flex;
        min-height: 100vh;
      }

      .sidebar {
        width: 230px;
        flex-shrink: 0;
        background: var(--white);
        border-right: 1px solid var(--border);
        display: flex;
        flex-direction: column;
        padding: 22px 16px;
        position: sticky;
        top: 0;
        height: 100vh;
      }

      .side-logo {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 4px 8px 24px;
      }

      .side-logo svg {
        color: var(--clay-dark);
        flex-shrink: 0;
      }

      .side-logo span {
        font-family: "Fraunces", serif;
        font-size: 18px;
        color: var(--brown-deep);
      }

      .side-logo em {
        font-style: normal;
        color: var(--clay);
      }

      .nav-group-label {
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: var(--ink-soft);
        padding: 14px 12px 6px;
      }

      .nav-item {
        display: flex;
        align-items: center;
        gap: 11px;
        padding: 10px 12px;
        border-radius: 10px;
        color: var(--ink-soft);
        font-size: 14.5px;
        text-decoration: none;
        margin-bottom: 2px;
        border: none;
        background: transparent;
        width: 100%;
        text-align: left;
      }

      .nav-item svg {
        flex-shrink: 0;
      }

      .nav-item:hover {
        background: var(--tan);
        color: var(--brown);
      }

      .nav-item.active {
        background: var(--tan-2);
        color: var(--brown-deep);
        font-weight: 500;
      }

      .sidebar-foot {
        margin-top: auto;
        padding-top: 14px;
        border-top: 1px solid var(--border);
      }

      .who {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 8px 10px;
      }

      .who-avatar {
        width: 34px;
        height: 34px;
        border-radius: 50%;
        background: var(--tan-2);
        color: var(--brown-deep);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 13px;
        font-weight: 600;
        flex-shrink: 0;
      }

      .who-name {
        font-size: 13.5px;
        font-weight: 500;
        color: var(--brown);
      }

      .who-role {
        font-size: 11.5px;
        color: var(--ink-soft);
      }

      .main {
        flex: 1;
        min-width: 0;
      }

      .topbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        padding: 18px 28px;
        background: var(--white);
        border-bottom: 1px solid var(--border);
        position: sticky;
        top: 0;
        z-index: 20;
      }

      .topbar h2 {
        font-size: 20px;
      }

      .topbar-actions {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .mobile-toggle {
        display: none;
        background: none;
        border: none;
        color: var(--brown);
        padding: 6px;
      }

      .content {
        padding: 26px 28px 80px;
        max-width: 1280px;
      }

      /* ---------- kpis ---------- */
      .kpi-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
        gap: 14px;
        margin-bottom: 26px;
      }

      .kpi-card {
        background: var(--white);
        border: 1px solid var(--border);
        border-radius: var(--radius);
        padding: 18px 20px;
        box-shadow: var(--shadow);
      }

      .kpi-label {
        font-size: 12.5px;
        color: var(--ink-soft);
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .kpi-value {
        font-family: "Fraunces", serif;
        font-size: 26px;
        color: var(--brown-deep);
        font-weight: 500;
      }

      .kpi-delta {
        font-size: 12px;
        margin-top: 6px;
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .kpi-delta.up {
        color: var(--sage-dark);
      }

      .kpi-delta.down {
        color: var(--danger-dark);
      }

      .section-card {
        background: var(--white);
        border: 1px solid var(--border);
        border-radius: var(--radius);
        padding: 22px;
        margin-bottom: 20px;
        box-shadow: var(--shadow);
      }

      .section-card h3 {
        font-size: 17px;
        margin-bottom: 16px;
      }

      .card-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
        gap: 12px;
        flex-wrap: wrap;
      }

      /* ---------- tables ---------- */
      .table-wrap {
        overflow-x: auto;
      }

      table {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
      }

      th {
        text-align: left;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        color: var(--ink-soft);
        padding: 9px 12px;
        border-bottom: 1.5px solid var(--border);
        white-space: nowrap;
      }

      td {
        padding: 11px 12px;
        border-bottom: 1px solid var(--border);
        vertical-align: middle;
      }

      tr:last-child td {
        border-bottom: none;
      }

      tbody tr:hover {
        background: var(--cream);
      }

      .mono {
        font-variant-numeric: tabular-nums;
      }

      .pill {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 4px 10px;
        border-radius: 100px;
        font-size: 12px;
        font-weight: 500;
        white-space: nowrap;
      }

      .pill-sage {
        background: #e9efdf;
        color: var(--sage-dark);
      }

      .pill-amber {
        background: #fbecd7;
        color: var(--amber-dark);
      }

      .pill-danger {
        background: #f7e2df;
        color: var(--danger-dark);
      }

      .pill-gray {
        background: #eee8dd;
        color: var(--ink-soft);
      }

      .pill-clay {
        background: var(--tan-2);
        color: var(--brown-deep);
      }

      .stock-bar {
        width: 70px;
        height: 6px;
        background: var(--tan);
        border-radius: 4px;
        overflow: hidden;
        display: inline-block;
        vertical-align: middle;
        margin-right: 8px;
      }

      .stock-bar-fill {
        height: 100%;
        border-radius: 4px;
      }

      /* ---------- forms/modals ---------- */
      .overlay {
        position: fixed;
        inset: 0;
        background: rgba(74, 27, 12, 0.32);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 100;
        padding: 20px;
      }

      .overlay.show {
        display: flex;
      }

      .modal {
        background: var(--white);
        border-radius: 18px;
        width: 100%;
        max-width: 460px;
        max-height: 88vh;
        overflow-y: auto;
        padding: 26px;
        box-shadow: 0 20px 60px rgba(74, 27, 12, 0.25);
      }

      .modal h3 {
        font-size: 19px;
        margin-bottom: 18px;
      }

      .modal-close {
        float: right;
        background: none;
        border: none;
        color: var(--ink-soft);
        padding: 4px;
      }

      .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
      }

      .field select {
        width: 100%;
        padding: 11px 13px;
        border-radius: 10px;
        border: 1.5px solid var(--border);
        background: var(--cream);
        font-size: 14.5px;
        color: var(--ink);
        outline: none;
      }

      .field textarea {
        width: 100%;
        padding: 11px 13px;
        border-radius: 10px;
        border: 1.5px solid var(--border);
        background: var(--cream);
        font-size: 14px;
        color: var(--ink);
        outline: none;
        resize: vertical;
        min-height: 70px;
      }

      .field select:focus,
      .field textarea:focus {
        border-color: var(--clay);
        background: var(--white);
      }

      .modal-actions {
        display: flex;
        gap: 10px;
        margin-top: 20px;
      }

      .modal-actions .btn {
        flex: 1;
      }

      .empty-state {
        text-align: center;
        padding: 50px 20px;
        color: var(--ink-soft);
      }

      .empty-state svg {
        color: var(--tan-2);
        margin-bottom: 14px;
      }

      .empty-state h4 {
        color: var(--brown);
        margin-bottom: 6px;
        font-size: 16px;
      }

      .toast {
        position: fixed;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%) translateY(20px);
        background: var(--brown-deep);
        color: var(--white);
        padding: 12px 20px;
        border-radius: 10px;
        font-size: 14px;
        opacity: 0;
        transition: all 0.25s ease;
        z-index: 200;
        pointer-events: none;
        display: flex;
        align-items: center;
        gap: 8px;
        max-width: 90vw;
      }

      .toast.show {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
      }

      .tabs {
        display: flex;
        gap: 6px;
        margin-bottom: 18px;
        flex-wrap: wrap;
        border-bottom: 1px solid var(--border);
      }

      .tab-btn {
        background: none;
        border: none;
        padding: 10px 6px;
        font-size: 14px;
        color: var(--ink-soft);
        border-bottom: 2px solid transparent;
        margin-bottom: -1px;
      }

      .tab-btn.active {
        color: var(--brown-deep);
        border-bottom-color: var(--clay);
        font-weight: 500;
      }

      .search-input {
        padding: 9px 14px 9px 34px;
        border-radius: 10px;
        border: 1.5px solid var(--border);
        background: var(--cream);
        font-size: 14px;
        width: 220px;
        outline: none;
        background-repeat: no-repeat;
        background-position: 10px center;
      }

      .search-input:focus {
        border-color: var(--clay);
        background-color: var(--white);
      }

      .search-wrap {
        position: relative;
      }

      .search-wrap svg {
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--ink-soft);
        pointer-events: none;
      }

      .chip-filter {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
      }

      .chip {
        padding: 6px 13px;
        border-radius: 100px;
        border: 1.5px solid var(--border);
        background: var(--white);
        font-size: 13px;
        color: var(--ink-soft);
      }

      .chip.active {
        background: var(--brown-deep);
        color: var(--white);
        border-color: var(--brown-deep);
      }

      .grid-2 {
        display: grid;
        grid-template-columns: 1.3fr 1fr;
        gap: 20px;
      }

      .progress-track {
        display: flex;
        align-items: center;
        gap: 6px;
        margin: 6px 0 2px;
      }

      .progress-step {
        flex: 1;
        height: 5px;
        border-radius: 3px;
        background: var(--tan);
      }

      .progress-step.done {
        background: var(--sage);
      }

      .progress-step.current {
        background: var(--amber);
      }

      .icon-btn {
        background: none;
        border: 1.5px solid var(--border);
        border-radius: 9px;
        padding: 7px;
        color: var(--brown);
        display: inline-flex;
      }

      .icon-btn:hover {
        border-color: var(--clay);
        color: var(--clay-dark);
      }

      .bank-list {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }

      .bank-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 14px;
        border: 1px solid var(--border);
        border-radius: 12px;
      }

      /* ---------- api badge & diagnostics ---------- */
      .api-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 12px;
        border-radius: 100px;
        font-size: 12px;
        font-weight: 500;
        border: 1px solid var(--border);
        background: var(--white);
        color: var(--ink-soft);
      }

      .api-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        display: inline-block;
      }

      .api-dot.online {
        background: #28a745;
        box-shadow: 0 0 6px #28a745;
      }

      .api-dot.offline {
        background: #e6a95c;
        box-shadow: 0 0 6px #e6a95c;
      }

      /* ---------- stock adjustments ---------- */
      .stock-adjust-group {
        display: inline-flex;
        align-items: center;
        gap: 5px;
      }

      .stock-btn {
        width: 24px;
        height: 24px;
        border-radius: 6px;
        border: 1px solid var(--border);
        background: var(--white);
        color: var(--ink);
        font-size: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0;
        cursor: pointer;
        transition: all 0.15s ease;
      }

      .stock-btn:hover {
        background: var(--tan);
        border-color: var(--clay);
      }

      /* ---------- inventory enhancements ---------- */
      .inv-channel-header {
        background: linear-gradient(135deg, var(--white) 0%, var(--tan) 100%);
        border: 1px solid var(--border);
        border-radius: var(--radius);
        padding: 20px 24px;
        margin-bottom: 22px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        box-shadow: var(--shadow);
        flex-wrap: wrap;
      }

      .inv-channel-info {
        display: flex;
        align-items: center;
        gap: 14px;
      }

      .inv-channel-icon {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        background: var(--tan-2);
        color: var(--brown-deep);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
      }

      .inv-channel-info h3 {
        font-size: 18px;
        margin-bottom: 2px;
      }

      .inv-channel-info p {
        font-size: 13px;
        color: var(--ink-soft);
        margin: 0;
      }

      .inv-channel-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
      }

      .other-stock-tag {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 2px 7px;
        border-radius: 6px;
        font-size: 11px;
        background: var(--cream);
        border: 1px solid var(--border);
        color: var(--ink-soft);
        white-space: nowrap;
        margin-top: 3px;
      }

      .transfer-box {
        background: var(--cream);
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 16px;
        margin: 14px 0;
      }

      .transfer-visual {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 14px;
        padding: 12px;
        background: var(--white);
        border-radius: 10px;
        border: 1px solid var(--border);
      }

      .transfer-node {
        text-align: center;
        flex: 1;
      }

      .transfer-node-label {
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--ink-soft);
        margin-bottom: 4px;
      }

      .transfer-node-val {
        font-family: "Fraunces", serif;
        font-size: 20px;
        font-weight: 500;
        color: var(--brown-deep);
      }

      .transfer-arrow {
        color: var(--clay);
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .quick-preset-chips {
        display: flex;
        gap: 6px;
        margin-top: 8px;
      }

      .preset-chip {
        padding: 3px 10px;
        border-radius: 6px;
        border: 1px solid var(--border);
        background: var(--white);
        font-size: 12px;
        color: var(--ink-soft);
        cursor: pointer;
      }

      .preset-chip:hover {
        background: var(--tan);
        color: var(--brown-deep);
      }

      .sort-select {
        padding: 8px 12px;
        border-radius: 10px;
        border: 1.5px solid var(--border);
        background: var(--cream);
        font-size: 13.5px;
        color: var(--ink);
        outline: none;
        cursor: pointer;
      }

      .sort-select:focus {
        border-color: var(--clay);
        background: var(--white);
      }

      /* ---------- tracking timeline ---------- */
      .tracking-timeline {
        margin: 16px 0;
        padding-left: 20px;
        border-left: 2px solid var(--tan-2);
        display: flex;
        flex-direction: column;
        gap: 16px;
      }

      .tracking-checkpoint {
        position: relative;
      }

      .tracking-checkpoint::before {
        content: "";
        position: absolute;
        left: -26px;
        top: 4px;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: var(--clay);
        border: 2px solid var(--white);
      }

      .tracking-checkpoint.latest::before {
        background: var(--sage);
        box-shadow: 0 0 6px rgba(138, 154, 107, 0.6);
      }

      /* ---------- mobile ---------- */
      .bottom-nav {
        display: none;
      }

      @media (max-width: 900px) {
        .sidebar {
          display: none;
        }

        .sidebar.mobile-open {
          display: flex;
          position: fixed;
          z-index: 60;
          top: 0;
          left: 0;
          width: 230px;
          height: 100vh;
          box-shadow: 0 0 40px rgba(0, 0, 0, 0.2);
        }

        .mobile-toggle {
          display: inline-flex;
        }

        .content {
          padding: 18px 14px 90px;
        }

        .topbar {
          padding: 14px 16px;
        }

        .form-row {
          grid-template-columns: 1fr;
        }

        .grid-2 {
          grid-template-columns: 1fr;
        }

        .kpi-row {
          grid-template-columns: repeat(2, 1fr);
        }

        .bottom-nav {
          display: flex;
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          background: var(--white);
          border-top: 1px solid var(--border);
          z-index: 50;
          padding: 6px 4px calc(6px + env(safe-area-inset-bottom));
          justify-content: space-around;
        }

        .bottom-nav button {
          background: none;
          border: none;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 3px;
          color: var(--ink-soft);
          font-size: 10.5px;
          padding: 5px 2px;
          flex: 1;
        }

        .bottom-nav button.active {
          color: var(--clay-dark);
        }

        .search-input {
          width: 100%;
        }
      }

      .scrim {
        display: none;
      }

      @media (max-width: 900px) {
        .scrim.show {
          display: block;
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.3);
          z-index: 55;
        }
      }
    </style>
  </head>

  <body>
    <!-- ============ LOGIN ============ -->
    <div id="loginScreen">
      <div class="login-card">
        <svg
          class="login-mark"
          viewBox="0 0 48 48"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
        >
          <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" />
          <ellipse cx="24" cy="17" rx="11" ry="4" />
        </svg>
        <h1>the little green house</h1>
        <p class="sub">studio dashboard — owner access</p>
        <div class="login-error" id="loginError">
          that email and password don't match our records.
        </div>
        <form id="loginForm">
          <div class="field">
            <label for="loginEmail">email</label>
            <input
              type="email"
              id="loginEmail"
              placeholder="you@thelittlegreenhouse.com"
              required
              autocomplete="username"
            />
          </div>
          <div class="field">
            <label for="loginPass">password</label>
            <input
              type="password"
              id="loginPass"
              placeholder="enter your password"
              required
              autocomplete="current-password"
            />
          </div>
          <button type="submit" class="btn btn-primary">sign in</button>
        </form>
        <p class="login-note">
          Sign in with an administrator account provisioned for this store. For a new local database,
          create the first owner using the CLI setup instructions in <a href="../SETUP.md">SETUP.md</a>.
        </p>
      </div>
    </div>

    <!-- ============ APP ============ -->
    <div id="app">
      <div class="shell">
        <div class="scrim" id="scrim"></div>
        <aside class="sidebar" id="sidebar">
          <div class="side-logo">
            <svg viewBox="0 0 48 48" width="28" height="28">
              <path
                d="M14 18 Q12 40 24 42 Q36 40 34 18 Z"
                fill="none"
                stroke="currentColor"
                stroke-width="2.4"
              />
              <ellipse
                cx="24"
                cy="17"
                rx="11"
                ry="4"
                fill="none"
                stroke="currentColor"
                stroke-width="2.4"
              />
            </svg>
            <span>the little green house</span>
          </div>

          <div class="nav-group-label">overview</div>
          <button class="nav-item" data-page="overview">
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <rect x="3" y="3" width="7" height="9" rx="1.5" />
              <rect x="14" y="3" width="7" height="5" rx="1.5" />
              <rect x="14" y="12" width="7" height="9" rx="1.5" />
              <rect x="3" y="16" width="7" height="5" rx="1.5" /></svg
            >dashboard
          </button>

          <div class="nav-group-label">inventory</div>
          <button class="nav-item" data-page="instore">
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M3 9l1.5-5h15L21 9M3 9v10a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V9M3 9h18M9 13h6"
              /></svg
            >in-store stock
          </button>
          <button class="nav-item" data-page="online">
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <circle cx="12" cy="12" r="9" />
              <path
                d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"
              /></svg
            >online stock
          </button>

          <div class="nav-group-label">operations</div>
          <button class="nav-item" data-page="orders">
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path d="M4 4h16v16H4z" />
              <path d="M8 9h8M8 13h8M8 17h5" /></svg
            >orders
          </button>
          <button class="nav-item" data-page="deliveries">
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <rect x="1" y="7" width="14" height="10" rx="1.5" />
              <path d="M15 10h4l3 3v4h-7z" />
              <circle cx="6" cy="19" r="1.8" />
              <circle cx="17.5" cy="19" r="1.8" /></svg
            >deliveries
          </button>
          <button class="nav-item" data-page="payments">
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <rect x="2" y="5" width="20" height="15" rx="2" />
              <path d="M2 10h20" /></svg
            >payments
          </button>
          <button class="nav-item" data-page="refunds">
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path d="M3 12a9 9 0 1 0 3-6.7" />
              <path d="M3 4v5h5" /></svg
            >refunds
          </button>

          <div class="nav-group-label">studio</div>
          <button class="nav-item" data-page="settings">
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <circle cx="12" cy="12" r="3" />
              <path
                d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"
              /></svg
            >settings
          </button>

          <div class="sidebar-foot">
            <div class="who">
              <div class="who-avatar" id="whoAvatar">O</div>
              <div>
                <div class="who-name" id="whoName">owner</div>
                <div class="who-role" id="whoRole">owner account</div>
              </div>
            </div>
            <button class="nav-item" id="logoutBtn">
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="1.8"
              >
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <path d="M16 17l5-5-5-5" />
                <path d="M21 12H9" /></svg
              >sign out
            </button>
          </div>
        </aside>

        <div class="main">
          <div class="topbar">
            <div style="display: flex; align-items: center; gap: 12px">
              <button class="mobile-toggle icon-btn" id="mobileMenuBtn">
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="1.8"
                >
                  <line x1="4" y1="7" x2="20" y2="7" />
                  <line x1="4" y1="12" x2="20" y2="12" />
                  <line x1="4" y1="17" x2="20" y2="17" />
                </svg>
              </button>
              <h2 id="pageTitle">dashboard</h2>
            </div>
            <div class="topbar-actions" id="topbarActions"></div>
          </div>
          <div class="content" id="content"></div>
        </div>
      </div>
      <nav class="bottom-nav" id="bottomNav">
        <button data-page="overview">
          <svg
            width="19"
            height="19"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
          >
            <rect x="3" y="3" width="7" height="9" rx="1.5" />
            <rect x="14" y="3" width="7" height="5" rx="1.5" />
            <rect x="14" y="12" width="7" height="9" rx="1.5" />
            <rect x="3" y="16" width="7" height="5" rx="1.5" /></svg
          >home
        </button>
        <button data-page="orders">
          <svg
            width="19"
            height="19"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
          >
            <path d="M4 4h16v16H4z" />
            <path d="M8 9h8M8 13h8M8 17h5" /></svg
          >orders
        </button>
        <button data-page="deliveries">
          <svg
            width="19"
            height="19"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
          >
            <rect x="1" y="7" width="14" height="10" rx="1.5" />
            <path d="M15 10h4l3 3v4h-7z" />
            <circle cx="6" cy="19" r="1.8" />
            <circle cx="17.5" cy="19" r="1.8" /></svg
          >delivery
        </button>
        <button data-page="payments">
          <svg
            width="19"
            height="19"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
          >
            <rect x="2" y="5" width="20" height="15" rx="2" />
            <path d="M2 10h20" /></svg
          >pay
        </button>
        <button data-page="instore">
          <svg
            width="19"
            height="19"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1.8"
          >
            <path
              d="M3 9l1.5-5h15L21 9M3 9v10a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V9M3 9h18M9 13h6"
            /></svg
          >stock
        </button>
      </nav>
    </div>

    <div class="overlay" id="overlay">
      <div class="modal" id="modalBody"></div>
    </div>
    <div class="toast" id="toast"></div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js"></script>
    <script src="admin.js?v=20261013-product-media-1"></script>
  </body>
</html>
