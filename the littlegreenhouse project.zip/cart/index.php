<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — your cart</title>
  <meta name="description"
    content="review your handmade pieces from the little green house – pots, candles, and décor ready to ship." />
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🛒</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1280px;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
      letter-spacing: 0.01em;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    ul {
      list-style: none;
    }

    img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 9999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    .reveal {
      opacity: 0;
      transform: translateY(24px);
      transition:
        opacity 0.8s var(--ease-hand),
        transform 0.8s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 15px 28px;
      border-radius: 100px;
      font-size: 0.9rem;
      font-weight: 500;
      letter-spacing: 0.02em;
      white-space: nowrap;
      transition: all 0.3s var(--ease-hand);
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      background: var(--c-900);
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
    }

    .btn-outline {
      border: 1.5px solid var(--c-700);
      color: var(--ink);
      background: transparent;
    }

    .btn-outline:hover {
      background: var(--c-800);
      color: var(--c-50);
      border-color: var(--c-800);
      transform: translateY(-3px);
    }

    /* header */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 600;
      background: rgba(251, 247, 241, 0.86);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 80px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.35rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
      transition: color 0.3s;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active {
      color: var(--ink);
    }

    .main-nav a.is-active::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s,
        color 0.3s;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition: 0.3s;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* cart hero */
    .cart-hero {
      padding: 50px 0 30px;
      text-align: center;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .cart-hero h1 {
      font-size: clamp(2.2rem, 4.5vw, 3.5rem);
      line-height: 1.1;
      margin-bottom: 10px;
    }

    .cart-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .cart-hero p {
      color: var(--muted);
      font-size: 1.1rem;
    }

    /* cart main */
    .cart-main {
      padding: 50px 0 80px;
    }

    .cart-layout {
      display: grid;
      grid-template-columns: 1fr 380px;
      gap: 40px;
      align-items: start;
    }

    /* cart items */
    .cart-items {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .cart-item {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      padding: 20px;
      display: grid;
      grid-template-columns: 120px 1fr auto;
      gap: 20px;
      transition:
        box-shadow 0.3s,
        transform 0.3s var(--ease-hand);
    }

    .cart-item:hover {
      box-shadow: var(--shadow-soft);
    }

    .cart-item-media {
      width: 120px;
      aspect-ratio: 4/3;
      border-radius: var(--radius-sm);
      overflow: hidden;
      background: var(--surface-2);
    }

    .cart-item-media img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .cart-item-details {
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .cart-item-category {
      font-size: 0.7rem;
      letter-spacing: 0.08em;
      color: var(--c-600);
      margin-bottom: 4px;
    }

    .cart-item-title {
      font-family: var(--font-display);
      font-size: 1.2rem;
      font-weight: 500;
      margin-bottom: 6px;
    }

    .cart-item-price {
      font-size: 1.1rem;
      color: var(--c-700);
      font-weight: 500;
    }

    .cart-item-actions {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .qty-control {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .qty-btn {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      border: 1px solid var(--line);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: 0.2s;
      font-size: 1.1rem;
      color: var(--ink-soft);
    }

    .qty-btn:hover {
      background: var(--c-100);
      border-color: var(--c-600);
    }

    .qty-value {
      font-size: 1rem;
      min-width: 30px;
      text-align: center;
      font-weight: 500;
    }

    .remove-btn {
      color: var(--muted);
      font-size: 0.8rem;
      text-decoration: underline;
      transition: color 0.2s;
    }

    .remove-btn:hover {
      color: #b34a4a;
    }

    /* empty cart */
    .empty-cart {
      text-align: center;
      padding: 60px 20px;
      background: var(--surface);
      border: 1px dashed var(--line);
      border-radius: var(--radius-lg);
    }

    .empty-cart svg {
      margin: 0 auto 20px;
      color: var(--c-400);
    }

    .empty-cart h3 {
      font-size: 1.5rem;
      margin-bottom: 8px;
    }

    .empty-cart p {
      color: var(--muted);
      margin-bottom: 24px;
    }

    /* order summary */
    .order-summary {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      padding: 28px;
      position: sticky;
      top: 100px;
    }

    .order-summary h3 {
      font-size: 1.4rem;
      margin-bottom: 20px;
    }

    .summary-row {
      display: flex;
      justify-content: space-between;
      padding: 12px 0;
      border-bottom: 1px solid var(--line);
      font-size: 0.95rem;
    }

    .summary-row:last-of-type {
      border-bottom: none;
    }

    .summary-row.total {
      font-size: 1.2rem;
      font-weight: 600;
      border-top: 2px solid var(--ink);
      border-bottom: none;
      margin-top: 10px;
      padding-top: 16px;
    }

    .summary-row .label {
      color: var(--muted);
    }

    .summary-row .value {
      font-weight: 500;
    }

    .free-shipping-note {
      font-size: 0.8rem;
      color: var(--c-600);
      margin-top: 12px;
    }

    .checkout-btn {
      width: 100%;
      margin-top: 20px;
      padding: 16px;
    }

    /* footer */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 70px 0 0;
      margin-top: 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.8fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 50px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand p {
      margin: 14px 0 20px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 12px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      transition: 0.3s;
    }

    .socials a:hover {
      background: var(--c-600);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 16px;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.2s;
    }

    .footer-col a:hover {
      color: white;
    }

    .footer-bottom {
      padding: 24px 0;
      text-align: center;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
    }

    /* responsive */
    @media (max-width: 1024px) {
      .cart-layout {
        grid-template-columns: 1fr;
      }

      .order-summary {
        position: static;
      }

      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 18px;
      }

      .main-nav {
        position: fixed;
        top: 80px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 16px 28px 28px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition: 0.4s var(--ease-hand);
        z-index: 500;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 14px 0;
        border-bottom: 1px solid var(--line);
      }

      .menu-toggle {
        display: flex;
      }

      .cart-item {
        grid-template-columns: 90px 1fr;
        gap: 15px;
        padding: 15px;
      }

      .cart-item-media {
        width: 90px;
      }

      .cart-item-actions {
        grid-column: 1 / -1;
        justify-content: space-between;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 30px;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <meta name="robots" content="noindex, nofollow" />
</head>

<body>
  <a class="skip-link" href="#main">skip to cart</a>
  <div class="grain" aria-hidden="true"></div>

  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo" aria-label="the little green house home">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="34" height="34">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products"><svg width="19" height="19" viewBox="0 0 24 24"
            fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg></a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="menu" aria-expanded="false" aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <section class="cart-hero">
      <div class="wrap">
        <h1>your <em>cart</em></h1>
        <p>review your pieces — they're almost ready to come home.</p>
      </div>
    </section>

    <section class="cart-main" aria-label="shopping cart">
      <div class="wrap">
        <div class="cart-layout">
          <!-- cart items container -->
          <div class="cart-items" id="cartItems">
            <!-- dynamically populated -->
          </div>

          <!-- order summary -->
          <aside class="order-summary" aria-label="order summary">
            <h3>order summary</h3>
            <div class="summary-row">
              <span class="label">subtotal</span>
              <span class="value" id="subtotal">₹0</span>
            </div>
            <div class="summary-row">
              <span class="label">shipping</span>
              <span class="value" id="shipping">₹0</span>
            </div>
            <div class="summary-row">
              <span class="label">gift wrap</span>
              <span class="value">₹0</span>
            </div>
            <div class="summary-row total">
              <span class="label">total</span>
              <span class="value" id="total">₹0</span>
            </div>
            <p class="free-shipping-note" id="shippingNote">
              free shipping on orders over ₹999
            </p>
            <button class="btn btn-primary checkout-btn" style="width: 100%;">
              proceed to checkout
            </button>
            <a href="../shop/" class="btn btn-ghost"
              style="width: 100%; justify-content: center; margin-top: 12px; text-decoration: none;">
              continue shopping
            </a>
          </aside>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>handmade pots, candles & home décor — made slowly, on purpose.</p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script src="../cart.js?v=20261013-cart-fix-1"></script>
  <script src="../checkout.js?v=20261013-checkout-fix-1"></script>
  <script>
    (function () {
      'use strict';

      const FREE_SHIPPING_THRESHOLD = 999;
      const SHIPPING_COST = 99;

      // Use shared cart utility — but keep local cartItems array in sync
      let cartItems = window.TLGHCart.getItems().map(item => ({
        ...item,
        id: Number(item.product_id),
        stock: Math.max(0, Number(item.stock) || 0),
        img: item.img || 'https://placehold.co/600x450/E5CDAE/633B2B?text=handmade+for+you'
      }));

      const cartContainer = document.getElementById("cartItems");
      const subtotalEl    = document.getElementById("subtotal");
      const shippingEl    = document.getElementById("shipping");
      const totalEl       = document.getElementById("total");
      const shippingNote  = document.getElementById("shippingNote");

      function formatPrice(amount) {
        return "\u20b9" + Number(amount).toLocaleString("en-IN");
      }

      function saveCart() {
        const items = cartItems.map(({ id, ...rest }) => ({ ...rest, product_id: id }));
        localStorage.setItem('tlgh_cart', JSON.stringify(items));
        window.dispatchEvent(new CustomEvent('tlgh:cart:updated', { detail: { items } }));
      }

      function calculateTotals() {
        const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
        const shipping = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_COST;
        const total = subtotal + shipping;

        subtotalEl.textContent = formatPrice(subtotal);
        shippingEl.textContent = shipping === 0 ? "free" : formatPrice(shipping);
        totalEl.textContent    = formatPrice(total);

        if (subtotal === 0) {
          shippingNote.textContent = "free shipping on orders over \u20b9999";
          shippingNote.style.color = "var(--muted)";
        } else if (subtotal >= FREE_SHIPPING_THRESHOLD) {
          shippingNote.textContent = "\u2713 you qualify for free shipping!";
          shippingNote.style.color = "var(--c-600)";
        } else {
          const remaining = FREE_SHIPPING_THRESHOLD - subtotal;
          shippingNote.textContent = `add ${formatPrice(remaining)} more for free shipping`;
          shippingNote.style.color = "var(--muted)";
        }

        // Update cart badge count
        const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
        document.querySelectorAll('.cart-dot').forEach(dot => {
          if (totalItems > 0) {
            dot.textContent = totalItems;
            dot.setAttribute('style', [
              'display:flex','align-items:center','justify-content:center',
              'width:16px','height:16px','border-radius:50%',
              'background:var(--c-600)','color:#fff','font-size:0.6rem',
              'position:absolute','top:4px','right:4px'
            ].join(';'));
          } else {
            dot.style.display = 'none';
          }
        });
      }

      function renderCart() {
        saveCart();
        const checkoutButton = document.querySelector('.checkout-btn');
        if (checkoutButton) {
          checkoutButton.disabled = cartItems.length === 0 || cartItems.some(item => item.stock < 1);
          checkoutButton.setAttribute('aria-disabled', String(checkoutButton.disabled));
        }
        if (cartItems.length === 0) {
          cartContainer.innerHTML = `
            <div class="empty-cart">
              <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2">
                <path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"/>
              </svg>
              <h3>your cart is empty</h3>
              <p>looks like you haven't added anything yet — explore the shop to find your piece.</p>
              <a href="../shop/" class="btn btn-primary">continue shopping</a>
            </div>
          `;
          calculateTotals();
          return;
        }

        cartContainer.innerHTML = cartItems.map((item, index) => `
          <article class="cart-item" data-index="${index}">
            <div class="cart-item-media">
              <a href="../product/?id=${item.id}">
                <img src="${item.img}" alt="${item.title}" loading="lazy"
                  onerror="this.src='https://placehold.co/600x450/E5CDAE/633B2B?text=handmade'" />
              </a>
            </div>
            <div class="cart-item-details">
              <span class="cart-item-category">${item.category || ''}</span>
              <h3 class="cart-item-title">
                <a href="../product/?id=${item.id}" style="color:inherit;text-decoration:none;">${item.title}</a>
              </h3>
              <span class="cart-item-price">${formatPrice(item.price)}</span>
              ${item.stock < 1 ? '<span class="cart-item-category" role="status">currently unavailable</span>' : ''}
            </div>
            <div class="cart-item-actions">
              <div class="qty-control">
                <button class="qty-btn decrease" aria-label="decrease quantity">−</button>
                <span class="qty-value">${item.quantity}</span>
                <button class="qty-btn increase" aria-label="increase quantity">+</button>
              </div>
              <button class="remove-btn" aria-label="remove item">remove</button>
            </div>
          </article>
        `).join("");

        // Attach events
        cartContainer.querySelectorAll(".cart-item").forEach((card) => {
          const index = parseInt(card.dataset.index);

          card.querySelector(".decrease").addEventListener("click", () => {
            if (cartItems[index].quantity > 1) {
              cartItems[index].quantity--;
            } else {
              cartItems.splice(index, 1);
            }
            renderCart();
          });

          card.querySelector(".increase").addEventListener("click", () => {
            const ceiling = Math.min(20, cartItems[index].stock);
            if (cartItems[index].quantity >= ceiling) return;
            cartItems[index].quantity++;
            renderCart();
          });

          card.querySelector(".remove-btn").addEventListener("click", () => {
            cartItems.splice(index, 1);
            renderCart();
          });
        });

        calculateTotals();
      }

      // Refresh cart prices from live catalog on load
      (async function refreshCartFromCatalog() {
        try {
          const response = await fetch('../api/products', { headers: { Accept: 'application/json' } });
          if (!response.ok) throw new Error('Catalog unavailable');
          const payload = await response.json();
          const catalog = new Map((payload.products || []).map(p => [Number(p.id), p]));
          cartItems = cartItems.map(item => {
            const current = catalog.get(item.id);
            return current
              ? { ...item, title: current.name, price: Number(current.price), category: current.category_name || item.category, img: current.primary_image || item.img, stock: Math.max(0, Number(current.online_stock_quantity ?? current.stock_quantity ?? 0)) }
              : item;
          });
        } catch (_) { /* Offline mode — use stored cart as-is */ }
        renderCart();
      })();

      // ── Fastrr Checkout ────────────────────────────────────────────
      document.querySelector(".checkout-btn")?.addEventListener("click", async (event) => {
        event.preventDefault();
        if (!cartItems.length) return;

        const button = event.currentTarget;
        button.disabled = true;
        button.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 0.8s linear infinite"><path d="M12 2a10 10 0 0 1 0 20A10 10 0 0 1 2 12"/></svg> connecting to secure checkout\u2026`;

        // Add spinner animation
        if (!document.getElementById('spinKeyframes')) {
          const style = document.createElement('style');
          style.id = 'spinKeyframes';
          style.textContent = '@keyframes spin { to { transform: rotate(360deg); } }';
          document.head.append(style);
        }

        try {
          await window.TLGHCheckout.startCheckout(
            cartItems.map((item) => ({ product_id: item.id, quantity: item.quantity })),
            event,
          );
        } catch (error) {
          alert(error.message);
          button.disabled = false;
          button.textContent = 'proceed to checkout';
        }
      });

      // ── Menu toggle ───────────────────────────────────────────────
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) =>
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          })
        );
      }

      // ── Header shadow ──────────────────────────────────────────────
      const header = document.querySelector(".site-header");
      window.addEventListener("scroll", () => {
        header.style.boxShadow = window.scrollY > 20 ? "0 8px 24px -18px rgba(53,29,21,0.35)" : "none";
      }, { passive: true });

    })();
  </script>
</body>

</html>
