#!/usr/bin/env bash
cd "$(dirname "$0")"
command -v php >/dev/null || { echo "PHP 8.1+ install karo"; exit 1; }
read -r -s -p "Admin password (14+ chars, Enter = skip): " P; echo
PHP_MYSQL_FLAG=""
if ! php -r 'exit(extension_loaded("pdo_mysql") ? 0 : 1);'; then
  php -d extension=pdo_mysql.so -r 'exit(extension_loaded("pdo_mysql") ? 0 : 1);' || { echo "pdo_mysql is required to use the cPanel database"; exit 1; }
  PHP_MYSQL_FLAG="-d extension=pdo_mysql.so"
fi
[ -n "$P" ] && php $PHP_MYSQL_FLAG api/setup-admin.php admin@truelokal.com "$P"
echo "Site: http://localhost:3000/   Admin: http://localhost:3000/admin/"
php $PHP_MYSQL_FLAG -S localhost:3000 router.php
