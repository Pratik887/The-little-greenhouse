<?php
// Local development router for PHP built-in web server (php -S localhost:8088 router.php)
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// The static markup is an internal template consumed by product/index.php.
if (strtolower($uri) === '/product/template.php') {
    http_response_code(404);
    exit;
}

// Database files are never public assets, including the local catalog snapshot.
if (preg_match('#^/(?:database|api/database)(?:/|$)#i', $uri) || basename($uri) === 'thelittlegreenhouse-3737f1d6') {
    http_response_code(404);
    exit;
}
if (preg_match('#(?:^|/)\.env(?:\.[^/]*)?$#i', $uri)) {
    http_response_code(404);
    exit;
}

// Route /api/* requests to /api/index.php
if (strtolower($uri) === '/api/setup-admin.php') {
    require __DIR__ . '/api/setup-admin.php';
    return;
}
if (strpos($uri, '/api/') === 0 || $uri === '/api') {
    $_SERVER['SCRIPT_NAME'] = '/api/index.php';
    $_SERVER['PHP_SELF'] = '/api/index.php';
    require __DIR__ . '/api/index.php';
    return;
}

if (strtolower($uri) === '/sitemap.xml') {
    require __DIR__ . '/sitemap.php';
    return;
}

// Serve existing static files directly
$file = __DIR__ . $uri;
if ($uri !== '/' && is_file($file)) {
    return false;
}

// Directory indexes
if (is_dir($file)) {
    // Product details need the PHP entry point so crawlers receive server-rendered SEO metadata.
    if (strtolower(trim($uri, '/')) === 'product' && file_exists($file . '/index.php')) {
        require $file . '/index.php';
        return;
    }
    if (file_exists($file . '/index.php')) {
        require $file . '/index.php';
        return;
    }
}

return false;
