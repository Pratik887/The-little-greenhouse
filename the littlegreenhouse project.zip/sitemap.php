<?php
header('Content-Type: application/xml; charset=UTF-8');

$siteUrl = 'https://thelittlegreenhouse.in';
$staticPaths = [
    '/', '/shop/', '/category/', '/ourstory/', '/theprocess/', '/reviews/',
    '/visit/', '/care-guide/', '/faqs/', '/shipping-and-returns/',
    '/privacy-policy/', '/terms-and-conditions/', '/support/',
];
$urls = array_map(static fn(string $path): array => ['loc' => $siteUrl . $path], $staticPaths);

try {
    require_once __DIR__ . '/api/config/database.php';
    $config = require __DIR__ . '/api/config/config.php';
    $siteUrl = rtrim((string) ($config['app']['url'] ?? $siteUrl), '/');
    $products = Database::getConnection()->query('SELECT slug, updated_at FROM products WHERE is_active = 1 ORDER BY id')->fetchAll();
    foreach ($products as $product) {
        $urls[] = [
            'loc' => $siteUrl . '/product/?slug=' . rawurlencode((string) $product['slug']),
            'lastmod' => $product['updated_at'] ?? null,
        ];
    }
} catch (Throwable $error) {
    error_log('Sitemap product lookup failed: ' . $error->getMessage());
}

$escapeXml = static fn(string $value): string => htmlspecialchars($value, ENT_XML1 | ENT_QUOTES, 'UTF-8');
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
foreach ($urls as $url) {
    echo '  <url><loc>' . $escapeXml($url['loc']) . '</loc>';
    if (!empty($url['lastmod'])) {
        $timestamp = strtotime((string) $url['lastmod']);
        if ($timestamp !== false) {
            echo '<lastmod>' . gmdate('Y-m-d', $timestamp) . '</lastmod>';
        }
    }
    echo "</url>\n";
}
echo '</urlset>';
