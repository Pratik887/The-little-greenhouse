<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — shipping & returns</title>
  <meta name="description"
    content="learn about shipping, delivery, and return policies for handmade products from the little green house studio." />
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>📦</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1180px;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
      letter-spacing: 0.01em;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    ul {
      list-style: none;
    }

    img {
      display: block;
      max-width: 100%;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 9999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    .reveal {
      opacity: 0;
      transform: translateY(24px);
      transition:
        opacity 0.8s var(--ease-hand),
        transform 0.8s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 14px 26px;
      border-radius: 100px;
      font-size: 0.9rem;
      font-weight: 500;
      letter-spacing: 0.02em;
      white-space: nowrap;
      transition: all 0.3s var(--ease-hand);
      min-height: 44px;
      touch-action: manipulation;
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      background: var(--c-900);
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
    }

    .btn-outline {
      border: 1.5px solid var(--c-700);
      color: var(--ink);
      background: transparent;
    }

    .btn-outline:hover {
      background: var(--c-800);
      color: var(--c-50);
      border-color: var(--c-800);
      transform: translateY(-3px);
    }

    /* header */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 600;
      background: rgba(251, 247, 241, 0.86);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 80px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.35rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
      transition: color 0.3s;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active {
      color: var(--ink);
    }

    .main-nav a.is-active::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s,
        color 0.3s;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .profile-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: var(--c-600);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition: 0.3s;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* policy hero */
    .policy-hero {
      padding: 60px 0 30px;
      text-align: center;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .policy-hero h1 {
      font-size: clamp(2rem, 4vw, 3rem);
      line-height: 1.1;
      margin-bottom: 10px;
    }

    .policy-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .policy-hero p {
      color: var(--muted);
      font-size: 1.1rem;
      max-width: 600px;
      margin: 0 auto;
    }

    /* policy main */
    .policy-main {
      padding: 50px 0 80px;
    }

    .policy-layout {
      display: grid;
      grid-template-columns: 250px 1fr;
      gap: 40px;
      align-items: start;
    }

    /* sidebar */
    .policy-nav {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      overflow: hidden;
      position: sticky;
      top: 100px;
    }

    .policy-nav a {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 16px 20px;
      font-size: 0.9rem;
      font-weight: 500;
      color: var(--ink-soft);
      transition: 0.2s;
      border-bottom: 1px solid var(--line);
    }

    .policy-nav a:last-child {
      border-bottom: none;
    }

    .policy-nav a:hover {
      background: var(--surface-2);
      color: var(--ink);
    }

    .policy-nav a.active {
      background: var(--c-100);
      color: var(--c-700);
      border-left: 3px solid var(--c-600);
    }

    .policy-nav a svg {
      width: 18px;
      height: 18px;
      flex-shrink: 0;
    }

    /* policy content */
    .policy-section {
      margin-bottom: 40px;
    }

    .policy-section:last-child {
      margin-bottom: 0;
    }

    .policy-card {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      padding: 28px;
      margin-bottom: 24px;
    }

    .policy-card h2 {
      font-size: 1.5rem;
      margin-bottom: 16px;
      font-family: var(--font-display);
    }

    .policy-card h3 {
      font-size: 1.1rem;
      margin: 20px 0 10px;
    }

    .policy-card p {
      color: var(--muted);
      font-size: 0.95rem;
      line-height: 1.7;
      margin-bottom: 12px;
    }

    .policy-card ul {
      margin-bottom: 12px;
      padding-left: 20px;
    }

    .policy-card ul li {
      color: var(--muted);
      font-size: 0.95rem;
      line-height: 1.7;
      margin-bottom: 8px;
      list-style: disc;
    }

    .policy-card .highlight {
      background: var(--surface-2);
      border-left: 3px solid var(--c-600);
      padding: 16px 20px;
      border-radius: var(--radius-sm);
      margin: 16px 0;
    }

    .policy-card .highlight p {
      color: var(--ink-soft);
      margin-bottom: 0;
    }

    /* info boxes */
    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin: 20px 0;
    }

    .info-box {
      text-align: center;
      padding: 20px;
      background: var(--surface-2);
      border-radius: var(--radius-sm);
    }

    .info-box .icon {
      font-size: 2rem;
      margin-bottom: 8px;
    }

    .info-box h4 {
      font-size: 0.95rem;
      margin-bottom: 4px;
    }

    .info-box p {
      font-size: 0.8rem;
      color: var(--muted);
      margin-bottom: 0;
    }

    /* contact section */
    .contact-policy {
      text-align: center;
      padding: 40px 20px;
      background: var(--surface-2);
      border-radius: var(--radius-lg);
      margin-top: 40px;
    }

    .contact-policy h3 {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }

    .contact-policy p {
      color: var(--muted);
      margin-bottom: 20px;
    }

    .contact-actions {
      display: flex;
      gap: 12px;
      justify-content: center;
      flex-wrap: wrap;
    }

    /* footer */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 70px 0 0;
      margin-top: 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.8fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 50px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand p {
      margin: 14px 0 20px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 12px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      transition: 0.3s;
    }

    .socials a:hover {
      background: var(--c-600);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 16px;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.2s;
    }

    .footer-col a:hover {
      color: white;
    }

    .footer-bottom {
      padding: 24px 0;
      text-align: center;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
    }

    /* responsive */
    @media (max-width: 1024px) {
      .policy-layout {
        grid-template-columns: 1fr;
      }

      .policy-nav {
        position: static;
        display: flex;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
      }

      .policy-nav a {
        min-width: 140px;
        border-bottom: none;
        border-right: 1px solid var(--line);
        flex-shrink: 0;
      }

      .policy-nav a.active {
        border-left: none;
        border-bottom: 3px solid var(--c-600);
      }

      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 16px;
      }

      .header-inner {
        height: 64px;
      }

      .logo-text {
        font-size: 1.1rem;
      }

      .main-nav {
        position: fixed;
        top: 64px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 16px 28px 28px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition: 0.4s var(--ease-hand);
        z-index: 500;
        max-height: calc(100vh - 64px);
        overflow-y: auto;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 16px 0;
        border-bottom: 1px solid var(--line);
        font-size: 1rem;
      }

      .menu-toggle {
        display: flex;
      }

      .profile-avatar {
        width: 32px;
        height: 32px;
        font-size: 0.8rem;
      }

      .policy-hero {
        padding: 40px 0 20px;
      }

      .policy-hero h1 {
        font-size: 1.8rem;
      }

      .policy-hero p {
        font-size: 1rem;
      }

      .policy-main {
        padding: 30px 0 60px;
      }

      .policy-card {
        padding: 20px 16px;
      }

      .policy-card h2 {
        font-size: 1.2rem;
      }

      .policy-card h3 {
        font-size: 1rem;
      }

      .info-grid {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 12px;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 30px;
        padding-bottom: 30px;
      }

      .site-footer {
        padding: 50px 0 0;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <link rel="canonical" href="https://thelittlegreenhouse.in/shipping-and-returns/" />
  <meta property="og:title" content="the little green house — shipping &amp; returns" />
  <meta property="og:description" content="learn about shipping, delivery, and return policies for handmade products from the little green house studio." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/shipping-and-returns/" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
  <a class="skip-link" href="#main">skip to policies</a>
  <div class="grain" aria-hidden="true"></div>

  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo" aria-label="the little green house home">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="30" height="30">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products"><svg width="19" height="19" viewBox="0 0 24 24"
            fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg></a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="menu" aria-expanded="false" aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <section class="policy-hero">
      <div class="wrap">
        <h1>shipping <em>&amp;</em> returns</h1>
        <p>
          everything you need to know about how we get our handmade pieces to
          you.
        </p>
      </div>
    </section>

    <section class="policy-main">
      <div class="wrap">
        <div class="policy-layout">
          <!-- sidebar navigation -->
          <nav class="policy-nav" aria-label="policy sections">
            <a href="#shipping" class="active">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <path d="M21 8l-9-5-9 5v8l9 5 9-5V8z" />
                <path d="M3 8l9 5 9-5M12 13v8" />
              </svg>
              shipping info
            </a>
            <a href="#delivery">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <rect x="1" y="3" width="15" height="13" rx="1" />
                <path d="M16 8h4l3 3v5h-7V8z" />
                <circle cx="5.5" cy="18.5" r="2.5" />
                <circle cx="18.5" cy="18.5" r="2.5" />
              </svg>
              delivery times
            </a>
            <a href="#returns">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                <path d="M3 3v5h5" />
              </svg>
              return policy
            </a>
            <a href="#damages">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                <path d="M12 8v4M12 16h.01" />
              </svg>
              damages & issues
            </a>
            <a href="#international">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <circle cx="12" cy="12" r="10" />
                <path
                  d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
              </svg>
              international
            </a>
          </nav>

          <!-- policy content -->
          <div class="policy-content">
            <!-- shipping section -->
            <section class="policy-section" id="shipping">
              <div class="policy-card">
                <h2>shipping information</h2>
                <p>
                  we take great care in packaging each handmade piece to
                  ensure it arrives safely at your doorstep. every item is
                  wrapped with love and protected with eco-friendly materials.
                </p>

                <div class="info-grid">
                  <div class="info-box">
                    <div class="icon">📦</div>
                    <h4>processing time</h4>
                    <p>3-5 business days</p>
                  </div>
                  <div class="info-box">
                    <div class="icon">🚚</div>
                    <h4>domestic delivery</h4>
                    <p>5-8 business days</p>
                  </div>
                  <div class="info-box">
                    <div class="icon">✈️</div>
                    <h4>international</h4>
                    <p>2-3 weeks</p>
                  </div>
                  <div class="info-box">
                    <div class="icon">💰</div>
                    <h4>free shipping</h4>
                    <p>orders over ₹2,500</p>
                  </div>
                </div>

                <h3>how it works</h3>
                <p>
                  once you place your order, our team carefully prepares your
                  items for shipment. you'll receive a confirmation email with
                  tracking information as soon as your package leaves our
                  studio in bhubaneswar.
                </p>

                <div class="highlight">
                  <p>
                    <strong>note:</strong> during peak seasons (festivals,
                    holidays), processing times may extend by 2-3 business
                    days. we appreciate your patience as we handcraft each
                    piece with care.
                  </p>
                </div>
              </div>
            </section>

            <!-- delivery section -->
            <section class="policy-section" id="delivery">
              <div class="policy-card">
                <h2>delivery times</h2>
                <h3>domestic (india)</h3>
                <ul>
                  <li>
                    <strong>standard shipping:</strong> 5-8 business days
                    after dispatch
                  </li>
                  <li>
                    <strong>express shipping:</strong> 2-4 business days after
                    dispatch (available at checkout)
                  </li>
                  <li>
                    <strong>free shipping:</strong> on all orders over ₹2,500
                  </li>
                  <li>
                    <strong>flat rate:</strong> ₹150 for orders below ₹2,500
                  </li>
                </ul>

                <h3>international shipping</h3>
                <ul>
                  <li><strong>south asia:</strong> 7-14 business days</li>
                  <li>
                    <strong>middle east & europe:</strong> 10-20 business days
                  </li>
                  <li><strong>north america:</strong> 14-21 business days</li>
                  <li>
                    <strong>australia & new zealand:</strong> 14-21 business
                    days
                  </li>
                  <li><strong>rest of world:</strong> 15-25 business days</li>
                </ul>

                <div class="highlight">
                  <p>
                    <strong>tracking:</strong> all orders include tracking.
                    you'll receive your tracking number via email once your
                    order ships.
                  </p>
                </div>
              </div>
            </section>

            <!-- returns section -->
            <section class="policy-section" id="returns">
              <div class="policy-card">
                <h2>return policy</h2>
                <p>
                  we want you to love your handmade pieces. if something isn't
                  quite right, we're here to help.
                </p>

                <h3>return window</h3>
                <p>
                  you have <strong>14 days</strong> from the date of delivery
                  to initiate a return for unused, undamaged items in their
                  original packaging.
                </p>

                <h3>how to return an item</h3>
                <ul>
                  <li>
                    contact us at <strong>hello@thelittlegreenhouse.com</strong> with
                    your order number and reason for return
                  </li>
                  <li>
                    we'll provide you with a return authorization and shipping
                    instructions
                  </li>
                  <li>pack the item securely in its original packaging</li>
                  <li>
                    ship the item back to our studio within 7 days of
                    receiving your return authorization
                  </li>
                  <li>
                    once received and inspected, we'll process your refund
                    within 5-7 business days
                  </li>
                </ul>

                <h3>refund method</h3>
                <p>
                  refunds are issued to the original payment method. for
                  orders paid by UPI or bank transfer, refunds may take 3-5
                  additional business days to reflect in your account.
                </p>

                <h3>non-returnable items</h3>
                <ul>
                  <li>custom or personalized orders</li>
                  <li>items marked as "final sale" or "clearance"</li>
                  <li>gift cards</li>
                  <li>used candles or items that show signs of wear</li>
                </ul>
              </div>
            </section>

            <!-- damages section -->
            <section class="policy-section" id="damages">
              <div class="policy-card">
                <h2>damages & issues</h2>
                <p>
                  we take great care in packaging our handmade items, but
                  sometimes things happen during transit. if your order
                  arrives damaged or defective, we'll make it right.
                </p>

                <h3>what to do if your item arrives damaged</h3>
                <ul>
                  <li>
                    take photos of the damaged item and packaging within
                    <strong>48 hours</strong> of delivery
                  </li>
                  <li>
                    email the photos and your order number to
                    <strong>hello@thelittlegreenhouse.com</strong>
                  </li>
                  <li>
                    we'll review your claim and offer a replacement or full
                    refund
                  </li>
                  <li>replacement items are shipped at no additional cost</li>
                </ul>

                <div class="highlight">
                  <p>
                    <strong>important:</strong> due to the handmade nature of
                    our products, small variations in color, texture, and size
                    are not considered defects. these characteristics make
                    each piece unique.
                  </p>
                </div>

                <h3>wrong item received</h3>
                <p>
                  if you receive the wrong item, contact us within 48 hours of
                  delivery. we'll arrange for the correct item to be shipped
                  immediately and provide a prepaid return label for the
                  incorrect item.
                </p>
              </div>
            </section>

            <!-- international section -->
            <section class="policy-section" id="international">
              <div class="policy-card">
                <h2>international shipping</h2>
                <p>
                  we ship worldwide! here's what you need to know about
                  international orders.
                </p>

                <h3>customs & duties</h3>
                <p>
                  international orders may be subject to customs fees, import
                  duties, and taxes imposed by your country. these charges are
                  the responsibility of the recipient and are not included in
                  the shipping cost at checkout.
                </p>

                <h3>shipping costs</h3>
                <p>
                  international shipping costs are calculated at checkout
                  based on your location and order weight. free shipping
                  promotions apply to domestic orders only.
                </p>

                <h3>delivery times</h3>
                <p>
                  international delivery times vary by destination. please
                  allow up to 3 weeks for delivery. tracking is included with
                  all international orders.
                </p>

                <h3>returns for international orders</h3>
                <p>
                  international customers are responsible for return shipping
                  costs. we recommend using a tracked shipping method for
                  returns.
                </p>
              </div>
            </section>

            <!-- contact section -->
            <div class="contact-policy">
              <h3>still have questions?</h3>
              <p>
                we're happy to help with any shipping or return inquiries.
              </p>
              <div class="contact-actions">
                <a href="mailto:hello@thelittlegreenhouse.com" class="btn btn-primary">email us</a>
                <a href="#faq" class="btn btn-outline">view faq</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>handmade pots, candles & home décor — made slowly, on purpose.</p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    (function () {
      // smooth scroll for policy nav
      const policyLinks = document.querySelectorAll(".policy-nav a");

      policyLinks.forEach((link) => {
        link.addEventListener("click", (e) => {
          e.preventDefault();
          const targetId = link.getAttribute("href").substring(1);
          const targetElement = document.getElementById(targetId);

          if (targetElement) {
            // update active state
            policyLinks.forEach((l) => l.classList.remove("active"));
            link.classList.add("active");

            // smooth scroll to target
            targetElement.scrollIntoView({
              behavior: "smooth",
              block: "start",
            });
          }
        });
      });

      // highlight active section on scroll
      const sections = document.querySelectorAll(".policy-section");

      function updateActiveLink() {
        let currentSection = "";
        sections.forEach((section) => {
          const sectionTop = section.offsetTop - 100;
          if (window.scrollY >= sectionTop) {
            currentSection = section.id;
          }
        });

        policyLinks.forEach((link) => {
          link.classList.remove("active");
          if (link.getAttribute("href") === `#${currentSection}`) {
            link.classList.add("active");
          }
        });
      }

      window.addEventListener("scroll", updateActiveLink, { passive: true });

      // menu toggle
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) =>
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }),
        );
      }

      // close mobile nav on outside click
      document.addEventListener("click", (e) => {
        if (mainNav && mainNav.classList.contains("is-open")) {
          if (
            !e.target.closest(".main-nav") &&
            !e.target.closest(".menu-toggle")
          ) {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }
        }
      });

      // header shadow
      const header = document.querySelector(".site-header");
      window.addEventListener(
        "scroll",
        () => {
          header.style.boxShadow =
            window.scrollY > 20
              ? "0 8px 24px -18px rgba(53,29,21,0.35)"
              : "none";
        },
        { passive: true },
      );

      // scroll reveal
      const revealObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              revealObserver.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.1 },
      );

      document
        .querySelectorAll(".reveal")
        .forEach((el) => revealObserver.observe(el));
    })();
  </script>
</body>

</html>