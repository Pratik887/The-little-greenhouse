<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — the process</title>
  <meta name="description"
    content="how we make our handmade pots, candles, plants and décor — from raw material to your shelf, every step done by hand in small batches." />
  <meta name="keywords"
    content="handmade process, pottery wheel, hand poured candles, artisan studio, small batch home decor, the little green house" />
  <meta name="author" content="the little green house" />
  <meta name="robots" content="index, follow" />
  <link rel="canonical" href="https://thelittlegreenhouse.in/theprocess/" />

  <!-- open graph -->
  <meta property="og:title" content="the little green house — the process" />
  <meta property="og:description"
    content="from raw material to your shelf: shaping, finishing, checking and wrapping — every step done by hand." />
  <meta property="og:type" content="website" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/theprocess/" />
  <meta property="og:site_name" content="the little green house" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="the little green house — the process" />
  <meta name="twitter:description"
    content="from raw material to your shelf: shaping, finishing, checking and wrapping — every step done by hand." />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />

  <meta name="theme-color" content="#fbf7f1" />

  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🏺</text></svg>" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />

  <style>
    /* ============================================================
       the little green house — process page styles
       (matches the story page theme exactly)
       ============================================================ */
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --accent-2: var(--c-500);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1180px;
    }

    *,
    *::before,
    *::after {
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      margin: 0;
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
    }

    img,
    svg {
      display: block;
      max-width: 100%;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    ul {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    h1,
    h2,
    h3,
    h4 {
      font-family: var(--font-display);
      font-weight: 500;
      margin: 0;
      text-transform: lowercase;
    }

    p {
      margin: 0;
    }

    input {
      font-family: inherit;
      text-transform: none;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    /* grain overlay */
    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    /* reveal */
    .reveal {
      opacity: 0;
      transform: translateY(22px);
      transition:
        opacity 0.9s var(--ease-hand),
        transform 0.9s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      html {
        scroll-behavior: auto;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 15px 28px;
      border-radius: 100px;
      font-size: 0.95rem;
      letter-spacing: 0.02em;
      transition:
        transform 0.35s var(--ease-hand),
        box-shadow 0.35s var(--ease-hand),
        background 0.35s ease,
        color 0.35s ease;
      white-space: nowrap;
    }

    .btn svg {
      transition: transform 0.35s var(--ease-hand);
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
      background: var(--c-900);
    }

    .btn-primary:hover svg {
      transform: translateX(4px);
    }

    .btn-ghost {
      background: transparent;
      border: 1.5px solid var(--c-800);
      color: var(--ink);
    }

    .btn-ghost:hover {
      background: var(--c-800);
      color: var(--c-50);
      transform: translateY(-3px);
    }

    .eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 9px;
      font-family: var(--font-body);
      font-size: 0.82rem;
      letter-spacing: 0.14em;
      color: var(--c-700);
      margin-bottom: 14px;
    }

    .eyebrow-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-600);
      box-shadow: 0 0 0 4px var(--c-200);
    }

    /* header */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 500;
      background: rgba(251, 247, 241, 0.82);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 82px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.3rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active-link {
      color: var(--ink);
    }

    .main-nav a.is-active-link::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s ease,
        color 0.3s ease;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition:
        transform 0.3s var(--ease-hand),
        opacity 0.3s ease;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* ===== page hero ===== */
    .page-hero {
      padding: 70px 0 40px;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .page-hero-inner {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .page-hero h1 {
      font-size: clamp(2.6rem, 5.5vw, 4.4rem);
      line-height: 1.08;
      letter-spacing: -0.01em;
      max-width: 860px;
      margin-bottom: 20px;
    }

    .page-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .page-hero p {
      font-size: 1.15rem;
      color: var(--muted);
      max-width: 640px;
      margin-bottom: 28px;
    }

    /* ===== step detail blocks ===== */
    .process-detail {
      padding: 90px 0;
      border-bottom: 1px solid var(--line);
      opacity: 0;
      transform: translateY(30px);
      animation: fadeUp 0.9s var(--ease-hand) forwards;
    }

    .process-detail:nth-of-type(1) {
      animation-delay: 0.1s;
    }

    .process-detail:nth-of-type(2) {
      animation-delay: 0.2s;
    }

    .process-detail:nth-of-type(3) {
      animation-delay: 0.3s;
    }

    .process-detail:nth-of-type(4) {
      animation-delay: 0.4s;
    }

    @keyframes fadeUp {
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @media (prefers-reduced-motion: reduce) {
      .process-detail {
        opacity: 1;
        transform: none;
        animation: none;
      }
    }

    .process-detail-inner {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 60px 70px;
      align-items: center;
    }

    .process-detail-reverse .process-detail-inner {
      direction: rtl;
    }

    .process-detail-reverse .process-detail-inner>* {
      direction: ltr;
    }

    .process-detail-copy .process-badge {
      display: inline-block;
      font-family: var(--font-body);
      font-size: 0.78rem;
      letter-spacing: 0.16em;
      color: var(--c-700);
      background: var(--c-100);
      padding: 6px 16px;
      border-radius: 100px;
      margin-bottom: 18px;
      border: 1px solid var(--c-200);
    }

    .process-detail-copy h2 {
      font-size: clamp(2rem, 3.6vw, 3rem);
      line-height: 1.1;
      margin-bottom: 20px;
    }

    .process-detail-copy h2 em {
      color: var(--c-600);
      font-style: italic;
    }

    .process-detail-copy p {
      color: var(--muted);
      font-size: 1.05rem;
      max-width: 520px;
      margin-bottom: 24px;
    }

    .process-points {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .process-points li {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      font-size: 0.95rem;
      color: var(--ink-soft);
    }

    .process-points li::before {
      content: "";
      display: block;
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: var(--c-500);
      margin-top: 8px;
      flex-shrink: 0;
    }

    .process-detail-visual {
      display: flex;
      justify-content: center;
    }

    .process-illustration {
      width: 100%;
      max-width: 400px;
      border-radius: var(--radius-lg);
      overflow: hidden;
      box-shadow: var(--shadow-lift);
      background: var(--c-100);
      transition: transform 0.6s var(--ease-hand);
    }

    .process-detail-visual:hover .process-illustration {
      transform: scale(1.01) rotate(0.5deg);
    }

    .process-illustration svg {
      width: 100%;
      height: auto;
      display: block;
    }

    /* ===== materials strip ===== */
    .materials {
      padding: 90px 0;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .materials-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 24px;
      margin-top: 50px;
    }

    .material-card {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      padding: 32px 26px;
      transition:
        transform 0.45s var(--ease-hand),
        box-shadow 0.45s var(--ease-hand);
    }

    .material-card:hover {
      transform: translateY(-6px);
      box-shadow: var(--shadow-lift);
    }

    .material-icon {
      color: var(--c-600);
      margin-bottom: 18px;
    }

    .material-card h3 {
      font-size: 1.2rem;
      margin-bottom: 8px;
    }

    .material-card p {
      font-size: 0.92rem;
      color: var(--muted);
      line-height: 1.5;
    }

    /* ===== cta strip ===== */
    .cta-strip {
      padding: 90px 0;
      text-align: center;
      background: var(--surface);
    }

    .cta-strip h2 {
      font-size: clamp(1.9rem, 3.4vw, 2.8rem);
      margin-bottom: 16px;
    }

    .cta-strip h2 em {
      color: var(--c-600);
      font-style: italic;
    }

    .cta-strip p {
      color: var(--muted);
      font-size: 1.05rem;
      max-width: 520px;
      margin: 0 auto 30px;
    }

    .cta-strip .btn {
      margin: 0 auto;
    }

    /* ===== footer ===== */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 80px 0 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.6fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 60px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand .logo-text em {
      color: var(--c-400);
    }

    .footer-brand p {
      margin: 16px 0 22px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 10px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      color: var(--c-200);
      transition:
        background 0.3s ease,
        transform 0.3s var(--ease-hand);
    }

    .socials a:hover {
      background: var(--c-600);
      transform: translateY(-3px);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 18px;
    }

    .footer-col {
      display: flex;
      flex-direction: column;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.3s ease;
    }

    .footer-col a:hover {
      color: var(--c-100);
    }

    .footer-bottom {
      padding: 26px 0;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
      text-align: center;
    }

    /* ===== responsive ===== */
    @media (max-width: 1024px) {
      .process-detail-inner {
        grid-template-columns: 1fr;
        gap: 40px;
      }

      .process-detail-reverse .process-detail-inner {
        direction: ltr;
      }

      .process-detail-visual {
        order: -1;
      }

      .process-illustration {
        max-width: 480px;
        margin: 0 auto;
      }

      .process-detail-copy p {
        max-width: 100%;
      }

      .materials-grid {
        grid-template-columns: repeat(2, 1fr);
      }

      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 20px;
      }

      .main-nav {
        position: fixed;
        top: 82px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 20px 28px 30px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition:
          transform 0.45s var(--ease-hand),
          opacity 0.4s ease;
        z-index: 400;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 14px 0;
        border-bottom: 1px solid var(--line);
      }

      .menu-toggle {
        display: flex;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 34px;
      }

      .page-hero h1 {
        font-size: 2.2rem;
      }

      .process-detail {
        padding: 60px 0;
      }

      .process-detail-copy h2 {
        font-size: 1.8rem;
      }

      .materials-grid {
        grid-template-columns: 1fr;
      }

      .cta-strip {
        padding: 60px 0;
      }

      .cta-strip .btn+.btn {
        margin-left: 0;
        margin-top: 10px;
      }

      .cta-strip .btn {
        display: inline-flex;
        width: 100%;
        justify-content: center;
      }

      .cta-strip .btn+.btn {
        margin-left: 0;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
</head>

<body>
  <a class="skip-link" href="#main">skip to content</a>
  <div class="grain" aria-hidden="true"></div>

  <!-- ===== header ===== -->
  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="34" height="34">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/" class="is-active-link" aria-current="page">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="open menu" aria-expanded="false"
          aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <!-- ===== page hero ===== -->
    <section class="page-hero" aria-label="the process introduction">
      <div class="wrap page-hero-inner">
        <p class="eyebrow reveal">
          <span class="eyebrow-dot"></span>how it's made
        </p>
        <h1 class="reveal">
          from raw material <br />
          to your shelf — <em>slowly.</em>
        </h1>
        <p class="reveal">
          every piece that leaves the studio passes through the same four
          stages. no shortcuts, no batch production — just clay, wax, soil and
          time.
        </p>
        <div class="reveal">
          <a href="#step-1" class="btn btn-primary">see the steps</a>
        </div>
      </div>
    </section>

    <!-- ===== step 1 ===== -->
    <section class="process-detail" id="step-1" aria-label="step one: shaped by hand">
      <div class="wrap process-detail-inner">
        <div class="process-detail-visual reveal">
          <div class="process-illustration">
            <svg viewBox="0 0 360 360" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <rect x="0" y="0" width="360" height="360" fill="#e5cdae" />
              <ellipse cx="180" cy="270" rx="140" ry="26" fill="#c3804c" opacity="0.5" />
              <ellipse cx="180" cy="262" rx="140" ry="22" fill="#975637" />
              <path d="M138 150 Q126 240 180 262 Q234 240 222 150 Z" fill="#ce9969" />
              <ellipse cx="180" cy="148" rx="46" ry="15" fill="#7a4632" />
              <ellipse cx="180" cy="143" rx="38" ry="11" fill="#e5cdae" opacity="0.8" />
              <path d="M118 200 Q100 185 96 155 Q94 140 108 138 Q120 138 124 152 Q140 170 140 200 Z" fill="#7a4632" />
              <path d="M242 200 Q260 185 264 155 Q266 140 252 138 Q240 138 236 152 Q220 170 220 200 Z" fill="#7a4632" />
              <circle cx="150" cy="90" r="4" fill="#fbf7f1" opacity="0.6" />
              <circle cx="210" cy="100" r="3" fill="#fbf7f1" opacity="0.6" />
              <circle cx="180" cy="70" r="3" fill="#fbf7f1" opacity="0.5" />
            </svg>
          </div>
        </div>
        <div class="process-detail-copy">
          <span class="process-badge reveal">step 01</span>
          <h2 class="reveal">shaped by hand</h2>
          <p class="reveal">
            clay is centred on the wheel and pulled upward by feel — the
            thickness, the curve, the weight of the rim. wax is weighed and
            warmed by eye, not by app. every pot and every candle starts the
            same way: with a person deciding when it looks right.
          </p>
          <ul class="process-points reveal">
            <li>wheel-thrown stoneware, one at a time</li>
            <li>soy wax poured in small batches</li>
            <li>plants potted fresh before they ship</li>
          </ul>
        </div>
      </div>
    </section>

    <!-- ===== step 2 ===== -->
    <section class="process-detail process-detail-reverse" id="step-2" aria-label="step two: finished slow">
      <div class="wrap process-detail-inner">
        <div class="process-detail-visual reveal">
          <div class="process-illustration">
            <svg viewBox="0 0 360 360" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <rect x="0" y="0" width="360" height="360" fill="#f5ecdf" />
              <rect x="40" y="240" width="280" height="10" rx="3" fill="#ce9969" opacity="0.5" />
              <path d="M100 160 Q92 230 130 240 Q168 230 160 160 Z" fill="#c3804c" />
              <ellipse cx="130" cy="158" rx="34" ry="12" fill="#7a4632" />
              <path d="M190 180 Q184 230 210 240 Q236 230 230 180 Z" fill="#975637" />
              <ellipse cx="210" cy="178" rx="24" ry="9" fill="#633b2b" />
              <rect x="260" y="200" width="36" height="40" rx="3" fill="#f5ecdf" stroke="#ddbb94" stroke-width="2" />
              <rect x="273" y="188" width="10" height="14" fill="#e5cdae" />
              <circle cx="300" cy="70" r="30" fill="none" stroke="#7a4632" stroke-width="3" opacity="0.5" />
              <line x1="300" y1="70" x2="300" y2="48" stroke="#7a4632" stroke-width="3" stroke-linecap="round"
                opacity="0.5" />
              <line x1="300" y1="70" x2="315" y2="78" stroke="#7a4632" stroke-width="3" stroke-linecap="round"
                opacity="0.5" />
            </svg>
          </div>
        </div>
        <div class="process-detail-copy">
          <span class="process-badge reveal">step 02</span>
          <h2 class="reveal">finished slow</h2>
          <p class="reveal">
            glazes are mixed in-house from raw minerals, then tested on scrap
            tiles before they ever touch a finished piece. candles rest for
            two full weeks before they're wicked and boxed — that's what gives
            them a slow, even burn instead of a quick, smoky one.
          </p>
          <ul class="process-points reveal">
            <li>glazes mixed and tested by hand</li>
            <li>candles cured for 14 days before shipping</li>
            <li>plants hardened off, never forced</li>
          </ul>
        </div>
      </div>
    </section>

    <!-- ===== step 3 ===== -->
    <section class="process-detail" id="step-3" aria-label="step three: checked by hand">
      <div class="wrap process-detail-inner">
        <div class="process-detail-visual reveal">
          <div class="process-illustration">
            <svg viewBox="0 0 360 360" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <rect x="0" y="0" width="360" height="360" fill="#e5cdae" />
              <rect x="50" y="220" width="260" height="14" rx="3" fill="#975637" />
              <path d="M140 150 Q132 210 180 220 Q228 210 220 150 Z" fill="#c3804c" />
              <ellipse cx="180" cy="148" rx="42" ry="14" fill="#7a4632" />
              <circle cx="260" cy="130" r="34" fill="none" stroke="#7a4632" stroke-width="5" />
              <line x1="284" y1="154" x2="310" y2="180" stroke="#7a4632" stroke-width="6" stroke-linecap="round" />
              <circle cx="260" cy="130" r="26" fill="#fbf7f1" opacity="0.3" />
              <path d="M80 80 L100 100 L140 60" fill="none" stroke="#8a9a6b" stroke-width="6" stroke-linecap="round"
                stroke-linejoin="round" />
            </svg>
          </div>
        </div>
        <div class="process-detail-copy">
          <span class="process-badge reveal">step 03</span>
          <h2 class="reveal">checked by hand</h2>
          <p class="reveal">
            before anything is wrapped, it's held up to the light and looked
            at properly — the rim, the base, the wick, the leaves. if a piece
            isn't something we'd keep on our own shelf, it doesn't leave the
            studio. that's the whole quality-control department.
          </p>
          <ul class="process-points reveal">
            <li>every piece inspected individually</li>
            <li>seconds are kept, not sold</li>
            <li>nothing ships that we wouldn't keep</li>
          </ul>
        </div>
      </div>
    </section>

    <!-- ===== step 4 ===== -->
    <section class="process-detail process-detail-reverse" id="step-4" aria-label="step four: wrapped with care">
      <div class="wrap process-detail-inner">
        <div class="process-detail-visual reveal">
          <div class="process-illustration">
            <svg viewBox="0 0 360 360" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <rect x="0" y="0" width="360" height="360" fill="#f5ecdf" />
              <rect x="90" y="140" width="180" height="150" rx="6" fill="#ce9969" />
              <rect x="90" y="140" width="180" height="40" rx="6" fill="#ddbb94" />
              <path d="M110 190 Q140 175 170 190 Q200 205 230 190" fill="none" stroke="#c3804c" stroke-width="4"
                stroke-linecap="round" />
              <path d="M110 210 Q140 195 170 210 Q200 225 230 210" fill="none" stroke="#c3804c" stroke-width="4"
                stroke-linecap="round" />
              <path d="M180 140 Q160 110 145 125 Q135 140 160 150" fill="none" stroke="#7a4632" stroke-width="4"
                stroke-linecap="round" />
              <path d="M180 140 Q200 110 215 125 Q225 140 200 150" fill="none" stroke="#7a4632" stroke-width="4"
                stroke-linecap="round" />
              <circle cx="180" cy="140" r="6" fill="#7a4632" />
              <rect x="230" y="250" width="70" height="50" rx="4" fill="#fbf7f1" stroke="#ddbb94" stroke-width="2" />
              <line x1="242" y1="266" x2="288" y2="266" stroke="#ddbb94" stroke-width="2" />
              <line x1="242" y1="278" x2="280" y2="278" stroke="#ddbb94" stroke-width="2" />
              <line x1="242" y1="290" x2="270" y2="290" stroke="#ddbb94" stroke-width="2" />
            </svg>
          </div>
        </div>
        <div class="process-detail-copy">
          <span class="process-badge reveal">step 04</span>
          <h2 class="reveal">wrapped with care</h2>
          <p class="reveal">
            pieces are cushioned in recycled kraft paper and straw, boxed by
            hand, and sent with a small note about the piece inside. no
            plastic, no polystyrene — just materials that can go straight into
            the recycling or the compost.
          </p>
          <ul class="process-points reveal">
            <li>recycled kraft &amp; straw packaging</li>
            <li>handwritten note with every order</li>
            <li>plastic-free, always</li>
          </ul>
        </div>
      </div>
    </section>

    <!-- ===== materials strip ===== -->
    <section class="materials" aria-label="materials we use">
      <div class="wrap">
        <div style="text-align: center">
          <p class="eyebrow reveal">
            <span class="eyebrow-dot"></span>what goes in
          </p>
          <h2 class="reveal" style="font-size: clamp(1.9rem, 3.4vw, 2.8rem)">
            simple materials, chosen with care
          </h2>
        </div>

        <div class="materials-grid">
          <div class="material-card reveal">
            <div class="material-icon" aria-hidden="true">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="M12 2v20M6 8l6-6 6 6" />
              </svg>
            </div>
            <h3>stoneware clay</h3>
            <p>
              durable, high-fire clay that holds its shape and glazes
              beautifully
            </p>
          </div>
          <div class="material-card reveal">
            <div class="material-icon" aria-hidden="true">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path
                  d="M12 2c3 4 3 8 0 12-3-4-3-8 0-12ZM6 10c2 3 2 6 0 9-2-3-2-6 0-9ZM18 10c2 3 2 6 0 9-2-3-2-6 0-9Z" />
              </svg>
            </div>
            <h3>soy wax</h3>
            <p>clean-burning, slow-melting, and kind to indoor air</p>
          </div>
          <div class="material-card reveal">
            <div class="material-icon" aria-hidden="true">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="M12 22V10M12 10c-4-1-6-4-6-8 4 0 6 3 6 6M12 10c4-1 6-4 6-8-4 0-6 3-6 6" />
              </svg>
            </div>
            <h3>living plants</h3>
            <p>
              easy-care varieties that thrive in real homes, not greenhouses
            </p>
          </div>
          <div class="material-card reveal">
            <div class="material-icon" aria-hidden="true">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <path d="M3 15l5-5 4 4 5-6 4 5" />
              </svg>
            </div>
            <h3>natural finishes</h3>
            <p>
              mineral glazes, beeswax, and linseed oil — nothing synthetic
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- ===== cta strip ===== -->
    <section class="cta-strip" aria-label="shop the collection">
      <div class="wrap">
        <h2 class="reveal">ready to see the finished pieces?</h2>
        <p class="reveal">
          every piece in the shop was made this way — slowly, by hand, in
          small batches.
        </p>
        <a href="../shop/" class="btn btn-primary reveal">
          <span>browse the shop</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="5" y1="12" x2="19" y2="12" />
            <polyline points="12 5 19 12 12 19" />
          </svg>
        </a>
      </div>
    </section>
  </main>

  <!-- ===== footer ===== -->
  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>
          handmade pots, candles &amp; home décor — made slowly, on purpose.
        </p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    (function () {
      "use strict";

      // scroll reveal
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.15, rootMargin: "0px 0px -40px 0px" },
      );

      document
        .querySelectorAll(".reveal")
        .forEach((el) => observer.observe(el));

      // mobile nav toggle
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) => {
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          });
        });
      }

      // header shadow on scroll
      const header = document.querySelector(".site-header");
      window.addEventListener(
        "scroll",
        () => {
          if (header) {
            header.style.boxShadow =
              window.scrollY > 20
                ? "0 8px 24px -18px rgba(53,29,21,0.35)"
                : "none";
          }
        },
        { passive: true },
      );
    })();
  </script>
</body>

</html>
