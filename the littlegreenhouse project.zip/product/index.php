<?php
/**
 * Serve the product page with product-specific metadata in the initial HTML.
 * This lets search crawlers and social preview bots see the product before JS runs.
 */

$templatePath = __DIR__ . '/template.php';
$html = is_file($templatePath) ? file_get_contents($templatePath) : false;
if ($html === false) {
    http_response_code(500);
    exit('Product page template unavailable.');
}

$product = null;
try {
    require_once __DIR__ . '/../api/config/database.php';
    $config = require __DIR__ . '/../api/config/config.php';
    $db = Database::getConnection();
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    $slug = trim((string) ($_GET['slug'] ?? ''));
    if (($id && $id > 0) || $slug !== '') {
        $lookup = $db->prepare(
            'SELECT p.*, (SELECT name FROM categories WHERE id = p.category_id LIMIT 1) AS category_name,
                    (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) AS primary_image
             FROM products p WHERE p.is_active = 1 AND (p.id = ? OR p.slug = ?) LIMIT 1'
        );
        $lookup->execute([$id ?: 0, $slug]);
        $product = $lookup->fetch() ?: null;
    }
} catch (Throwable $error) {
    // Keep the client-rendered page available if SEO metadata cannot be loaded.
    error_log('Product SEO metadata lookup failed: ' . $error->getMessage());
}

if (!$product && (isset($_GET['id']) || isset($_GET['slug']))) {
    http_response_code(404);
    $html = preg_replace('~</head>~i', "  <meta name=\"robots\" content=\"noindex, nofollow\" />\n</head>", $html, 1);
}

if ($product) {
    // Match the canonical host used by the rest of the public page metadata.
    $siteUrl = rtrim((string) ($config['app']['url'] ?? 'https://thelittlegreenhouse.in'), '/');
    $name = trim((string) $product['name']);
    $plainDescription = trim(preg_replace('/\s+/', ' ', strip_tags((string) ($product['short_description'] ?: $product['description'] ?: 'Handmade in small batches at The Little Green House studio.'))));
    $description = function_exists('mb_substr') ? mb_substr($plainDescription, 0, 160) : substr($plainDescription, 0, 160);
    $productUrl = $siteUrl . '/product/?slug=' . rawurlencode((string) $product['slug']);
    $image = trim((string) ($product['primary_image'] ?? ''));
    if ($image === '') {
        $image = 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&q=85';
    } elseif (preg_match('#^http://#i', $image)) {
        $image = 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&q=85';
    } elseif (!preg_match('#^https://#i', $image)) {
        $image = $siteUrl . '/' . ltrim($image, '/');
    }

    $e = static fn(string $value): string => htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $priceText = number_format((float) $product['price'], 2, '.', ',');
    $stock = max(0, (int) ($product['online_stock_quantity'] ?? $product['stock_quantity'] ?? 0));
    $imageQuery = $db->prepare('SELECT image_url, alt_text FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC');
    $imageQuery->execute([(int) $product['id']]);
    $gallery = $imageQuery->fetchAll(PDO::FETCH_ASSOC) ?: [];
    if (!$gallery && $image !== '') {
        $gallery[] = ['image_url' => $image, 'alt_text' => $name];
    }
    $clientProduct = [
        'id' => (int) $product['id'], 'name' => $name, 'slug' => (string) $product['slug'],
        'price' => (float) $product['price'], 'compare_at_price' => isset($product['compare_at_price']) ? (float) $product['compare_at_price'] : null,
        'description' => (string) ($product['description'] ?? ''), 'short_description' => (string) ($product['short_description'] ?? ''),
        'sku' => (string) ($product['sku'] ?? ''), 'dimensions' => (string) ($product['dimensions'] ?? ''),
        'weight_grams' => (int) ($product['weight_grams'] ?? 0), 'online_stock_quantity' => $stock,
        'stock_quantity' => $stock, 'category_name' => (string) ($product['category_name'] ?? ''),
        'tag' => (string) ($product['tag'] ?? ''), 'primary_image' => $image, 'images' => $gallery,
    ];
    $clientProductJson = json_encode($clientProduct, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($clientProductJson !== false) {
        $html = str_replace('<script src="../cart.js">', '<script id="serverProductData" type="application/json">' . $clientProductJson . '</script>' . "\n  " . '<script src="../cart.js">', $html);
    }
    $serverContent = '<div id="pdpContent" data-server-rendered="true" style="display:block;">'
        . '<div class="pdp-grid"><div class="pdp-gallery"><div class="pdp-main-img">'
        . '<img src="' . $e($image) . '" alt="' . $e($name) . '" fetchpriority="high" />'
        . '</div></div><div class="pdp-info"><p class="pdp-category">' . $e((string) ($product['category_name'] ?? '')) . '</p>'
        . '<h1 class="pdp-title">' . $e($name) . '</h1><div class="pdp-price-row"><span class="pdp-price">&#8377;' . $e($priceText) . '</span></div>'
        . '<p class="pdp-desc">' . nl2br($e($plainDescription), false) . '</p>'
        . '<div class="pdp-stock ' . ($stock > 0 ? 'in-stock' : 'out-stock') . '">' . ($stock > 0 ? 'in stock' : 'out of stock') . '</div>'
        . '<div class="pdp-actions"><div class="pdp-qty-row"><span class="qty-label">quantity</span><div class="qty-stepper">'
        . '<button id="qtyMinus" aria-label="decrease quantity">−</button><span class="qty-num" id="qtyNum">1</span><button id="qtyPlus" aria-label="increase quantity">+</button></div></div>'
        . '<button class="btn-add-cart" id="btnAddCart"' . ($stock < 1 ? ' disabled' : '') . '>add to cart</button>'
        . '<button class="btn-checkout" id="btnBuyNow"' . ($stock < 1 ? ' disabled' : '') . '>buy now — instant checkout</button></div>'
        . '<div class="pdp-meta">' . (!empty($product['sku']) ? '<div class="pdp-meta-row"><span class="pdp-meta-label">sku:</span><span class="pdp-meta-val">' . $e((string) $product['sku']) . '</span></div>' : '')
        . (!empty($product['dimensions']) ? '<div class="pdp-meta-row"><span class="pdp-meta-label">size:</span><span class="pdp-meta-val">' . $e((string) $product['dimensions']) . '</span></div>' : '')
        . (!empty($product['weight_grams']) ? '<div class="pdp-meta-row"><span class="pdp-meta-label">weight:</span><span class="pdp-meta-val">' . (int) $product['weight_grams'] . 'g</span></div>' : '')
        . '<div class="pdp-meta-row"><span class="pdp-meta-label">free shipping</span><span class="pdp-meta-val">on orders above &#8377;999</span></div>'
        . '<div class="pdp-meta-row"><span class="pdp-meta-label">returns</span><span class="pdp-meta-val">7-day hassle-free returns</span></div></div></div></div></div>';
    $html = preg_replace('~<div\s+id="pdpSkeleton"[^>]*>~i', '<div id="pdpSkeleton" style="display:none;">', $html, 1);
    $html = preg_replace('~<div\s+id="pdpContent"\s+style="display:none;"\s*>\s*</div>~i', $serverContent, $html, 1);
    $titleTag = '<title>' . $e($name . ' — the little green house') . '</title>';
    $html = preg_replace('~<title\b[^>]*>.*?</title>~is', $titleTag, $html, 1);
    $html = preg_replace('~<meta\s+name=["\']description["\'][^>]*>~i', '<meta name="description" content="' . $e($description) . '" />', $html, 1);
    $html = preg_replace('~<link\b(?=[^>]*\brel=["\']canonical["\'])[^>]*>~i', '<link id="pageCanonical" rel="canonical" href="' . $e($productUrl) . '" />', $html, 1);

    $openGraph = "\n  <meta property=\"og:title\" content=\"" . $e($name . ' — the little green house') . "\" />"
        . "\n  <meta property=\"og:description\" content=\"" . $e($description) . "\" />"
        . "\n  <meta property=\"og:type\" content=\"product\" />"
        . "\n  <meta property=\"og:url\" content=\"" . $e($productUrl) . "\" />"
        . "\n  <meta property=\"og:image\" content=\"" . $e($image) . "\" />"
        . "\n  <meta property=\"og:site_name\" content=\"the little green house\" />"
        . "\n  <meta name=\"twitter:card\" content=\"summary_large_image\" />"
        . "\n  <meta name=\"twitter:title\" content=\"" . $e($name . ' — the little green house') . "\" />"
        . "\n  <meta name=\"twitter:description\" content=\"" . $e($description) . "\" />"
        . "\n  <meta name=\"twitter:image\" content=\"" . $e($image) . "\" />\n";
    $html = preg_replace('~</head>~i', $openGraph . '</head>', $html, 1);

    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'Product',
        'name' => $name,
        'description' => $description,
        'image' => [$image],
        'sku' => (string) $product['sku'],
        'brand' => ['@type' => 'Brand', 'name' => 'The Little Green House'],
        'offers' => [
            '@type' => 'Offer',
            'url' => $productUrl,
            'priceCurrency' => 'INR',
            'price' => (string) $product['price'],
            'availability' => (int) ($product['online_stock_quantity'] ?? $product['stock_quantity'] ?? 0) > 0
                ? 'https://schema.org/InStock'
                : 'https://schema.org/OutOfStock',
        ],
    ];
    $schemaJson = json_encode($schema, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($schemaJson !== false) {
        $html = preg_replace('~</head>~i', "  <script type=\"application/ld+json\">{$schemaJson}</script>\n</head>", $html, 1);
    }
}

header('Content-Type: text/html; charset=UTF-8');
echo $html;
