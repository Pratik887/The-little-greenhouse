<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title id="pageTitle">product — the little green house</title>
  <meta name="description" id="pageDescription" content="handmade pieces from the little green house studio — pots, candles, and home décor." />
  <link id="pageCanonical" rel="canonical" href="https://thelittlegreenhouse.in/product/" />
  <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🌿</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet" />
  <style>
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1280px;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; }
    html { scroll-behavior: smooth; }

    body {
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
      letter-spacing: 0.01em;
    }

    a { color: inherit; text-decoration: none; }
    ul { list-style: none; }
    img { display: block; width: 100%; height: 100%; object-fit: cover; }
    button { font-family: inherit; cursor: pointer; background: none; border: none; color: inherit; }

    :focus-visible { outline: 2px solid var(--c-700); outline-offset: 3px; border-radius: 4px; }

    .wrap { max-width: var(--container); margin: 0 auto; padding: 0 28px; }

    .grain {
      position: fixed; inset: 0; z-index: 2000; pointer-events: none;
      opacity: 0.035; mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    /* ── header ── */
    .site-header {
      position: sticky; top: 0; z-index: 600;
      background: rgba(251, 247, 241, 0.88);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }
    .header-inner { display: flex; align-items: center; justify-content: space-between; height: 80px; }
    .logo { display: flex; align-items: center; gap: 10px; }
    .logo-mark { color: var(--c-700); display: flex; }
    .logo-text { font-family: var(--font-display); font-size: 1.35rem; color: var(--ink); }
    .logo-text em { font-style: normal; color: var(--c-500); }
    .main-nav { display: flex; gap: 34px; }
    .main-nav a { font-size: 0.95rem; color: var(--ink-soft); position: relative; padding: 4px 0; transition: color 0.3s; }
    .main-nav a::after {
      content: ""; position: absolute; left: 0; bottom: -2px; width: 100%; height: 1.5px;
      background: var(--c-600); transform: scaleX(0); transform-origin: right; transition: transform 0.4s var(--ease-hand);
    }
    .main-nav a:hover::after { transform: scaleX(1); transform-origin: left; }
    .header-actions { display: flex; align-items: center; gap: 6px; }
    .icon-btn {
      width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;
      border-radius: 50%; color: var(--ink-soft); transition: background 0.3s, color 0.3s; position: relative;
    }
    .icon-btn:hover { background: var(--c-100); color: var(--ink); }
    .cart-dot {
      position: absolute; top: 4px; right: 4px; width: 16px; height: 16px;
      border-radius: 50%; background: var(--c-600); color: #fff; font-size: 0.6rem;
      display: none; align-items: center; justify-content: center;
    }
    .menu-toggle { display: none; flex-direction: column; justify-content: center; gap: 5px; width: 40px; height: 40px; }
    .menu-toggle span { display: block; width: 20px; height: 1.5px; background: var(--ink); margin: 0 auto; transition: 0.3s; }
    .menu-toggle.is-open span:nth-child(1) { transform: translateY(6.5px) rotate(45deg); }
    .menu-toggle.is-open span:nth-child(2) { opacity: 0; }
    .menu-toggle.is-open span:nth-child(3) { transform: translateY(-6.5px) rotate(-45deg); }

    /* ── breadcrumb ── */
    .breadcrumb { padding: 18px 0 0; font-size: 0.78rem; color: var(--muted); }
    .breadcrumb a { color: var(--muted); transition: color 0.2s; }
    .breadcrumb a:hover { color: var(--c-600); }
    .breadcrumb span { margin: 0 8px; opacity: 0.5; }

    /* ── product detail layout ── */
    .pdp-wrap { padding: 28px 0 80px; }
    .pdp-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 64px;
      align-items: start;
    }

    /* ── image gallery ── */
    .pdp-gallery { position: sticky; top: 100px; }
    .pdp-main-img {
      width: 100%;
      aspect-ratio: 1 / 1;
      border-radius: var(--radius-lg);
      overflow: hidden;
      background: var(--surface-2);
      border: 1px solid var(--line);
      box-shadow: var(--shadow-soft);
    }
    .pdp-main-img img, .pdp-main-img video { width: 100%; height: 100%; object-fit: cover; }
    .pdp-main-img img { transition: transform 0.6s var(--ease-hand); }
    .pdp-main-img:hover img { transform: scale(1.03); }
    .pdp-thumbs { display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap; }
    .pdp-thumb {
      width: 72px; height: 72px; border-radius: 10px; overflow: hidden;
      border: 2px solid transparent; cursor: pointer; transition: border-color 0.2s;
      background: var(--surface-2); flex-shrink: 0; padding: 0; color: inherit; font: inherit;
    }
    .pdp-thumb.active { border-color: var(--c-600); }
    .pdp-thumb:hover { border-color: var(--c-400); }
    .pdp-thumb img { width: 100%; height: 100%; object-fit: cover; }
    .pdp-thumb span { display: grid; place-items: center; height: 100%; color: var(--c-700); font-size: 0.72rem; }

    /* ── product info ── */
    .pdp-info { padding-top: 8px; }
    .pdp-category { font-size: 0.7rem; letter-spacing: 0.1em; color: var(--c-600); margin-bottom: 10px; }
    .pdp-badge {
      display: inline-block; background: var(--c-600); color: white; padding: 3px 10px;
      border-radius: 20px; font-size: 0.65rem; letter-spacing: 0.05em; margin-left: 8px; vertical-align: middle;
    }
    .pdp-title {
      font-family: var(--font-display); font-size: clamp(1.8rem, 3vw, 2.6rem);
      line-height: 1.15; font-weight: 500; margin-bottom: 16px;
    }
    .pdp-price-row { display: flex; align-items: center; gap: 14px; margin-bottom: 20px; }
    .pdp-price { font-family: var(--font-display); font-size: 1.7rem; color: var(--c-700); font-weight: 500; }
    .pdp-compare { font-size: 1.1rem; color: var(--muted); text-decoration: line-through; }
    .pdp-saving {
      background: #e9efdf; color: #5c6b42; padding: 3px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 600;
    }

    .pdp-stock {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 6px 14px; border-radius: 30px; font-size: 0.8rem; font-weight: 500; margin-bottom: 22px;
    }
    .pdp-stock.in-stock { background: #e9efdf; color: #5c6b42; }
    .pdp-stock.low-stock { background: #fbecd7; color: #a06a1f; }
    .pdp-stock.out-stock { background: #f7e2df; color: #a5423a; }
    .pdp-stock-dot { width: 7px; height: 7px; border-radius: 50%; background: currentColor; }

    .pdp-desc { font-size: 1rem; color: var(--ink-soft); line-height: 1.8; margin-bottom: 28px; }
    .pdp-desc p + p { margin-top: 10px; }

    /* ── qty + add to cart ── */
    .pdp-actions { margin-bottom: 28px; }
    .pdp-qty-row { display: flex; align-items: center; gap: 16px; margin-bottom: 16px; }
    .qty-label { font-size: 0.85rem; color: var(--muted); }
    .qty-stepper {
      display: flex; align-items: center; gap: 0;
      border: 1.5px solid var(--line); border-radius: 50px; overflow: hidden;
    }
    .qty-stepper button {
      width: 38px; height: 38px; display: flex; align-items: center; justify-content: center;
      font-size: 1.1rem; color: var(--ink-soft); transition: background 0.2s;
    }
    .qty-stepper button:hover { background: var(--c-100); color: var(--ink); }
    .qty-stepper .qty-num { width: 36px; text-align: center; font-weight: 600; font-size: 0.95rem; }

    .btn-add-cart {
      width: 100%; padding: 16px; border-radius: 50px; background: var(--ink);
      color: var(--c-100); font-size: 0.95rem; font-weight: 500; letter-spacing: 0.02em;
      box-shadow: var(--shadow-soft); transition: all 0.3s var(--ease-hand); margin-bottom: 12px;
      display: flex; align-items: center; justify-content: center; gap: 8px;
    }
    .btn-add-cart:hover:not(:disabled) { background: var(--c-700); transform: translateY(-2px); box-shadow: var(--shadow-lift); }
    .btn-add-cart:disabled { opacity: 0.5; cursor: not-allowed; }

    .btn-checkout {
      width: 100%; padding: 16px; border-radius: 50px; background: var(--c-600);
      color: white; font-size: 0.95rem; font-weight: 500; letter-spacing: 0.02em;
      box-shadow: 0 4px 16px rgba(181, 108, 65, 0.4); transition: all 0.3s var(--ease-hand);
      display: flex; align-items: center; justify-content: center; gap: 8px;
    }
    .btn-checkout:hover:not(:disabled) { background: var(--c-700); transform: translateY(-2px); }
    .btn-checkout:disabled { opacity: 0.6; cursor: not-allowed; }

    .fastrr-tagline {
      text-align: center; font-size: 0.72rem; color: var(--muted); margin-top: 8px;
      display: flex; align-items: center; justify-content: center; gap: 4px;
    }
    .fastrr-tagline svg { color: var(--c-600); }

    /* ── meta strips ── */
    .pdp-meta { border-top: 1px solid var(--line); padding-top: 20px; display: flex; flex-direction: column; gap: 10px; }
    .pdp-meta-row { display: flex; align-items: center; gap: 10px; font-size: 0.85rem; }
    .pdp-meta-row svg { color: var(--c-600); flex-shrink: 0; }
    .pdp-meta-label { color: var(--muted); }
    .pdp-meta-val { color: var(--ink); font-weight: 500; }

    /* ── skeleton / loading ── */
    .skeleton { background: var(--c-200); border-radius: 8px; animation: pulse 1.4s ease infinite; }
    @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.45; } }

    /* ── error state ── */
    .pdp-error {
      text-align: center; padding: 80px 20px;
    }
    .pdp-error h2 { font-family: var(--font-display); font-size: 2rem; margin-bottom: 12px; color: var(--c-700); }
    .pdp-error p { color: var(--muted); margin-bottom: 24px; }
    .pdp-error a { display: inline-flex; align-items: center; gap: 8px; padding: 14px 28px; border-radius: 50px; background: var(--ink); color: var(--c-100); font-size: 0.9rem; }

    /* ── footer ── */
    .site-footer { background: var(--ink); color: var(--c-200); padding: 70px 0 0; }
    .footer-inner { display: grid; grid-template-columns: 1.8fr 1fr 1fr 1fr; gap: 40px; padding-bottom: 50px; border-bottom: 1px solid rgba(245, 236, 223, 0.12); }
    .footer-brand .logo-text { color: var(--c-100); }
    .footer-brand p { margin: 14px 0 20px; font-size: 0.9rem; color: var(--c-300); max-width: 260px; }
    .socials { display: flex; gap: 12px; }
    .socials a { width: 38px; height: 38px; display: flex; align-items: center; justify-content: center; border-radius: 50%; border: 1px solid rgba(245, 236, 223, 0.2); transition: 0.3s; }
    .socials a:hover { background: var(--c-600); }
    .footer-col h4 { font-family: var(--font-body); font-size: 0.85rem; letter-spacing: 0.1em; color: var(--c-400); margin-bottom: 16px; }
    .footer-col a { display: block; font-size: 0.9rem; color: var(--c-300); margin-bottom: 12px; transition: color 0.2s; }
    .footer-col a:hover { color: white; }
    .footer-bottom { padding: 24px 0; text-align: center; }
    .footer-bottom p { font-size: 0.8rem; color: var(--c-400); }

    /* ── responsive ── */
    @media (max-width: 900px) {
      .pdp-grid { grid-template-columns: 1fr; gap: 36px; }
      .pdp-gallery { position: static; }
      .footer-inner { grid-template-columns: 1fr 1fr; }
    }
    @media (max-width: 760px) {
      .wrap { padding: 0 18px; }
      .main-nav {
        position: fixed; top: 80px; left: 0; right: 0; background: var(--bg);
        flex-direction: column; padding: 16px 28px 28px; gap: 0;
        border-bottom: 1px solid var(--line); transform: translateY(-130%); opacity: 0;
        transition: 0.4s var(--ease-hand); z-index: 500;
      }
      .main-nav.is-open { transform: translateY(0); opacity: 1; }
      .main-nav a { padding: 14px 0; border-bottom: 1px solid var(--line); }
      .menu-toggle { display: flex; }
      .footer-inner { grid-template-columns: 1fr; gap: 30px; }
    }
      input, textarea, select { text-transform: none; }
</style>
  <meta property="og:title" content="product — the little green house" />
  <meta property="og:description" content="handmade pieces from the little green house studio — pots, candles, and home d&#233;cor." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/product/" />
  <meta property="og:site_name" content="the little green house" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="product — the little green house" />
  <meta name="twitter:description" content="handmade pieces from the little green house studio — pots, candles, and home décor." />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
  <div class="grain" aria-hidden="true"></div>

  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo" aria-label="the little green house home">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="34" height="34">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart" id="headerCartBtn">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg>
          <span class="cart-dot" id="cartBadge" aria-label="cart items"></span>
        </a>
        <button class="menu-toggle" id="menuToggle" aria-label="menu" aria-expanded="false" aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <div class="wrap">
      <nav class="breadcrumb" aria-label="breadcrumb" id="breadcrumb">
        <a href="../">home</a><span>›</span>
        <a href="../shop/">shop</a><span>›</span>
        <span id="breadcrumbProduct">loading…</span>
      </nav>
    </div>

    <div class="wrap pdp-wrap">
      <!-- Loading skeleton -->
      <div id="pdpSkeleton">
        <div class="pdp-grid">
          <div>
            <div class="skeleton" style="width:100%;aspect-ratio:1;border-radius:30px;"></div>
            <div style="display:flex;gap:10px;margin-top:12px;">
              <div class="skeleton" style="width:72px;height:72px;border-radius:10px;"></div>
              <div class="skeleton" style="width:72px;height:72px;border-radius:10px;"></div>
            </div>
          </div>
          <div style="display:flex;flex-direction:column;gap:14px;padding-top:8px;">
            <div class="skeleton" style="height:14px;width:100px;border-radius:6px;"></div>
            <div class="skeleton" style="height:44px;width:90%;border-radius:8px;"></div>
            <div class="skeleton" style="height:32px;width:140px;border-radius:8px;"></div>
            <div class="skeleton" style="height:80px;border-radius:8px;"></div>
            <div class="skeleton" style="height:52px;border-radius:50px;"></div>
            <div class="skeleton" style="height:52px;border-radius:50px;"></div>
          </div>
        </div>
      </div>

      <!-- Actual product -->
      <div id="pdpContent" style="display:none;"></div>

      <!-- Error state -->
      <div id="pdpError" style="display:none;" class="pdp-error">
        <h2>product not found</h2>
        <p>this piece may be sold out or no longer available. explore the shop to discover more.</p>
        <a href="../shop/">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
          back to shop
        </a>
      </div>
    </div>
  </main>

  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>handmade pots, candles &amp; home décor — made slowly, on purpose.</p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r="1" /></svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="10" /><path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" /></svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" /></svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <!-- Cart utility -->
  <script src="../cart.js?v=20261013-cart-fix-1"></script>
  <script src="../checkout.js?v=20261013-checkout-fix-1"></script>

  <script>
  (function () {
    'use strict';

    const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[char]);
    const safeMediaUrl = (value) => {
      try {
        const url = new URL(String(value || ''), window.location.href);
        return (url.origin === window.location.origin || url.protocol === 'https:') ? url.href : '';
      } catch (_) { return ''; }
    };

    // ── Read product ID from URL ──────────────────────────────────────
    const params   = new URLSearchParams(window.location.search);
    const productId = parseInt(params.get('id')) || 0;
    const slug      = (params.get('slug') || '').trim();

    let currentProduct = null;
    let currentQty = 1;

    // ── DOM refs ──────────────────────────────────────────────────────
    const skeleton = document.getElementById('pdpSkeleton');
    const content  = document.getElementById('pdpContent');
    const errorEl  = document.getElementById('pdpError');

    // PHP serves the product with the page so the details and checkout controls
    // remain available even when the separate product API request is unavailable.
    try {
      const serverData = document.getElementById('serverProductData');
      if (serverData) currentProduct = JSON.parse(serverData.textContent);
    } catch (_) {}

    // ── Fetch product from API ────────────────────────────────────────
    async function loadProduct() {
      if (currentProduct) {
        skeleton.style.display = 'none';
        renderProduct(currentProduct);
        return;
      }
      try {
        const endpoint = slug
          ? `../api/products?slug=${encodeURIComponent(slug)}`
          : `../api/products/${productId}`;
        const res  = await fetch(endpoint, { headers: { Accept: 'application/json' } });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        const apiProduct = data.product || (Array.isArray(data.products) ? data.products[0] : null);
        if (apiProduct) currentProduct = apiProduct;
        if (!currentProduct && productId) {
          // fallback: search in full list
          const listRes = await fetch('../api/products', { headers: { Accept: 'application/json' } });
          const listData = await listRes.json();
          currentProduct = (listData.products || []).find(p => Number(p.id) === productId) || null;
        }
      } catch (_) {
        // Try fallback in admin's local DB if API is offline
        try {
          const db = JSON.parse(localStorage.getItem('tlgh_admin_local_db') || 'null');
          if (!currentProduct && db && db.products) {
            currentProduct = db.products.find(p =>
              (productId && Number(p.id) === productId) ||
              (slug && (p.slug === slug || p.name.toLowerCase().replace(/\s+/g, '-') === slug))
            ) || null;
          }
        } catch (_2) {}
      }

      skeleton.style.display = 'none';

      if (!currentProduct) {
        errorEl.style.display = 'block';
        return;
      }

      renderProduct(currentProduct);
    }

    // ── Render product HTML ───────────────────────────────────────────
    function renderProduct(p) {
      const fallbackImage = 'https://placehold.co/800x800/E5CDAE/633B2B?text=handmade';
      const media = (Array.isArray(p.images) ? p.images : []).map((item) => {
        const url = safeMediaUrl(item.image_url || item.url);
        if (!url) return null;
        const type = item.media_type || (/\.(mp4|webm)(?:[?#].*)?$/i.test(url) ? 'video' : 'image');
        return { url, type };
      }).filter(Boolean);
      const primaryImage = safeMediaUrl(p.primary_image) || media.find(item => item.type === 'image')?.url || fallbackImage;
      if (!media.some(item => item.url === primaryImage)) media.unshift({ url: primaryImage, type: 'image' });
      const img = primaryImage;
      const imgs = media.length ? media : [{ url: img, type: 'image' }];
      const price = Number(p.price);
      const compare = Number(p.compare_at_price);
      const onlineStock = Number(p.online_stock_quantity ?? p.stock_quantity ?? 0);
      const savingPct = compare > price ? Math.round((1 - price / compare) * 100) : 0;
      const desc = p.description || p.short_description || 'A handmade piece from our studio — created with care, slow craftsmanship and quality materials.';

      let stockHTML = '';
      if (onlineStock > 10) {
        stockHTML = `<span class="pdp-stock in-stock"><span class="pdp-stock-dot"></span>in stock</span>`;
      } else if (onlineStock > 0) {
        stockHTML = `<span class="pdp-stock low-stock"><span class="pdp-stock-dot"></span>only ${onlineStock} left</span>`;
      } else {
        stockHTML = `<span class="pdp-stock out-stock"><span class="pdp-stock-dot"></span>out of stock</span>`;
      }

      // Update page meta
      const pageTitle = `${p.name} — the little green house`;
      const pageDescription = String(p.short_description || p.description || `handmade ${p.name} from the little green house studio`).replace(/\s+/g, ' ').slice(0, 160);
      document.getElementById('pageTitle').textContent = pageTitle;
      document.getElementById('pageDescription').content = pageDescription;
      const canonical = document.querySelector('link[rel="canonical"]');
      if (canonical && p.slug) {
        const canonicalUrl = new URL(canonical.href);
        canonicalUrl.search = `?slug=${encodeURIComponent(p.slug)}`;
        canonical.href = canonicalUrl.href;
      }
      const ogTitle = document.querySelector('meta[property="og:title"]');
      const ogDescription = document.querySelector('meta[property="og:description"]');
      const ogUrl = document.querySelector('meta[property="og:url"]');
      const ogImage = document.querySelector('meta[property="og:image"]');
      if (ogTitle) ogTitle.content = pageTitle;
      if (ogDescription) ogDescription.content = pageDescription;
      if (ogUrl && canonical) ogUrl.content = canonical.href;
      if (ogImage) ogImage.content = img;
      document.getElementById('breadcrumbProduct').textContent = p.name;

      content.innerHTML = `
        <div class="pdp-grid">
          <!-- Gallery -->
          <div class="pdp-gallery">
            <div class="pdp-main-img" id="mainImgWrap">${imgs[0].type === 'video'
              ? `<video id="mainMedia" src="${escapeHtml(imgs[0].url)}" controls playsinline preload="metadata" aria-label="${escapeHtml(p.name)} product video"></video>`
              : `<img id="mainMedia" src="${escapeHtml(img)}" alt="${escapeHtml(p.name)}" fetchpriority="high" />`}</div>
            ${imgs.length > 1 ? `
            <div class="pdp-thumbs" id="thumbsRow">
              ${imgs.map((item, i) => `<button type="button" class="pdp-thumb${i === 0 ? ' active' : ''}" data-src="${escapeHtml(item.url)}" data-type="${item.type}" aria-label="Show ${item.type === 'video' ? 'video' : 'image'} ${i + 1}">${item.type === 'video' ? '<span aria-hidden="true">▶ Video</span>' : `<img src="${escapeHtml(item.url)}" alt="${escapeHtml(p.name)} view ${i + 1}" loading="lazy" />`}</button>`).join('')}
            </div>` : ''}
          </div>

          <!-- Info panel -->
          <div class="pdp-info">
            <p class="pdp-category">${escapeHtml(p.category_name || '')}${p.tag ? `<span class="pdp-badge">${escapeHtml(p.tag)}</span>` : ''}</p>
            <h1 class="pdp-title">${escapeHtml(p.name)}</h1>

            <div class="pdp-price-row">
              <span class="pdp-price">&#8377;${price.toLocaleString('en-IN')}</span>
              ${compare > price ? `<span class="pdp-compare">&#8377;${compare.toLocaleString('en-IN')}</span><span class="pdp-saving">${savingPct}% off</span>` : ''}
            </div>

            ${stockHTML}

            <p class="pdp-desc">${escapeHtml(desc).replace(/\n/g, '<br>')}</p>

            <!-- Qty + actions -->
            <div class="pdp-actions">
              <div class="pdp-qty-row">
                <span class="qty-label">quantity</span>
                <div class="qty-stepper">
                  <button id="qtyMinus" aria-label="decrease quantity">−</button>
                  <span class="qty-num" id="qtyNum">1</span>
                  <button id="qtyPlus" aria-label="increase quantity">+</button>
                </div>
              </div>

              <button class="btn-add-cart" id="btnAddCart" ${onlineStock <= 0 ? 'disabled' : ''}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"/></svg>
                ${onlineStock <= 0 ? 'out of stock' : 'add to cart'}
              </button>

              <button class="btn-checkout" id="btnBuyNow" ${onlineStock <= 0 ? 'disabled' : ''}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                buy now — instant checkout
              </button>
              <p class="fastrr-tagline">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                powered by fastrr • secure express checkout
              </p>
            </div>

            <!-- Product meta -->
            <div class="pdp-meta">
              ${p.sku ? `<div class="pdp-meta-row"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 3h-8l-2 4h12z"/></svg><span class="pdp-meta-label">sku:</span><span class="pdp-meta-val">${escapeHtml(p.sku)}</span></div>` : ''}
              ${p.dimensions ? `<div class="pdp-meta-row"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg><span class="pdp-meta-label">size:</span><span class="pdp-meta-val">${escapeHtml(p.dimensions)}</span></div>` : ''}
              ${p.weight_grams ? `<div class="pdp-meta-row"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a3 3 0 0 1 3 3v1h4l1 14H4L5 6h4V5a3 3 0 0 1 3-3z"/></svg><span class="pdp-meta-label">weight:</span><span class="pdp-meta-val">${Number(p.weight_grams)}g</span></div>` : ''}
              <div class="pdp-meta-row"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 3c-4 0-9 3-9 9s5 9 9 9 9-3 9-9-5-9-9-9z"/></svg><span class="pdp-meta-label">free shipping</span><span class="pdp-meta-val">on orders above &#8377;999</span></div>
              <div class="pdp-meta-row"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg><span class="pdp-meta-label">returns</span><span class="pdp-meta-val">7-day hassle-free returns</span></div>
            </div>
          </div>
        </div>
      `;

      content.style.display = 'block';
      wireEvents(p, onlineStock);
    }

    // ── Wire interactivity ────────────────────────────────────────────
    function wireEvents(p, stock) {
      // The checkout API caps each product at 20 units. Keep the product page
      // quantity control within both that limit and the available online stock.
      const maxOrderQty = Math.min(20, Math.max(0, Number(stock) || 0));

      // Thumb gallery
      document.querySelectorAll('.pdp-thumb').forEach(thumb => {
        thumb.addEventListener('click', () => {
          document.querySelectorAll('.pdp-thumb').forEach(t => t.classList.remove('active'));
          thumb.classList.add('active');
          const main = document.getElementById('mainMedia');
          const url = thumb.dataset.src;
          if (thumb.dataset.type === 'video') {
            const video = document.createElement('video');
            video.id = 'mainMedia'; video.src = url; video.controls = true;
            video.playsInline = true; video.preload = 'metadata';
            video.setAttribute('aria-label', `${p.name} product video`);
            main.replaceWith(video);
          } else if (main.tagName.toLowerCase() === 'video') {
            const image = document.createElement('img');
            image.id = 'mainMedia'; image.src = url; image.alt = `${p.name} product image`;
            main.replaceWith(image);
          } else {
            main.src = url;
          }
        });
      });

      // Qty stepper
      document.getElementById('qtyMinus').addEventListener('click', () => {
        if (currentQty > 1) { currentQty--; document.getElementById('qtyNum').textContent = currentQty; }
      });
      document.getElementById('qtyPlus').addEventListener('click', () => {
        if (currentQty < maxOrderQty) { currentQty++; document.getElementById('qtyNum').textContent = currentQty; }
      });

      // Add to Cart
      document.getElementById('btnAddCart').addEventListener('click', () => {
        if (!currentProduct) return;
        if (!window.TLGHCart || typeof window.TLGHCart.add !== 'function') {
          alert('The cart is still loading. Please try again.');
          return;
        }
        const addedItems = window.TLGHCart.add({
          id: Number(p.id),
          title: p.name,
          price: Number(p.price),
          category: p.category_name || p.category_slug || '',
          img: p.primary_image || '',
          stock: stock
        }, currentQty);
        if (!addedItems) {
          alert('This product is currently out of stock.');
          return;
        }
        const btn = document.getElementById('btnAddCart');
        btn.textContent = '✓ added to cart';
        btn.style.background = 'var(--c-700)';
        setTimeout(() => {
          btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"/></svg> add to cart`;
          btn.style.background = '';
        }, 2000);
      });

      // Buy Now (Fastrr Express Checkout)
      document.getElementById('btnBuyNow').addEventListener('click', async (event) => {
        event.preventDefault();
        const btn = document.getElementById('btnBuyNow');
        btn.disabled = true;
        btn.textContent = 'connecting to secure checkout…';

        try {
          if (!window.TLGHCheckout || typeof window.TLGHCheckout.startCheckout !== 'function') {
            throw new Error('Secure checkout is still loading. Please try again.');
          }
          // Buy now sends only this product to checkout. It must not alter the
          // shopper's saved cart, especially when checkout cannot be started.
          await window.TLGHCheckout.startCheckout(
            [{ product_id: Number(p.id), quantity: currentQty }],
            event,
          );
        } catch (err) {
          alert(err.message);
          btn.disabled = false;
          btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg> buy now — instant checkout`;
        }
      });
    }

    // ── Mobile nav ────────────────────────────────────────────────────
    const menuToggle = document.getElementById('menuToggle');
    const mainNav = document.getElementById('main-nav');
    if (menuToggle && mainNav) {
      menuToggle.addEventListener('click', () => {
        const isOpen = mainNav.classList.toggle('is-open');
        menuToggle.classList.toggle('is-open', isOpen);
        menuToggle.setAttribute('aria-expanded', String(isOpen));
      });
      mainNav.querySelectorAll('a').forEach(link =>
        link.addEventListener('click', () => {
          mainNav.classList.remove('is-open');
          menuToggle.classList.remove('is-open');
          menuToggle.setAttribute('aria-expanded', 'false');
        })
      );
    }

    // ── Header shadow ─────────────────────────────────────────────────
    const header = document.querySelector('.site-header');
    window.addEventListener('scroll', () => {
      header.style.boxShadow = window.scrollY > 20 ? '0 8px 24px -18px rgba(53,29,21,0.35)' : 'none';
    }, { passive: true });

    // ── Boot ──────────────────────────────────────────────────────────
    if (!productId && !slug) {
      skeleton.style.display = 'none';
      errorEl.style.display = 'block';
    } else {
      loadProduct();
    }
  })();
  </script>
</body>

</html>
