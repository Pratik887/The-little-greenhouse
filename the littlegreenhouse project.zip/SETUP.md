# Setup and deployment

This project is a PHP storefront backed by MySQL as its primary database. SQLite is available only when explicitly selected for isolated local development. All page routes and the API must be served by PHP; opening `.php` files with `file://` or a static-only server will not run the application.

## Local development

1. Install PHP 8.1 or newer with PDO MySQL, cURL, and mbstring enabled. On Windows, confirm `php.exe` is on `PATH`.
2. Copy `api/.env.example` to `api/.env`. Set `DB_DRIVER=mysql` and the main MySQL host, port, database, username, and password. Set a unique random `JWT_SECRET` of at least 32 characters and a separate random `SHIPROCKET_WEBHOOK_SECRET`. Add Shiprocket/Fastrr and SMTP credentials only when using those services. Keep `api/.env` private.
3. Start the built-in PHP server from the project root:

   ```powershell
   php -S localhost:8088 router.php
   ```

4. If an owner account must be provisioned through the web setup page, temporarily set `ADMIN_SETUP_ENABLED=true` and a random `ADMIN_SETUP_TOKEN` of at least 32 characters, then open `/api/setup-admin.php` over HTTPS. Use an authorized address and a unique password of at least 14 characters. After provisioning, set `ADMIN_SETUP_ENABLED=false` and remove or rotate the setup token. The page is disabled by default.

5. Open `http://localhost:8088/`, then check `http://localhost:8088/api/health`, `http://localhost:8088/admin/`, and `http://localhost:8088/product/?id=1`.

The local router blocks direct requests to `/api/database/`. Check `/api/health` and confirm it reports `database: connected` before provisioning an admin or testing checkout. Back up the MySQL database before schema changes.

## Apache deployment

1. Deploy the project under an HTTPS virtual host with PHP 8.1+, `mod_rewrite`, and PDO MySQL enabled. Ensure Apache honors the project `.htaccess` files.
2. Keep `api/.env` outside public source control and restrict it to the PHP process owner. Set `APP_ENV=production`, the canonical `APP_URL`, an explicit `CORS_ORIGIN`, `JWT_SECRET`, and a random `SHIPROCKET_WEBHOOK_SECRET`.
3. Set `DB_DRIVER=mysql`, `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, and `DB_PASSWORD`. Use a dedicated database user with only the required privileges, and verify DNS plus TCP access from the PHP host.
4. Provision the first owner using the temporary, token-protected web setup only if required, then disable it as described above. Configure Shiprocket’s tracking webhook to send `X-Shiprocket-Webhook-Secret` matching `SHIPROCKET_WEBHOOK_SECRET`; callbacks fail closed until configured.
5. Configure Fastrr endpoints and credentials per the root README. Keep the return page on the same HTTPS origin as the storefront.
6. Verify health, an SEO product URL, admin sign-in, checkout verification, and the webhook with the provider’s test tools before launch.

The sitemap is served at `/sitemap.xml` and includes active product detail URLs from MySQL. Product pages are server-rendered with canonical URLs and Product structured data; keep them publicly accessible to crawlers and submit the sitemap in Google Search Console.

For an existing MySQL database, apply `api/database/migrations/20261007_add_fastrr_refund_pending.sql` once before using the updated refund workflow. Do not run `api/database/schema.sql` on a populated database; it drops and recreates tables.

Schedule `php api/cron/reconcile-fastrr-orders.php` from the PHP host every 15 minutes as a failsafe for successful checkouts whose return redirect or webhook was missed. The script is CLI-only and uses `APP_URL` to submit provider-verified orders through the same idempotent callback handler.

## Operational notes

- Do not expose database files, `.env` files, logs, backups, or setup credentials through the web server.
- Use HTTPS for the storefront and API. Restrict `CORS_ORIGIN` to the storefront origin instead of `*` in production.
- Back up the database securely and test restoration before upgrades.
- Store webhook secrets in both the environment and the provider’s webhook configuration. Rotate both sides together.
