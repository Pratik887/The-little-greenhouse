/**
 * TLGH Cart Utility - shared across shop, product, and cart pages
 * Cart is stored as JSON in localStorage under key 'tlgh_cart'
 * Format: [{ product_id, quantity, title, price, category, img }]
 */
(function (window) {
  'use strict';

  const CART_KEY = 'tlgh_cart';
  const FREE_SHIPPING_THRESHOLD = 999;
  const SHIPPING_COST = 99;

  function readCart() {
    try {
      const stored = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
      if (!Array.isArray(stored)) return [];
      return stored.map(function (item) {
        if (!item || typeof item !== 'object') return null;
        const productId = Number(item.product_id ?? item.id);
        const quantity = Math.floor(Number(item.quantity) || 0);
        if (!Number.isSafeInteger(productId) || productId < 1 || quantity < 1) return null;
        return {
          ...item,
          product_id: productId,
          quantity: Math.min(20, quantity),
          title: String(item.title || item.name || ''),
          price: Math.max(0, Number(item.price) || 0),
          category: String(item.category || item.category_name || ''),
          img: String(item.img || item.primary_image || ''),
          stock: Math.max(0, Math.floor(Number(item.stock) || 0))
        };
      }).filter(Boolean);
    }
    catch (_) { return []; }
  }

  function writeCart(items) {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
    window.dispatchEvent(new CustomEvent('tlgh:cart:updated', { detail: { items } }));
    updateCartUI();
  }

  function totalItems(items) {
    return items.reduce(function (s, i) { return s + (i.quantity || 0); }, 0);
  }

  function updateCartUI() {
    const items = readCart();
    const count = totalItems(items);
    document.querySelectorAll('.cart-count').forEach(function (el) {
      el.textContent = count;
      el.style.display = count > 0 ? 'flex' : 'none';
    });
    document.querySelectorAll('.cart-dot').forEach(function (dot) {
      if (count > 0) {
        dot.textContent = count;
        dot.setAttribute('style', [
          'display:flex', 'align-items:center', 'justify-content:center',
          'width:16px', 'height:16px', 'border-radius:50%',
          'background:var(--c-600,#b56c41)', 'color:#fff',
          'font-size:0.6rem', 'position:absolute', 'top:4px', 'right:4px'
        ].join(';'));
      } else {
        dot.style.display = 'none';
      }
    });
  }

  const Cart = {
    getItems: readCart,
    getCount: function () { return totalItems(readCart()); },
    getSubtotal: function () {
      return readCart().reduce(function (s, i) { return s + i.price * i.quantity; }, 0);
    },
    getShipping: function () {
      return Cart.getSubtotal() >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_COST;
    },
    getTotal: function () { return Cart.getSubtotal() + Cart.getShipping(); },

    add: function (product, qty) {
      if (!product || !product.id) return;
      qty = Math.max(1, Math.min(20, Math.floor(Number(qty) || 1)));
      const stock = Math.max(0, Math.floor(Number(product.stock) || 0));
      if (stock < 1) return false;
      const items = readCart();
      const existing = items.find(function (i) { return Number(i.product_id) === Number(product.id); });
      if (existing) {
        existing.stock = stock;
        existing.quantity = Math.min(20, stock, existing.quantity + qty);
      } else {
        items.push({
          product_id: Number(product.id),
          quantity: Math.min(qty, stock),
          title: product.title || product.name || '',
          price: Number(product.price) || 0,
          category: product.category || product.category_name || '',
          img: product.img || product.primary_image || 'https://placehold.co/600x450/E5CDAE/633B2B?text=handmade',
          stock: stock
        });
      }
      writeCart(items);
      return items;
    },

    updateQty: function (productId, newQty) {
      const items = readCart();
      const idx = items.findIndex(function (i) { return Number(i.product_id) === Number(productId); });
      if (idx === -1) return;
      if (newQty <= 0) { items.splice(idx, 1); } else { items[idx].quantity = newQty; }
      writeCart(items);
    },

    remove: function (productId) {
      writeCart(readCart().filter(function (i) { return Number(i.product_id) !== Number(productId); }));
    },

    clear: function () { writeCart([]); },

    formatPrice: function (amount) { return '\u20b9' + Number(amount).toLocaleString('en-IN'); },

    FREE_SHIPPING_THRESHOLD: FREE_SHIPPING_THRESHOLD,
    SHIPPING_COST: SHIPPING_COST,

    init: function () {
      updateCartUI();
      window.addEventListener('storage', function (e) {
        if (e.key === CART_KEY) updateCartUI();
      });
    }
  };

  window.TLGHCart = Cart;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', Cart.init);
  } else {
    Cart.init();
  }

}(window));
