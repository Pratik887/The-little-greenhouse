<?php
declare(strict_types=1);

/**
 * setup-admin.php
 *
 * Browser-based administrator provisioning page.
 *
 * Required server environment variable:
 *   ADMIN_SETUP_TOKEN = a long, random secret (at least 32 characters)
 *
 * Keep this file protected and remove it from the public web root after setup.
 */

session_start();
require_once __DIR__ . '/config/config.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");

$allowedEmails = [
    'admin@thelittlegreenhouse.com',
    'admin@truelokal.com',
];

$message = '';
$messageType = '';
$email = '';
$setupToken = '';
$setupRequested = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';

if (empty($_SESSION['setup_csrf'])) {
    $_SESSION['setup_csrf'] = bin2hex(random_bytes(32));
}

/**
 * Compare secrets without timing-sensitive string comparison.
 * Configure ADMIN_SETUP_TOKEN in the hosting environment.
 */
$setupEnabled = filter_var(get_config('ADMIN_SETUP_ENABLED', 'false'), FILTER_VALIDATE_BOOLEAN);
$expectedSetupToken = (string) get_config('ADMIN_SETUP_TOKEN', '');

if (!$setupEnabled || strlen($expectedSetupToken) < 32) {
    http_response_code(503);
    $message = 'Web setup is disabled. Enable it temporarily with ADMIN_SETUP_ENABLED=true and configure a strong ADMIN_SETUP_TOKEN (at least 32 characters).';
    $messageType = 'error';
} elseif ($setupRequested) {
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');
    $confirmPassword = (string) ($_POST['confirm_password'] ?? '');
    $setupToken = (string) ($_POST['setup_token'] ?? '');
    $csrf = (string) ($_POST['csrf_token'] ?? '');

    if (!hash_equals((string) $_SESSION['setup_csrf'], $csrf)) {
        http_response_code(403);
        $message = 'Your session expired or the form could not be verified. Reload the page and try again.';
        $messageType = 'error';
    } elseif (!hash_equals($expectedSetupToken, $setupToken)) {
        http_response_code(403);
        $message = 'Invalid setup token.';
        $messageType = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !in_array($email, $allowedEmails, true)) {
        $message = 'This email address is not authorized to create an administrator account.';
        $messageType = 'error';
    } elseif (strlen($password) < 14) {
        $message = 'Password must contain at least 14 characters.';
        $messageType = 'error';
    } elseif ($password !== $confirmPassword) {
        $message = 'Passwords do not match.';
        $messageType = 'error';
    } else {
        try {
            require_once __DIR__ . '/config/database.php';
            $db = Database::getConnection();

            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            if ($passwordHash === false) {
                throw new RuntimeException('Password hashing failed.');
            }

            $existing = $db->prepare('SELECT id FROM admins WHERE email = ? LIMIT 1');
            $existing->execute([$email]);
            $adminId = $existing->fetchColumn();

            if ($adminId) {
                $stmt = $db->prepare(
                    'UPDATE admins SET password_hash = ?, is_active = 1 WHERE id = ?'
                );
                $stmt->execute([$passwordHash, $adminId]);
            } else {
                $stmt = $db->prepare(
                    'INSERT INTO admins (full_name, email, password_hash, role, is_active)
                     VALUES (?, ?, ?, ?, 1)'
                );
                $stmt->execute(['Store Administrator', $email, $passwordHash, 'OWNER']);
            }

            // Rotate the CSRF token after successful provisioning.
            $_SESSION['setup_csrf'] = bin2hex(random_bytes(32));
            $message = "Administrator account for {$email} has been provisioned successfully.";
            $messageType = 'success';

            // Clear sensitive form values from memory where practical.
            $password = '';
            $confirmPassword = '';
            $setupToken = '';
        } catch (Throwable $e) {
            // Log details only on the server; never expose database errors to the browser.
            error_log('Administrator setup failed: ' . $e->getMessage());
            http_response_code(500);
            $message = 'Unable to create the administrator account. Check the server error log and database configuration.';
            $messageType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator Setup</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            min-height: 100vh; display: flex; align-items: center; justify-content: center;
            font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background: linear-gradient(135deg, #f5f7fa, #e8edf3); padding: 20px;
        }
        .setup-container { width: 100%; max-width: 460px; }
        .card {
            background: #fff; border-radius: 18px; padding: 36px;
            box-shadow: 0 20px 50px rgba(0,0,0,.10); border: 1px solid #e5e7eb;
        }
        .logo {
            width: 58px; height: 58px; display: flex; align-items: center;
            justify-content: center; border-radius: 14px; background: #111827;
            color: #fff; font-size: 25px; font-weight: 700; margin-bottom: 22px;
        }
        h1 { font-size: 27px; color: #111827; margin-bottom: 8px; }
        .subtitle { color: #6b7280; font-size: 14px; line-height: 1.6; margin-bottom: 28px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 8px; }
        input {
            width: 100%; min-height: 48px; padding: 0 14px; border: 1px solid #d1d5db;
            border-radius: 10px; outline: none; font-size: 15px; transition: border-color .2s, box-shadow .2s;
        }
        input:focus { border-color: #111827; box-shadow: 0 0 0 3px rgba(17,24,39,.08); }
        .password-wrapper { position: relative; }
        .password-wrapper input { padding-right: 65px; }
        .toggle-password {
            position: absolute; right: 10px; top: 50%; transform: translateY(-50%);
            border: 0; background: transparent; cursor: pointer; color: #6b7280;
            font-size: 13px; font-weight: 600;
        }
        .hint { margin-top: 8px; font-size: 12px; color: #6b7280; }
        button[type="submit"] {
            width: 100%; min-height: 50px; border: 0; border-radius: 10px;
            background: #111827; color: #fff; font-size: 15px; font-weight: 600; cursor: pointer;
        }
        button[type="submit"]:hover { background: #1f2937; }
        .message { padding: 13px 15px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; line-height: 1.5; }
        .message.success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #047857; }
        .message.error { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; }
        .security-note {
            margin-top: 22px; padding: 13px; border-radius: 10px; background: #f9fafb;
            color: #6b7280; font-size: 12px; line-height: 1.5; text-align: center;
        }
        @media (max-width: 480px) { .card { padding: 26px 20px; } h1 { font-size: 24px; } }
    </style>
</head>
<body>
<div class="setup-container">
    <div class="card">
        <div class="logo" aria-hidden="true">A</div>
        <h1>Administrator Setup</h1>
        <p class="subtitle">Create or reset an administrator account for the management system.</p>

        <?php if ($message !== ''): ?>
            <div class="message <?= htmlspecialchars($messageType, ENT_QUOTES, 'UTF-8') ?>" role="status">
                <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if ($setupEnabled && strlen($expectedSetupToken) >= 32): ?>
        <form method="POST" action="" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string) $_SESSION['setup_csrf'], ENT_QUOTES, 'UTF-8') ?>">

            <div class="form-group">
                <label for="setup_token">Setup token</label>
                <div class="password-wrapper">
                    <input type="password" id="setup_token" name="setup_token" required autocomplete="off">
                    <button type="button" class="toggle-password" onclick="togglePassword('setup_token', this)">Show</button>
                </div>
                <div class="hint">Use the token configured by the server administrator.</div>
            </div>

            <div class="form-group">
                <label for="email">Administrator email</label>
                <input type="email" id="email" name="email" placeholder="admin@example.com" required
                       autocomplete="email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>">
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password" placeholder="Enter a strong password"
                           minlength="14" required autocomplete="new-password">
                    <button type="button" class="toggle-password" onclick="togglePassword('password', this)">Show</button>
                </div>
                <div class="hint">Minimum 14 characters.</div>
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm password</label>
                <div class="password-wrapper">
                    <input type="password" id="confirm_password" name="confirm_password"
                           placeholder="Re-enter your password" minlength="14" required autocomplete="new-password">
                    <button type="button" class="toggle-password" onclick="togglePassword('confirm_password', this)">Show</button>
                </div>
            </div>

            <button type="submit">Provision Administrator</button>
        </form>
        <?php endif; ?>

        <div class="security-note">
            Only authorized administrator email addresses can be provisioned.
            Passwords are securely hashed before storage. Remove this setup page after use.
        </div>
    </div>
</div>
<script>
function togglePassword(id, button) {
    const input = document.getElementById(id);
    const showing = input.type === "password";
    input.type = showing ? "text" : "password";
    button.textContent = showing ? "Hide" : "Show";
}
document.querySelector("form")?.addEventListener("submit", function (event) {
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm_password").value;
    if (password !== confirmPassword) {
        event.preventDefault();
        alert("Passwords do not match.");
    }
});
</script>
</body>
</html>
