<?php
// CLI-only failsafe for checkout returns/webhooks that were not delivered.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit('Not found');
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../utils/Fastrr.php';

$config = require __DIR__ . '/../config/config.php';
$appUrl = rtrim((string) ($config['app']['url'] ?? ''), '/');
if (!filter_var($appUrl, FILTER_VALIDATE_URL) || !in_array(strtolower((string) parse_url($appUrl, PHP_URL_SCHEME)), ['http', 'https'], true)) {
    fwrite(STDERR, "APP_URL must be a valid URL before Fastrr order reconciliation can run.\n");
    exit(2);
}

try {
    $db = Database::getConnection();
    $from = gmdate('Y-m-d\T00:00:00\Z', strtotime('-14 days'));
    $to = gmdate('Y-m-d\TH:i:s\Z');
    $limit = 250;
    $verified = 0;
    $pending = 0;
    $failed = 0;
    $listed = 0;

    for ($page = 0; $page < 100; $page++) {
        $list = Fastrr::orderList($from, $to, 'SUCCESS', $limit, $page);
        if (empty($list['success'])) {
            fwrite(STDERR, "Shiprocket order list request failed: " . ($list['message'] ?? 'unknown provider error') . "\n");
            exit(3);
        }

        $result = $list['data'];
        $remoteOrders = $result['data'] ?? [];
        if (!is_array($remoteOrders) || !$remoteOrders) {
            break;
        }
        $listed += count($remoteOrders);

        foreach ($remoteOrders as $remoteOrder) {
            $providerOrderId = trim((string) ($remoteOrder['id'] ?? ''));
            if ($providerOrderId === '') {
                continue;
            }
            $checkout = $db->prepare('SELECT checkout_ref FROM fastrr_checkouts WHERE fastrr_order_id = ? AND processed_order_id IS NULL LIMIT 1');
            $checkout->execute([$providerOrderId]);
            $ref = $checkout->fetchColumn();
            if (!$ref) {
                continue;
            }

            $body = json_encode(['ref' => (string) $ref, 'order_id' => $providerOrderId], JSON_UNESCAPED_SLASHES);
            $ch = curl_init($appUrl . '/api/fastrr/verify');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 45,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
            ]);
            $raw = curl_exec($ch);
            $httpStatus = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            $response = is_string($raw) ? json_decode($raw, true) : null;
            if ($httpStatus >= 200 && $httpStatus < 300 && is_array($response) && !empty($response['success'])) {
                if (empty($response['already_processed'])) {
                    $verified++;
                }
            } elseif ($httpStatus === 409) {
                // The provider may list an order before payment/address details
                // are fully finalized; a later cron run retries it.
                $pending++;
            } else {
                $failed++;
                if ($curlError !== '') {
                    error_log('Fastrr reconcile callback request failed: ' . $curlError);
                }
            }
        }

        $total = (int) ($result['total'] ?? 0);
        if (count($remoteOrders) < $limit || ($total > 0 && (($page + 1) * $limit) >= $total)) {
            break;
        }
    }

    fwrite(STDOUT, json_encode([
        'success' => true,
        'listed' => $listed,
        'processed' => $verified,
        'pending' => $pending,
        'failed' => $failed,
    ], JSON_UNESCAPED_SLASHES) . PHP_EOL);
} catch (Throwable $e) {
    error_log('Fastrr order reconciliation failed: ' . $e->getMessage());
    fwrite(STDERR, "Fastrr order reconciliation failed. Check the PHP server error log.\n");
    exit(1);
}
