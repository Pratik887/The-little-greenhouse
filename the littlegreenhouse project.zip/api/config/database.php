<?php
/**
 * Database Connection using PDO
 */

class Database {
    private static ?PDO $instance = null;

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            $config = require __DIR__ . '/config.php';
            $db = $config['db'];

            if (($db['driver'] ?? 'mysql') === 'sqlite') {
                try {
                    if (!in_array('sqlite', PDO::getAvailableDrivers(), true)) {
                        throw new RuntimeException('The PDO SQLite driver is not enabled.');
                    }
                    $databasePath = $db['database'];
                    if (!str_starts_with($databasePath, '/') && !preg_match('/^[A-Za-z]:[\\\\\/]/', $databasePath)) {
                        $databasePath = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . $databasePath;
                    }
                    $dir = dirname($databasePath);
                    if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) {
                        throw new RuntimeException('The SQLite database directory could not be created.');
                    }
                    if (file_exists($databasePath) && !is_writable($databasePath)) {
                        throw new RuntimeException('The SQLite database file is not writable.');
                    }
                    self::$instance = new PDO('sqlite:' . $databasePath, null, null, [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                    ]);
                    self::$instance->exec('PRAGMA foreign_keys = ON');
                    self::$instance->sqliteCreateFunction('NOW', static fn() => date('Y-m-d H:i:s'));
                    try {
                        self::migrateInventoryColumns(self::$instance);
                    } catch (Throwable $ignore) {}
                    self::$instance->exec(file_get_contents(__DIR__ . '/../database/sqlite-schema.sql'));
                    self::migrateInventoryColumns(self::$instance);
                    self::ensureSiteMediaTable(self::$instance);
                    return self::$instance;
                } catch (Throwable $e) {
                    throw new RuntimeException('SQLite database initialization failed: ' . $e->getMessage(), 0, $e);
                }
            }
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                $db['host'],
                $db['port'],
                $db['database'],
                $db['charset']
            );

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];

            try {
                self::$instance = new PDO($dsn, $db['username'], $db['password'], $options);
                self::migrateMysqlInventoryColumns(self::$instance);
                self::ensureSiteMediaTable(self::$instance);
            } catch (PDOException $e) {
                $sqlState = (string) ($e->errorInfo[0] ?? $e->getCode());
                $driverCode = (string) ($e->errorInfo[1] ?? 'n/a');
                error_log("MySQL connection/setup failed (SQLSTATE {$sqlState}, driver code {$driverCode}): " . $e->getMessage());
                throw new RuntimeException('Database connection failed.', 0, $e);
            }
        }

        return self::$instance;
    }

    /** Keep old SQLite databases compatible while separating store and web stock. */
    private static function migrateInventoryColumns(PDO $pdo): void {
        $columns = array_column($pdo->query('PRAGMA table_info(products)')->fetchAll(), 'name');
        if (!in_array('online_stock_quantity', $columns, true)) {
            $pdo->exec('ALTER TABLE products ADD COLUMN online_stock_quantity INTEGER');
            // Existing stock belonged to the web catalog before this split.
            $pdo->exec('UPDATE products SET online_stock_quantity = stock_quantity');
        }
        if (!in_array('local_stock_quantity', $columns, true)) {
            $pdo->exec('ALTER TABLE products ADD COLUMN local_stock_quantity INTEGER DEFAULT 0');
        }
    }

    /** Add the online/local stock fields required by checkout to older MySQL schemas. */
    private static function migrateMysqlInventoryColumns(PDO $pdo): void {
        $stmt = $pdo->prepare('SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
        $stmt->execute(['products']);
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        if (!$columns) {
            return; // Fresh database not imported yet.
        }

        if (!in_array('online_stock_quantity', $columns, true)) {
            $pdo->exec('ALTER TABLE products ADD COLUMN online_stock_quantity INT NULL DEFAULT NULL AFTER stock_quantity');
            $pdo->exec('UPDATE products SET online_stock_quantity = stock_quantity WHERE online_stock_quantity IS NULL');
        }
        if (!in_array('local_stock_quantity', $columns, true)) {
            $pdo->exec('ALTER TABLE products ADD COLUMN local_stock_quantity INT NOT NULL DEFAULT 0 AFTER online_stock_quantity');
        }
    }

    private static function ensureSiteMediaTable(PDO $pdo): void {
        $pdo->exec('CREATE TABLE IF NOT EXISTS site_media (
            slot VARCHAR(50) PRIMARY KEY,
            image_url VARCHAR(500) NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )');
    }
}
