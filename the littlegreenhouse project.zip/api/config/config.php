<?php
/**
 * The Little Green House - Configuration Settings
 * 
 * Supports environment variables or default web server settings.
 */

// Report errors in development, suppress in production
error_reporting(E_ALL);
ini_set('display_errors', '0');

// Prefer the API's deployment config. A stale project-root .env must not
// override the canonical URL or database settings configured for the API.
$envFile = __DIR__ . '/../.env';
if (!file_exists($envFile)) {
    $envFile = __DIR__ . '/../../.env';
}
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line) || strpos($line, '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            // Remove enclosing quotes if any
            if (preg_match('/^(["\'])(.*)\1$/', $value, $matches)) {
                $value = $matches[2];
            }
            // Hosting-panel / process variables take precedence over the file.
            if (getenv($key) === false && !array_key_exists($key, $_SERVER) && !array_key_exists($key, $_ENV)) {
                putenv("$key=$value");
                $_ENV[$key] = $value;
                $_SERVER[$key] = $value;
            }
        }
    }
}

// This file is intentionally loaded by API helpers as well as the router.
// Guard the helper so repeat includes do not cause a fatal redeclaration error.
if (!function_exists('get_config')) {
    function get_config($key, $default = null) {
        $val = getenv($key);
        if ($val === false) {
            $val = $_ENV[$key] ?? $_SERVER[$key] ?? $default;
        }
        return $val;
    }
}

$jwtSecret = get_config('JWT_SECRET');
if (!is_string($jwtSecret) || strlen($jwtSecret) < 32) {
    throw new RuntimeException('JWT_SECRET must be configured with at least 32 characters.');
}

return [
    'app' => [
        'name'        => 'The Little Green House',
        'url'         => get_config('APP_URL', 'https://thelittlegreenhouse.in'),
        'env'         => get_config('APP_ENV', 'development'), // 'production' or 'development'
        'cors_origin' => get_config('CORS_ORIGIN', '*'),
        'free_shipping_threshold' => (float) get_config('FREE_SHIPPING_THRESHOLD', 999.00),
        'default_shipping_cost'   => (float) get_config('DEFAULT_SHIPPING_COST', 99.00),
    ],

    'db' => [
        // MySQL is the durable primary database. SQLite is only used when
        // explicitly selected for local development.
        'driver'   => get_config('DB_DRIVER', 'mysql'),
        // cPanel installs MySQL on the same hosting account by default.
        // Set DB_HOST explicitly when the provider gives you a remote DB host.
        'host'     => get_config('DB_HOST', 'localhost'),
        'port'     => get_config('DB_PORT', '3306'),
        'database' => get_config('DB_DATABASE', 'thelittlegreenhouse'),
        'username' => get_config('DB_USERNAME', 'root'),
        'password' => get_config('DB_PASSWORD', ''),
        'charset'  => 'utf8mb4',
    ],

    'jwt' => [
        'secret'     => $jwtSecret,
        'expiry_admin'    => (int) get_config('JWT_EXPIRY_ADMIN', 86400 * 7), // 7 days in seconds
        'expiry_customer' => (int) get_config('JWT_EXPIRY_CUSTOMER', 86400 * 30), // 30 days
        'issuer'     => 'thelittlegreenhouse.com',
    ],

    'shiprocket' => [
        'email'         => get_config('SHIPROCKET_EMAIL', ''),
        'password'      => get_config('SHIPROCKET_PASSWORD', ''),
        'base_url'      => 'https://apiv2.shiprocket.in/v1/external',
        'pickup_pin'    => get_config('SHIPROCKET_PICKUP_PINCODE', '110001'),
        'pickup_name'   => get_config('SHIPROCKET_PICKUP_LOCATION', 'TLGH Studio Delhi'),
        'channel_id'    => get_config('SHIPROCKET_CHANNEL_ID', ''),
        'webhook_secret'=> get_config('SHIPROCKET_WEBHOOK_SECRET', ''),
    ],

    'fastrr' => [
        'api_key' => get_config('FASTRR_API_KEY', ''),
        'api_secret' => get_config('FASTRR_API_SECRET', ''),
        'base_url' => get_config('FASTRR_BASE_URL', 'https://checkout-api.shiprocket.com'),
        'checkout_script' => get_config('FASTRR_CHECKOUT_SCRIPT', 'https://checkout-ui.shiprocket.com/assets/js/channels/shopify.js'),
        'checkout_style' => get_config('FASTRR_CHECKOUT_STYLE', 'https://checkout-ui.shiprocket.com/assets/styles/shopify.css'),
        'ssl_verify' => filter_var(get_config('FASTRR_SSL_VERIFY', 'true'), FILTER_VALIDATE_BOOLEAN),
    ],

    'mail' => [
        'driver'       => get_config('MAIL_DRIVER', 'smtp'), // 'smtp' or 'mail'
        'host'         => get_config('MAIL_HOST', 'smtp.mailtrap.io'),
        'port'         => (int) get_config('MAIL_PORT', 587),
        'username'     => get_config('MAIL_USERNAME', ''),
        'password'     => get_config('MAIL_PASSWORD', ''),
        'encryption'   => get_config('MAIL_ENCRYPTION', 'tls'), // 'tls', 'ssl', or null
        'from_address' => get_config('MAIL_FROM_ADDRESS', 'orders@thelittlegreenhouse.com'),
        'from_name'    => 'The Little Green House',
        'admin_email'  => get_config('ADMIN_EMAIL', 'owner@thelittlegreenhouse.com'),
    ],
];
