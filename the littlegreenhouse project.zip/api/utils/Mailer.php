<?php
/**
 * Transactional Email Dispatcher for The Little Green House
 *
 * Supports SMTP (with TLS/SSL) and native PHP mail() fallback.
 */

class Mailer
{
    private static function getConfig(): array
    {
        $config = require __DIR__ . '/../config/config.php';
        return $config['mail'];
    }

    /**
     * Send email via SMTP or native mail()
     */
    public static function send(string $to, string $subject, string $htmlContent): bool
    {
        $cfg = self::getConfig();

        // If SMTP credentials configured, attempt SMTP delivery
        if (! empty($cfg['host']) && ! empty($cfg['username']) && ! empty($cfg['password'])) {
            try {
                return self::sendSmtp($to, $subject, $htmlContent, $cfg);
            } catch (Exception $e) {
                error_log("SMTP send error: " . $e->getMessage() . ". Falling back to native mail().");
            }
        }

        // Native PHP mail fallback
        $headers = [
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=utf-8',
            'From: ' . sprintf('%s <%s>', $cfg['from_name'], $cfg['from_address']),
            'Reply-To: ' . $cfg['from_address'],
            'X-Mailer: PHP/' . phpversion(),
        ];

        return @mail($to, $subject, $htmlContent, implode("\r\n", $headers));
    }

    /**
     * Lightweight socket SMTP client supporting STARTTLS/SSL and AUTH LOGIN
     */
    private static function sendSmtp(string $to, string $subject, string $html, array $cfg): bool
    {
        $host    = $cfg['host'];
        $port    = (int) $cfg['port'];
        $timeout = 15;

        $prefix = ($cfg['encryption'] === 'ssl') ? 'ssl://' : '';
        $socket = @fsockopen($prefix . $host, $port, $errno, $errstr, $timeout);

        if (! $socket) {
            throw new Exception("Unable to connect to SMTP host: $errstr ($errno)");
        }

        $read = function () use ($socket) {
            $data = '';
            while ($str = fgets($socket, 515)) {
                $data .= $str;
                if (substr($str, 3, 1) === ' ') {
                    break;
                }

            }
            return $data;
        };

        $write  = function (string $cmd) use ($socket) {
            fputs($socket, $cmd . "\r\n");
        };

        $read(); // Initial 220 banner

        $write("EHLO " . ($cfg['host'] ?: 'localhost'));
        $ehlo = $read();

        // Start TLS if requested
        if ($cfg['encryption'] === 'tls') {
            $write("STARTTLS");
            $tlsRes = $read();
            if (strpos($tlsRes, '220') !== 0) {
                throw new Exception("STARTTLS rejected: $tlsRes");
            }
            if (! stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                throw new Exception("Failed to negotiate TLS");
            }
            $write("EHLO " . ($cfg['host'] ?: 'localhost'));
            $read();
        }

        // Authenticate
        $write("AUTH LOGIN");
        $read();
        $write(base64_encode($cfg['username']));
        $read();
        $write(base64_encode($cfg['password']));
        $authRes = $read();
        if (strpos($authRes, '235') !== 0) {
            throw new Exception("SMTP Authentication failed: $authRes");
        }

        // Send mail envelope
        $write("MAIL FROM: <" . $cfg['from_address'] . ">");
        $read();
        $write("RCPT TO: <" . $to . ">");
        $read();
        $write("DATA");
        $read();

        // Body with headers
        $headers = "From: =?UTF-8?B?" . base64_encode($cfg['from_name']) . "?= <" . $cfg['from_address'] . ">\r\n";
        $headers .= "To: <$to>\r\n";
        $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "Date: " . date(DATE_RFC2822) . "\r\n";

        $write($headers . "\r\n" . $html . "\r\n.");
        $res = $read();
        $write("QUIT");
        fclose($socket);

        return (strpos($res, '250') === 0);
    }

    /**
     * 1. Password changed notification to Admin
     */
    public static function sendPasswordChangedAlert(string $adminEmail, string $adminName, ?string $ipAddress = null): bool
    {
        $ipInfo  = $ipAddress ? "<p style='color: #666; font-size: 13px;'>IP Address: <strong>{$ipAddress}</strong></p>" : "";
        $timeStr = date('F j, Y, g:i a e');

        $html = self::wrapTemplate("Password Changed Alert", "
            <h2 style='color: #1a3320; margin-top: 0;'>Password Security Notification</h2>
            <p>Hello <strong>" . htmlspecialchars($adminName) . "</strong>,</p>
            <p>Your password for <strong>The Little Green House</strong> administration portal was successfully updated on <strong>{$timeStr}</strong>.</p>
            {$ipInfo}
            <div style='background-color: #f7faf7; border-left: 4px solid #2e5a36; padding: 14px 18px; margin: 20px 0; font-size: 14px; color: #2c4431;'>
                If you made this change, you can safely ignore this email. If you did <strong>not</strong> authorize this change, please immediately reset your password and contact support.
            </div>
        ");

        return self::send($adminEmail, "Security Alert: Password Changed - The Little Green House", $html);
    }

    /**
     * 2. Password reset link with security token
     */
    public static function sendPasswordResetLink(string $toEmail, string $token, string $name, string $userType = 'ADMIN'): bool
    {
        $cfg      = require __DIR__ . '/../config/config.php';
        $appUrl   = rtrim($cfg['app']['url'], '/');
        $resetUrl = "{$appUrl}/admin/?reset_token=" . urlencode($token);

        $html = self::wrapTemplate("Reset Your Password", "
            <h2 style='color: #1a3320; margin-top: 0;'>Password Reset Request</h2>
            <p>Hello <strong>" . htmlspecialchars($name) . "</strong>,</p>
            <p>A password reset was requested for your {$userType} account at <strong>The Little Green House</strong>.</p>
            <p style='text-align: center; margin: 30px 0;'>
                <a href='{$resetUrl}' style='background-color: #2e5a36; color: #ffffff; text-decoration: none; padding: 12px 28px; border-radius: 4px; font-weight: bold; display: inline-block;'>Reset Password</a>
            </p>
            <p style='font-size: 13px; color: #666;'>Or copy and paste this link into your browser:<br><a href='{$resetUrl}' style='color: #2e5a36;'>{$resetUrl}</a></p>
            <p style='font-size: 13px; color: #888;'>This link will expire in 1 hour. If you didn't request a password reset, please ignore this email.</p>
        ");

        return self::send($toEmail, "Password Reset Request - The Little Green House", $html);
    }

    /**
     * 3. Admin operation notification (Staff added, deleted, or role changed)
     */
    public static function sendAdminOperationAlert(string $adminEmail, string $operation, array $details): bool
    {
        $detailsHtml = "<ul style='padding-left: 20px; line-height: 1.6; color: #333;'>";
        foreach ($details as $key => $val) {
            $formattedKey  = ucwords(str_replace('_', ' ', $key));
            $formattedVal  = is_array($val) ? json_encode($val) : htmlspecialchars((string) $val);
            $detailsHtml  .= "<li><strong>{$formattedKey}:</strong> {$formattedVal}</li>";
        }
        $detailsHtml .= "</ul>";

        $timeStr = date('F j, Y, g:i a e');

        $html  = self::wrapTemplate("Admin Operation Alert", "
            <h2 style='color: #1a3320; margin-top: 0;'>Admin Action Notification</h2>
            <p>An administrative operation was executed on <strong>The Little Green House</strong> portal:</p>
            <div style='background-color: #f7faf7; border-left: 4px solid #2e5a36; padding: 12px 18px; margin: 15px 0;'>
                <strong style='font-size: 16px; color: #1a3320;'>" . htmlspecialchars($operation) . "</strong><br>
                <span style='font-size: 13px; color: #666;'>Time: {$timeStr}</span>
            </div>
            <h4 style='color: #2c4431; margin-bottom: 8px;'>Operation Details:</h4>
            {$detailsHtml}
        ");

        return self::send($adminEmail, "Admin Activity Alert: {$operation} - The Little Green House", $html);
    }

    /**
     * 4. New customer order alert to store admin
     */
    public static function sendNewOrderAdminNotification(array $order): bool
    {
        $cfg        = self::getConfig();
        $adminEmail = $cfg['admin_email'];

        $itemsHtml      = self::renderOrderItemsTable($order['items'] ?? []);
        $totalFormatted = number_format((float) $order['total_amount'], 2);

        $html = self::wrapTemplate("New Order Received", "
            <h2 style='color: #1a3320; margin-top: 0;'>New Order Placed: #" . htmlspecialchars($order['order_number']) . "</h2>
            <p>A new order has been placed on <strong>The Little Green House</strong> website.</p>

            <table style='width: 100%; margin: 15px 0; border-collapse: collapse; font-size: 14px;'>
                <tr><td style='padding: 6px 0; color: #666;'>Customer:</td><td><strong>" . htmlspecialchars($order['customer_name']) . "</strong></td></tr>
                <tr><td style='padding: 6px 0; color: #666;'>Email:</td><td>" . htmlspecialchars($order['customer_email']) . "</td></tr>
                <tr><td style='padding: 6px 0; color: #666;'>Phone:</td><td>" . htmlspecialchars($order['customer_phone']) . "</td></tr>
                <tr><td style='padding: 6px 0; color: #666;'>Payment Method:</td><td>" . htmlspecialchars($order['payment_method']) . " (" . htmlspecialchars($order['payment_status']) . ")</td></tr>
                <tr><td style='padding: 6px 0; color: #666;'>Shiprocket Status:</td><td>" . htmlspecialchars($order['shiprocket_status'] ?? 'Shipment Created') . "</td></tr>
                <tr><td style='padding: 6px 0; color: #666;'>Order Total:</td><td><strong style='font-size: 16px; color: #2e5a36;'>₹{$totalFormatted}</strong></td></tr>
            </table>

            <h4 style='color: #1a3320; margin-top: 20px; border-bottom: 2px solid #e2e8e2; padding-bottom: 6px;'>Order Items</h4>
            {$itemsHtml}
        ");

        return self::send($adminEmail, "New Order #" . $order['order_number'] . " Received (₹{$totalFormatted})", $html);
    }

    /**
     * 5. Order confirmation to customer
     */
    public static function sendOrderConfirmationCustomer(array $order): bool
    {
        $customerEmail  = $order['customer_email'];
        $itemsHtml      = self::renderOrderItemsTable($order['items'] ?? []);
        $totalFormatted = number_format((float) $order['total_amount'], 2);
        $trackingHtml   = ! empty($order['tracking_url'])
            ? "<p style='margin: 15px 0;'><a href='{$order['tracking_url']}' style='background-color: #2e5a36; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px; display: inline-block;'>Track Shipment on Shiprocket</a></p>"
            : "";

        $html = self::wrapTemplate("Thank You for Your Order", "
            <h2 style='color: #1a3320; margin-top: 0;'>Thank You for Your Order!</h2>
            <p>Dear <strong>" . htmlspecialchars($order['customer_name']) . "</strong>,</p>
            <p>We have received your order <strong>#" . htmlspecialchars($order['order_number']) . "</strong> and are preparing it with care at <strong>The Little Green House</strong>.</p>

            {$trackingHtml}

            <h4 style='color: #1a3320; margin-top: 25px; border-bottom: 2px solid #e2e8e2; padding-bottom: 6px;'>Order Summary</h4>
            {$itemsHtml}

            <div style='text-align: right; margin-top: 15px;'>
                <p style='margin: 4px 0; color: #666;'>Subtotal: ₹" . number_format((float) $order['subtotal'], 2) . "</p>
                <p style='margin: 4px 0; color: #666;'>Shipping: ₹" . number_format((float) $order['shipping_cost'], 2) . "</p>
                <p style='margin: 8px 0; font-size: 18px; font-weight: bold; color: #2e5a36;'>Total Paid: ₹{$totalFormatted}</p>
            </div>

            <p style='margin-top: 30px; font-size: 13px; color: #666;'>
                Questions about your order? Reply directly to this email or reach us at <a href='mailto:hello@thelittlegreenhouse.com' style='color: #2e5a36;'>hello@thelittlegreenhouse.com</a>.
            </p>
        ");

        return self::send($customerEmail, "Order Confirmation #" . $order['order_number'] . " - The Little Green House", $html);
    }

    /**
     * 6. Order status update alert to customer
     */
    public static function sendOrderStatusUpdateCustomer(array $order, string $status, ?string $trackingUrl = null, ?string $courier = null, ?string $awb = null): bool
    {
        $customerEmail = $order['customer_email'];
        $statusLabels  = [
            'CONFIRMED'        => 'Confirmed & In Preparation',
            'PROCESSING'       => 'Being Packed with Care',
            'SHIPPED'          => 'Shipped & On Its Way!',
            'OUT_FOR_DELIVERY' => 'Out for Delivery Today!',
            'DELIVERED'        => 'Delivered',
            'CANCELLED'        => 'Cancelled',
        ];
        $displayStatus = $statusLabels[$status] ?? ucfirst(strtolower($status));
        $trackingHtml  = '';
        if (! empty($trackingUrl)) {
            $trackingHtml = "<p style='margin: 20px 0;'><a href='{$trackingUrl}' style='background-color: #2e5a36; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: 500;'>Track Your Package</a></p>";
        } elseif (! empty($awb)) {
            $trackingHtml = "<p style='margin: 15px 0; background: #f5f0eb; padding: 12px; border-radius: 6px;'><strong>Courier:</strong> " . htmlspecialchars($courier ?: 'Shiprocket Partner') . "<br><strong>AWB Tracking Number:</strong> <code>" . htmlspecialchars($awb) . "</code></p>";
        }

        $html = self::wrapTemplate("Order Update: #" . $order['order_number'], "
            <h2 style='color: #1a3320; margin-top: 0;'>Order Status Update</h2>
            <p>Dear <strong>" . htmlspecialchars($order['customer_name']) . "</strong>,</p>
            <p>Your order <strong>#" . htmlspecialchars($order['order_number']) . "</strong> at <strong>The Little Green House</strong> has been updated to:</p>
            <div style='background: #eaf1eb; border-left: 4px solid #2e5a36; padding: 14px 18px; margin: 18px 0; border-radius: 4px;'>
                <span style='font-size: 17px; font-weight: bold; color: #2e5a36;'>{$displayStatus}</span>
            </div>
            {$trackingHtml}
            <p style='color: #666; font-size: 14px; margin-top: 25px;'>
                Thank you for supporting our slow-crafted handmade studio. If you have any questions, reply to this email or reach us anytime at <a href='mailto:hello@thelittlegreenhouse.com' style='color: #2e5a36;'>hello@thelittlegreenhouse.com</a>.
            </p>
        ");

        return self::send($customerEmail, "Update on Order #" . $order['order_number'] . ": {$displayStatus}", $html);
    }

    /**
     * 7. Newsletter Welcome & Subscription Confirmation Email
     */
    public static function sendNewsletterWelcome(string $subscriberEmail): bool
    {
        $config = require __DIR__ . '/../config/config.php';
        $appUrl = rtrim($config['app']['url'] ?? 'https://thelittlegreenhouse.in', '/');
        $unsubscribeUrl = "{$appUrl}/api/newsletter/unsubscribe?email=" . urlencode($subscriberEmail);

        $html = self::wrapTemplate("Welcome to The Little Green House Studio List", "
            <h2 style='color: #1a3320; margin-top: 0; font-family: Georgia, serif;'>Welcome to the Studio List 🌿</h2>
            <p>Thank you for joining our quiet corner. We're glad you're here.</p>
            
            <p>At <strong>The Little Green House</strong>, every piece is made slowly and in small batches — hand-thrown stoneware planters, pure botanical candles, healthy foliage, and timeless earthen homewares.</p>
            
            <div style='background: #fbf7f1; border: 1.5px solid #e5cdae; border-radius: 8px; padding: 18px 22px; margin: 24px 0;'>
                <h4 style='color: #7a4632; margin-top: 0; margin-bottom: 8px;'>What you'll receive from us:</h4>
                <ul style='padding-left: 20px; margin: 0; color: #4a1b0c; line-height: 1.8;'>
                    <li>First notice on new kiln un-loadings and small-batch drops before they sell out</li>
                    <li>Seasonal plant care and candle burning rituals from our studio bench</li>
                    <li>Invitations to upcoming pottery workshops and studio visits</li>
                </ul>
            </div>

            <p style='margin: 24px 0; text-align: center;'>
                <a href='{$appUrl}/shop/' style='background-color: #c3804c; color: #ffffff; padding: 13px 28px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: 500; letter-spacing: 0.02em;'>
                    Explore Our Current Collection &rarr;
                </a>
            </p>

            <p style='color: #666; font-size: 13px; margin-top: 30px; border-top: 1px solid #ebebeb; padding-top: 15px;'>
                If you ever wish to stop receiving studio updates, you can <a href='{$unsubscribeUrl}' style='color: #975637; text-decoration: underline;'>unsubscribe at any time</a>.
            </p>
        ");

        return self::send($subscriberEmail, "Welcome to The Little Green House 🌿", $html);
    }

    private static function renderOrderItemsTable(array $items): string
    {
        $rows = "";
        foreach ($items as $item) {
            $price  = number_format((float) $item['unit_price'], 2);
            $total  = number_format((float) ($item['unit_price'] * $item['quantity']), 2);
            $rows  .= "
                <tr style='border-bottom: 1px solid #eee;'>
                    <td style='padding: 10px 0;'><strong>" . htmlspecialchars($item['product_name']) . "</strong><br><span style='font-size: 12px; color: #888;'>SKU: " . htmlspecialchars($item['sku'] ?? 'N/A') . "</span></td>
                    <td style='padding: 10px; text-align: center;'>" . (int) $item['quantity'] . "</td>
                    <td style='padding: 10px; text-align: right;'>₹{$price}</td>
                    <td style='padding: 10px; text-align: right;'><strong>₹{$total}</strong></td>
                </tr>
            ";
        }

        return "
            <table style='width: 100%; border-collapse: collapse; font-size: 14px;'>
                <thead>
                    <tr style='border-bottom: 2px solid #ddd; text-align: left; color: #666; font-size: 12px; text-transform: uppercase;'>
                        <th style='padding: 8px 0;'>Product</th>
                        <th style='padding: 8px; text-align: center;'>Qty</th>
                        <th style='padding: 8px; text-align: right;'>Price</th>
                        <th style='padding: 8px; text-align: right;'>Total</th>
                    </tr>
                </thead>
                <tbody>
                    {$rows}
                </tbody>
            </table>
        ";
    }

    private static function wrapTemplate(string $title, string $bodyContent): string
    {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='utf-8'>
            <title>{$title}</title>
            <style>
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f6f4; color: #333; }
                .container { max-width: 600px; margin: 30px auto; background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
                .header { background-color: #1a3320; color: #eaf2eb; padding: 25px 30px; text-align: center; }
                .header h1 { margin: 0; font-size: 22px; letter-spacing: 0.5px; font-family: Georgia, serif; }
                .content { padding: 30px; line-height: 1.6; }
                .footer { background-color: #fafbfa; border-top: 1px solid #ebebeb; padding: 20px 30px; text-align: center; font-size: 12px; color: #888; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>The Little Green House</h1>
                    <div style='font-size: 12px; opacity: 0.85; margin-top: 4px;'>Handcrafted Planters, Pure Botanical Candles & Living Flora</div>
                </div>
                <div class='content'>
                    {$bodyContent}
                </div>
                <div class='footer'>
                    &copy; " . date('Y') . " The Little Green House. All rights reserved.<br>
                    Crafted with care for mindful living.
                </div>
            </div>
        </body>
        </html>
        ";
    }
}
