<?php
/**
 * Shiprocket API Client for The Little Green House
 * Handles Shipping, Courier Assignment, AWB Generation, Tracking & Payments
 */

class Shiprocket
{
    private static ?string $cachedToken = null;
    private static ?int $tokenExpiresAt = null;

    private static function getConfig(): array
    {
        $config = require __DIR__ . '/../config/config.php';
        return $config['shiprocket'];
    }

    /**
     * Authenticate and obtain Shiprocket Bearer Token
     */
    public static function getToken(): ?string
    {
        // Return in-memory token if valid
        if (self::$cachedToken && self::$tokenExpiresAt && time() < self::$tokenExpiresAt) {
            return self::$cachedToken;
        }

        // Check file cache
        $cacheFile = __DIR__ . '/../config/.shiprocket_token.cache';
        if (file_exists($cacheFile)) {
            $data = @json_decode(file_get_contents($cacheFile), true);
            if (! empty($data['token']) && ! empty($data['expires_at']) && time() < $data['expires_at']) {
                self::$cachedToken    = $data['token'];
                self::$tokenExpiresAt = $data['expires_at'];
                return self::$cachedToken;
            }
        }

        $cfg = self::getConfig();
        if (empty($cfg['email']) || empty($cfg['password'])) {
            return null; // Shiprocket credentials not yet supplied in .env
        }

        $response = self::request('POST', '/auth/login', [
            'email'    => $cfg['email'],
            'password' => $cfg['password'],
        ], false);

        if (! empty($response['token'])) {
            self::$cachedToken = $response['token'];
            // Token is typically valid for 10 days; cache for 8 days
            self::$tokenExpiresAt = time() + (86400 * 8);
            @file_put_contents($cacheFile, json_encode([
                'token'      => self::$cachedToken,
                'expires_at' => self::$tokenExpiresAt,
            ]));
            return self::$cachedToken;
        }

        error_log("Shiprocket authentication failed: " . json_encode($response));
        return null;
    }

    /**
     * Check pincode serviceability & get estimated delivery rates
     */
    public static function checkServiceability(string $deliveryPincode, float $weightKg = 0.5, bool $isCod = false): array
    {
        $token = self::getToken();
        if (! $token) {
            return ['success' => false, 'message' => 'Shiprocket credentials not configured'];
        }

        $cfg       = self::getConfig();
        $pickupPin = $cfg['pickup_pin'];

        $endpoint = sprintf(
            '/courier/serviceability/?pickup_postcode=%s&delivery_postcode=%s&weight=%s&cod=%d',
            urlencode($pickupPin),
            urlencode($deliveryPincode),
            urlencode((string) $weightKg),
            $isCod ? 1 : 0
        );

        return self::request('GET', $endpoint, null, true);
    }

    /**
     * Create an ad-hoc order in Shiprocket
     */
    public static function createOrder(array $orderData): array
    {
        $token = self::getToken();
        if (! $token) {
            return [
                'success' => false,
                'message' => 'Shiprocket credentials missing. Set SHIPROCKET_EMAIL and SHIPROCKET_PASSWORD in .env.',
            ];
        }

        $cfg = self::getConfig();

        // Calculate total package weight in kg from products (default 0.5kg per item)
        $weightKg   = 0.0;
        $orderItems = [];
        foreach ($orderData['items'] as $item) {
            $weightKg     += (($item['weight_grams'] ?? 500) * $item['quantity']) / 1000.0;
            $orderItems[]  = [
                'name'          => $item['product_name'],
                'sku'           => $item['sku'] ?? ('TLGH-' . $item['product_id']),
                'units'         => (int) $item['quantity'],
                'selling_price' => (float) $item['unit_price'],
                'discount'      => 0,
                'tax'           => 0,
            ];
        }
        if ($weightKg <= 0.1) {
            $weightKg = 0.5;
        }

        $shipping = is_string($orderData['shipping_address'])
            ? json_decode($orderData['shipping_address'], true)
            : $orderData['shipping_address'];

        $nameParts = explode(' ', trim($shipping['full_name'] ?? $orderData['customer_name'] ?? 'Customer'), 2);
        $firstName = $nameParts[0];
        $lastName  = $nameParts[1] ?? '.';

        $payload = [
            'order_id'              => (string) $orderData['order_number'],
            'order_date'            => date('Y-m-d H:i'),
            'pickup_location'       => $cfg['pickup_name'],
            'channel_id'            => $cfg['channel_id'] ?: '',
            'billing_customer_name' => $firstName,
            'billing_last_name'     => $lastName,
            'billing_address'       => $shipping['address_line1'] ?? '',
            'billing_address_2'     => $shipping['address_line2'] ?? '',
            'billing_city'          => $shipping['city'] ?? '',
            'billing_pincode'       => (string) ($shipping['postal_code'] ?? ''),
            'billing_state'         => $shipping['state'] ?? '',
            'billing_country'       => $shipping['country'] ?? 'India',
            'billing_email'         => $orderData['customer_email'] ?? '',
            'billing_phone'         => $shipping['phone'] ?? $orderData['customer_phone'] ?? '',
            'shipping_is_billing'   => true,
            'order_items'           => $orderItems,
            'payment_method'        => ($orderData['payment_method'] === 'COD') ? 'COD' : 'Prepaid',
            'shipping_charges'      => (float) ($orderData['shipping_cost'] ?? 0),
            'giftwrap_charges'      => 0,
            'transaction_charges'   => 0,
            'total_discount'        => (float) ($orderData['discount_amount'] ?? 0),
            'sub_total'             => (float) $orderData['subtotal'],
            'length'                => 15,
            'breadth'               => 15,
            'height'                => 15,
            'weight'                => round($weightKg, 2),
        ];

        return self::request('POST', '/orders/create/adhoc', $payload, true);
    }

    /**
     * Assign courier & generate AWB
     */
    public static function generateAWB(int $shipmentId, ?int $courierId = null): array
    {
        $payload = ['shipment_id' => $shipmentId];
        if ($courierId) {
            $payload['courier_id'] = $courierId;
        }
        return self::request('POST', '/courier/assign/awb', $payload, true);
    }

    /**
     * Request courier pickup
     */
    public static function requestPickup(int $shipmentId): array
    {
        return self::request('POST', '/courier/generate/pickup', [
            'shipment_id' => [$shipmentId],
        ], true);
    }

    /**
     * Track shipment in real-time by Shipment ID
     */
    public static function trackShipment(int $shipmentId): array
    {
        return self::request('GET', "/courier/track/shipment/{$shipmentId}", null, true);
    }

    /**
     * Track shipment by AWB Code
     */
    public static function trackAWB(string $awbCode): array
    {
        return self::request('GET', "/courier/track/awb/" . urlencode($awbCode), null, true);
    }

    /**
     * Cancel an order in Shiprocket
     */
    public static function cancelOrder(int $shiprocketOrderId): array
    {
        return self::request('POST', '/orders/cancel', [
            'ids' => [$shiprocketOrderId],
        ], true);
    }

    /**
     * Execute HTTP request using cURL
     */
    private static function request(string $method, string $path, ?array $body = null, bool $useAuth = true): array
    {
        $cfg = self::getConfig();
        $url = rtrim($cfg['base_url'], '/') . $path;

        $ch      = curl_init();
        $headers = ['Content-Type: application/json', 'Accept: application/json'];

        if ($useAuth) {
            $token = self::getToken();
            if ($token) {
                $headers[] = "Authorization: Bearer {$token}";
            }
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($body !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
            }
        } elseif ($method !== 'GET') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            if ($body !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
            }
        }

        $res      = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ['success' => false, 'error' => $error];
        }

        $decoded = json_decode($res, true);
        if ($decoded === null) {
            return ['success' => false, 'raw' => $res, 'http_code' => $httpCode];
        }

        return $decoded;
    }
}
