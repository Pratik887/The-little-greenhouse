<?php

/** Read owner-managed page photos without letting public pages fail if media is unset. */
final class SiteMedia
{
    public static function absolute(?string $url): ?string
    {
        $url = trim((string) $url);
        if ($url === '') return null;
        if (preg_match('#^https://#i', $url)) return $url;
        $config = require __DIR__ . '/../config/config.php';
        return rtrim((string) $config['app']['url'], '/') . '/' . ltrim($url, '/');
    }

    public static function get(string $slot): ?string
    {
        try {
            require_once __DIR__ . '/../config/database.php';
            $db = Database::getConnection();
            $stmt = $db->prepare('SELECT image_url FROM site_media WHERE slot = ? LIMIT 1');
            $stmt->execute([$slot]);
            $url = $stmt->fetchColumn();
            return is_string($url) && $url !== '' ? $url : null;
        } catch (Throwable $error) {
            error_log('Site media lookup failed: ' . $error->getMessage());
            return null;
        }
    }
}
