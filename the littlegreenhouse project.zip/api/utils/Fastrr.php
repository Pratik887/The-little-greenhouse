
<?php

/**
 * Server-side client for Shiprocket Fastrr custom-checkout APIs.
 */
final class Fastrr
{
    private static function config(): array
    {
        return (require __DIR__ . '/../config/config.php')['fastrr'];
    }

    public static function request(string $path, array $payload): array
    {
        $cfg = self::config();

        /*
         * Validate configuration
         */
        if (empty($cfg['api_key']) || empty($cfg['api_secret'])) {
            return [
                'success' => false,
                'message' => 'Fastrr API credentials are not configured',
                'http_status' => 0
            ];
        }

        /*
         * Encode request body
         */
        $body = json_encode(
            $payload,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        );

        if ($body === false) {
            return [
                'success' => false,
                'message' => 'Failed to encode Fastrr request',
                'http_status' => 0
            ];
        }

        /*
         * Generate HMAC signature
         */
        $signature = base64_encode(
            hash_hmac(
                'sha256',
                $body,
                $cfg['api_secret'],
                true
            )
        );

        /*
         * Build URL
         */
        $url = rtrim($cfg['base_url'], '/') . $path;

        /*
         * Initialize cURL
         */
        $ch = curl_init($url);
        $sslVerify = isset($cfg['ssl_verify']) ? (bool) $cfg['ssl_verify'] : true;

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Accept: application/json',
                'X-Api-Key: ' . $cfg['api_key'],
                'X-Api-HMAC-SHA256: ' . $signature
            ],
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_SSL_VERIFYPEER => $sslVerify,
            CURLOPT_SSL_VERIFYHOST => $sslVerify ? 2 : 0,
        ]);

        /*
         * Execute request
         */
        $raw = curl_exec($ch);

        $status = (int) curl_getinfo(
            $ch,
            CURLINFO_HTTP_CODE
        );

        $error = curl_error($ch);
        $errorCode = curl_errno($ch);

        curl_close($ch);

        /*
         * cURL/network failure
         */
        if ($raw === false || $error !== '') {
            error_log('Fastrr CURL ERROR | HTTP=' . $status . ' | CURL_CODE=' . $errorCode);

            return [
                'success' => false,
                'message' => 'Fastrr connection failed: ' . ($error ?: 'Network error'),
                'http_status' => $status
            ];
        }

        /*
         * Decode response
         */
        $data = json_decode(
            (string) $raw,
            true
        );

        /*
         * Invalid JSON
         */
        if (!is_array($data)) {
            error_log('Fastrr INVALID JSON | HTTP=' . $status);

            return [
                'success' => false,
                'message' => 'Invalid response received from Fastrr (HTTP ' . $status . ')',
                'http_status' => $status
            ];
        }

        /*
         * IMPORTANT:
         *
         * Fastrr responses can represent success using
         * different fields/types.
         */
        $succeeded = false;
        $explicitFailure = false;

        /*
         * Boolean flags
         */
        if (($data['ok'] ?? false) === true) {
            $succeeded = true;
        }

        if (($data['success'] ?? false) === true) {
            $succeeded = true;
        }

        // Refund APIs use a boolean `status` wrapper rather than `ok`.
        if (($data['status'] ?? null) === true) {
            $succeeded = true;
        }

        // Refund responses wrap their operation result under data.success.
        $nestedData = is_array($data['data'] ?? null) ? $data['data'] : [];
        if (($nestedData['success'] ?? null) === true) {
            $succeeded = true;
        }
        if (($data['status'] ?? null) === false || ($nestedData['success'] ?? null) === false) {
            $succeeded = false;
            $explicitFailure = true;
        }
        if (($data['success'] ?? null) === false || ($data['ok'] ?? null) === false) {
            $explicitFailure = true;
        }
        if ((isset($data['error']) && $data['error'] !== '' && $data['error'] !== null)
            || (isset($nestedData['error']) && $nestedData['error'] !== '' && $nestedData['error'] !== null)) {
            $explicitFailure = true;
        }

        /*
         * Status may be:
         *
         * true
         * "true"
         * "success"
         * "successful"
         * "ok"
         */
        if (isset($data['status'])) {
            $statusValue = strtolower(
                trim((string) $data['status'])
            );

            if (in_array($statusValue, [
                'true',
                'success',
                'successful',
                'ok'
            ], true)) {
                $succeeded = true;
            } elseif (in_array($statusValue, ['false', 'error', 'failed', 'failure', 'fail'], true)) {
                $explicitFailure = true;
            }
        }

        /*
         * HTTP status must also indicate success.
         */
        $httpSuccess =
            $status >= 200 &&
            $status < 300;

        /*
         * Log the complete response while debugging.
         */
        /*
         * Fastrr rejected the request.
         */
        // Catalog webhooks and some API responses signal success with HTTP 2xx
        // and a message only. Trust that response unless its body explicitly
        // reports failure; callers validate the operation-specific fields.
        if ($httpSuccess && !$explicitFailure && !$succeeded) {
            $succeeded = true;
        }
        if ($explicitFailure) {
            $succeeded = false;
        }

        if (!$httpSuccess || !$succeeded) {
            $extractedMessage = null;
            if (isset($data['result']) && is_string($data['result']) && trim($data['result']) !== '') {
                $extractedMessage = trim($data['result']);
            } elseif (isset($data['message']) && is_string($data['message']) && trim($data['message']) !== '') {
                $extractedMessage = trim($data['message']);
            } elseif (isset($data['error']) && is_string($data['error']) && trim($data['error']) !== '') {
                $extractedMessage = trim($data['error']);
            } elseif (isset($data['detail']) && is_string($data['detail']) && trim($data['detail']) !== '') {
                $extractedMessage = trim($data['detail']);
            } elseif (isset($data['msg']) && is_string($data['msg']) && trim($data['msg']) !== '') {
                $extractedMessage = trim($data['msg']);
            } elseif (isset($data['description']) && is_string($data['description']) && trim($data['description']) !== '') {
                $extractedMessage = trim($data['description']);
            } elseif (isset($data['code']) && is_string($data['code']) && trim($data['code']) !== '') {
                $extractedMessage = trim($data['code']);
            } elseif (isset($nestedData['message']) && is_string($nestedData['message']) && trim($nestedData['message']) !== '') {
                $extractedMessage = trim($nestedData['message']);
            } elseif (isset($nestedData['error']) && is_string($nestedData['error']) && trim($nestedData['error']) !== '') {
                $extractedMessage = trim($nestedData['error']);
            }

            if ($status === 511 || ($extractedMessage && stripos($extractedMessage, 'Invalid credentials') !== false)) {
                $message = "Fastrr authentication failed (HTTP 511: " . ($extractedMessage ?: 'Invalid credentials') . "). Please verify FASTRR_API_KEY and FASTRR_API_SECRET in api/.env";
            } elseif ($extractedMessage) {
                $message = "Fastrr error (HTTP {$status}): {$extractedMessage}";
            } else {
                $message = "Fastrr rejected the request (HTTP {$status})";
            }

            return [
                'success' => false,
                'message' => (string) $message,
                'http_status' => $status,
                'response' => $data
            ];
        }

        /*
         * Normalize useful response payload.
         */
        $result =
            (isset($data['result']) && is_array($data['result']))
                ? $data['result']
                : ((isset($data['data']) && is_array($data['data']))
                    ? $data['data']
                    : $data);

        return [
            'success' => true,
            'data' => $result,
            'http_status' => $status
        ];
    }

    public static function createCheckoutToken(
        array $variantItems,
        string $redirectUrl
    ): array {
        return self::request(
            '/api/v1/access-token/checkout',
            [
                'cart_data' => [
                    'items' => $variantItems,
                    'mobile_app' => false,
                ],
                'redirect_url' => $redirectUrl,
                'timestamp' => gmdate(
                    'Y-m-d\TH:i:s.v\Z'
                ),
            ]
        );
    }

    public static function orderDetails(
        string $orderId
    ): array {
        return self::request(
            '/api/v1/custom-platform-order/details',
            [
                'order_id' => $orderId,
                'timestamp' => gmdate(
                    'Y-m-d\TH:i:s.v\Z'
                ),
            ]
        );
    }

    public static function initiateRefund(
        string $orderId,
        float $amount
    ): array {
        return self::request(
            '/api/v1/external/refund/initiate',
            [
                'order_id' => $orderId,
                'amount' => max(0.01, $amount)
            ]
        );
    }

    public static function refundReports(
        string $from,
        string $to,
        int $page = 0
    ): array {
        return self::request(
            '/api/v1/external/refund/reports',
            [
                'page' => max(0, $page),
                'from' => $from,
                'to' => $to,
            ]
        );
    }

    public static function orderList(
        string $startDate,
        string $endDate,
        string $status = 'SUCCESS',
        int $limit = 200,
        int $page = 0
    ): array {
        return self::request(
            '/api/v1/custom-platform-order/details/list',
            [
                'startDate' => $startDate,
                'endDate' => $endDate,
                'status' => $status,
                'limit' => min(250, max(1, $limit)),
                'page' => max(0, $page),
                'timestamp' => gmdate('Y-m-d\TH:i:s.v\Z')
            ]
        );
    }

    public static function syncProductWebhook(
        array $productData
    ): array {
        return self::request(
            '/wh/v1/custom/product',
            $productData
        );
    }

    public static function syncCollectionWebhook(
        array $collectionData
    ): array {
        return self::request(
            '/wh/v1/custom/collection',
            $collectionData
        );
    }
}
