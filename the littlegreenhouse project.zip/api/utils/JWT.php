<?php
/**
 * Zero-dependency pure PHP JWT implementation (HS256)
 */

class JWT
{
    /**
     * Encode payload into a signed JWT token
     */
    public static function encode(array $payload, string $secret, int $ttlSeconds = 86400): string
    {
        $header = [
            'typ' => 'JWT',
            'alg' => 'HS256',
        ];

        $now            = time();
        $payload['iat'] = $now;
        $payload['exp'] = $now + $ttlSeconds;

        $base64Header  = self::base64UrlEncode(json_encode($header));
        $base64Payload = self::base64UrlEncode(json_encode($payload));

        $signature       = hash_hmac('sha256', "$base64Header.$base64Payload", $secret, true);
        $base64Signature = self::base64UrlEncode($signature);

        return "$base64Header.$base64Payload.$base64Signature";
    }

    /**
     * Decode and verify a JWT token
     * Returns decoded payload array or null if invalid/expired
     */
    public static function decode(string $jwt, string $secret): ?array
    {
        $parts = explode('.', $jwt);
        if (count($parts) !== 3) {
            return null;
        }

        list($base64Header, $base64Payload, $base64Signature) = $parts;

        // Verify header
        $header = json_decode(self::base64UrlDecode($base64Header), true);
        if (! $header || ($header['alg'] ?? '') !== 'HS256') {
            return null;
        }

        // Verify signature
        $expectedSignature = hash_hmac('sha256', "$base64Header.$base64Payload", $secret, true);
        $providedSignature = self::base64UrlDecode($base64Signature);

        if (! hash_equals($expectedSignature, $providedSignature)) {
            return null;
        }

        // Decode payload
        $payload = json_decode(self::base64UrlDecode($base64Payload), true);
        if (! $payload) {
            return null;
        }

        // Check expiration
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            return null; // Token expired
        }

        return $payload;
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function base64UrlDecode(string $data): string
    {
        return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4 ? strlen($data) + (4 - strlen($data) % 4) : strlen($data), '=', STR_PAD_RIGHT));
    }
}
