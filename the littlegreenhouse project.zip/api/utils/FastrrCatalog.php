<?php

/**
 * Maps local products/categories to the Shiprocket Checkout catalog contract
 * (see "Catalog APIs" and "Catalog Webhooks" in the SRC Custom Integration docs)
 * and pushes changes to Shiprocket through the signed catalog webhooks.
 *
 * The same mapper feeds both the pull endpoints Shiprocket calls
 * (/api/shiprocket/products, /collections) and the push webhooks, so the two
 * can never disagree.
 */
final class FastrrCatalog
{
    /** Variant IDs live above signed MySQL INT so they never collide with product IDs. */
    private const VARIANT_ID_OFFSET = 2147483648;

    public static function variantId(int $productId): int
    {
        return self::VARIANT_ID_OFFSET + $productId;
    }

    /** ISO 8601 with UTC offset, as the docs' examples show. */
    private static function iso($value): string
    {
        $ts = $value ? strtotime((string) $value) : false;
        return date('c', $ts !== false ? $ts : time());
    }

    private static function absoluteUrl(?string $url): string
    {
        $url = trim((string) $url);
        if ($url === '' || preg_match('#^https?://#i', $url)) {
            return $url;
        }
        $base = (string) ((require __DIR__ . '/../config/config.php')['app']['url'] ?? '');
        return rtrim($base, '/') . '/' . ltrim($url, '/');
    }

    /** SELECT used for both the feed and webhook pushes. */
    public static function productSelect(): string
    {
        return "SELECT p.*, c.name AS category_name, c.slug AS category_slug,
                       COALESCE(p.online_stock_quantity, p.stock_quantity) AS current_stock,
                       (SELECT image_url FROM product_images WHERE product_id=p.id AND is_primary=1 LIMIT 1) AS image_url
                FROM products p
                LEFT JOIN categories c ON c.id=p.category_id";
    }

    public static function mapProduct(array $p, string $status = 'active'): array
    {
        $grams     = (int) ($p['weight_grams'] ?? 500);
        $price     = (float) $p['price'];
        $compare   = (float) ($p['compare_at_price'] ?? 0);
        $img       = self::absoluteUrl($p['image_url'] ?? '');
        $createdAt = self::iso($p['created_at'] ?? null);
        $updatedAt = self::iso($p['updated_at'] ?? ($p['created_at'] ?? null));
        $tag       = trim((string) ($p['tag'] ?? ''));

        return [
            'id'           => (int) $p['id'],
            'title'        => (string) $p['name'],
            'body_html'    => (string) ($p['description'] ?? ''),
            'vendor'       => 'The Little Green House',
            'product_type' => (string) ($p['category_name'] ?? 'Botanical & Decor'),
            'created_at'   => $createdAt,
            'handle'       => (string) $p['slug'],
            'updated_at'   => $updatedAt,
            'tags'         => $tag !== '' ? $tag . ', Plants, Home Decor' : 'Plants, Home Decor, Indoor Plants, Gardening',
            'status'       => $status,
            'variants'     => [[
                'id'               => self::variantId((int) $p['id']),
                'title'            => 'Default',
                'price'            => number_format($price, 2, '.', ''),
                // compare_at_price must not be below price; fall back to price.
                'compare_at_price' => number_format($compare > $price ? $compare : $price, 2, '.', ''),
                'sku'              => (string) $p['sku'],
                'quantity'         => max(0, (int) ($p['current_stock'] ?? 0)),
                'created_at'       => $createdAt,
                'updated_at'       => $updatedAt,
                'taxable'          => true,
                'option_values'    => ['Title' => 'Default'],
                'grams'            => $grams,
                'image'            => ['src' => $img],
                'weight'           => round($grams / 1000, 2),
                'weight_unit'      => 'kg',
            ]],
            'image'   => ['src' => $img],
            'options' => [['name' => 'Title', 'values' => ['Default']]],
        ];
    }

    public static function mapCollection(array $c): array
    {
        return [
            'id'         => (int) $c['id'],
            'title'      => (string) $c['name'],
            'handle'     => (string) $c['slug'],
            'body_html'  => (string) ($c['description'] ?? ''),
            'image'      => ['src' => self::absoluteUrl($c['image_url'] ?? '')],
            'created_at' => self::iso($c['created_at'] ?? null),
            'updated_at' => self::iso($c['updated_at'] ?? ($c['created_at'] ?? null)),
        ];
    }

    private static function credentialsConfigured(): bool
    {
        $cfg = (require __DIR__ . '/../config/config.php')['fastrr'];
        return !empty($cfg['api_key']) && !empty($cfg['api_secret']);
    }

    /**
     * Push one product to Shiprocket. Never throws: a Shiprocket outage must not
     * break an admin save, and the pull feed remains the source of truth.
     */
    public static function pushProduct(PDO $db, int $productId, ?string $forceStatus = null): bool
    {
        if (!self::credentialsConfigured()) {
            return false;
        }
        try {
            $stmt = $db->prepare(self::productSelect() . ' WHERE p.id=?');
            $stmt->execute([$productId]);
            $row = $stmt->fetch();
            if (!$row) {
                return false;
            }
            $status = $forceStatus ?? ((int) $row['is_active'] === 1 ? 'active' : 'archived');
            $res = Fastrr::syncProductWebhook(self::mapProduct($row, $status));
            if (!$res['success']) {
                error_log('Shiprocket product webhook failed for #' . $productId . ': ' . ($res['message'] ?? ''));
            }
            return (bool) $res['success'];
        } catch (Throwable $e) {
            error_log('Shiprocket product webhook error: ' . $e->getMessage());
            return false;
        }
    }

    /** Push a product that is already gone locally (hard delete) as archived. */
    public static function pushArchivedSnapshot(array $row): bool
    {
        if (!self::credentialsConfigured()) {
            return false;
        }
        try {
            $res = Fastrr::syncProductWebhook(self::mapProduct($row, 'archived'));
            return (bool) $res['success'];
        } catch (Throwable $e) {
            error_log('Shiprocket product archive webhook error: ' . $e->getMessage());
            return false;
        }
    }

    public static function pushCollection(PDO $db, int $categoryId): bool
    {
        if (!self::credentialsConfigured()) {
            return false;
        }
        try {
            $stmt = $db->prepare('SELECT id, name, slug, description, image_url, created_at, updated_at FROM categories WHERE id=?');
            $stmt->execute([$categoryId]);
            $row = $stmt->fetch();
            if (!$row) {
                return false;
            }
            $res = Fastrr::syncCollectionWebhook(self::mapCollection($row));
            if (!$res['success']) {
                error_log('Shiprocket collection webhook failed for #' . $categoryId . ': ' . ($res['message'] ?? ''));
            }
            return (bool) $res['success'];
        } catch (Throwable $e) {
            error_log('Shiprocket collection webhook error: ' . $e->getMessage());
            return false;
        }
    }

    /** Push every collection and active product. Returns counts for the admin UI. */
    public static function pushAll(PDO $db): array
    {
        $out = ['collections' => ['ok' => 0, 'failed' => 0], 'products' => ['ok' => 0, 'failed' => 0]];
        foreach ($db->query('SELECT id FROM categories WHERE is_active=1')->fetchAll() as $r) {
            $out['collections'][self::pushCollection($db, (int) $r['id']) ? 'ok' : 'failed']++;
        }
        foreach ($db->query('SELECT id FROM products WHERE is_active=1')->fetchAll() as $r) {
            $out['products'][self::pushProduct($db, (int) $r['id']) ? 'ok' : 'failed']++;
        }
        return $out;
    }
}
