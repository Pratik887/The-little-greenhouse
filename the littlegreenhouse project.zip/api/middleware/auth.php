<?php
/**
 * Authentication & Authorization Middleware
 * Enforces JWT verification for admin and customer routes
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../utils/JWT.php';

class AuthMiddleware
{
    /**
     * Extract Bearer token from HTTP Authorization header
     */
    public static function getBearerToken(): ?string
    {
        $headers = null;
        if (isset($_SERVER['Authorization'])) {
            $headers = trim($_SERVER['Authorization']);
        } elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $headers = trim($_SERVER['HTTP_AUTHORIZATION']);
        } elseif (function_exists('apache_request_headers')) {
            $requestHeaders = apache_request_headers();
            // Case-insensitive lookup
            $headers = $requestHeaders['Authorization'] ?? $requestHeaders['authorization'] ?? null;
        }

        if (! empty($headers) && preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
            return $matches[1];
        }

        return null;
    }

    /**
     * Enforce JWT authentication for Admin operations
     *
     * @param string|null $requiredRole 'OWNER' or null (any active admin)
     * @return array The authenticated admin row
     */
    public static function requireAdmin(?string $requiredRole = null): array
    {
        $token = self::getBearerToken();
        if (! $token) {
            self::respondUnauthorized('Authentication required. Missing Bearer JWT token.');
        }

        $config  = require __DIR__ . '/../config/config.php';
        $payload = JWT::decode($token, $config['jwt']['secret']);

        if (! $payload || empty($payload['sub']) || ($payload['role_type'] ?? '') !== 'admin') {
            self::respondUnauthorized('Invalid or expired admin access token.');
        }

        // Verify admin in database
        $db   = Database::getConnection();
        $stmt = $db->prepare('SELECT id, full_name, email, role, is_active FROM admins WHERE id = ? LIMIT 1');
        $stmt->execute([(int) $payload['sub']]);
        $admin = $stmt->fetch();

        if (! $admin || ! (bool) $admin['is_active']) {
            self::respondUnauthorized('Admin account not found or suspended.');
        }

        // Enforce role hierarchy if specified
        if ($requiredRole !== null && $admin['role'] !== $requiredRole) {
            self::respondForbidden("Insufficient privileges. {$requiredRole} authorization required.");
        }

        return $admin;
    }

    /**
     * Enforce JWT authentication for Customer operations
     */
    public static function requireCustomer(): array
    {
        $token = self::getBearerToken();
        if (! $token) {
            self::respondUnauthorized('Customer login required.');
        }

        $config  = require __DIR__ . '/../config/config.php';
        $payload = JWT::decode($token, $config['jwt']['secret']);

        if (! $payload || empty($payload['sub']) || ($payload['role_type'] ?? '') !== 'customer') {
            self::respondUnauthorized('Invalid or expired customer token.');
        }

        $db   = Database::getConnection();
        $stmt = $db->prepare('SELECT id, first_name, last_name, email, phone, is_active FROM customers WHERE id = ? LIMIT 1');
        $stmt->execute([(int) $payload['sub']]);
        $customer = $stmt->fetch();

        if (! $customer || ! (bool) $customer['is_active']) {
            self::respondUnauthorized('Customer account not found or deactivated.');
        }

        return $customer;
    }

    /**
     * Optional authentication helper
     */
    public static function getOptionalUser(): ?array
    {
        $token = self::getBearerToken();
        if (! $token) {
            return null;
        }

        $config  = require __DIR__ . '/../config/config.php';
        $payload = JWT::decode($token, $config['jwt']['secret']);
        if (! $payload) {
            return null;
        }

        $db = Database::getConnection();
        if (($payload['role_type'] ?? '') === 'admin') {
            $stmt = $db->prepare('SELECT id, full_name, email, role, is_active FROM admins WHERE id = ? LIMIT 1');
            $stmt->execute([(int) $payload['sub']]);
            $user = $stmt->fetch();
            if ($user && $user['is_active']) {
                $user['type'] = 'admin';
                return $user;
            }
        } elseif (($payload['role_type'] ?? '') === 'customer') {
            $stmt = $db->prepare('SELECT id, first_name, last_name, email, phone, is_active FROM customers WHERE id = ? LIMIT 1');
            $stmt->execute([(int) $payload['sub']]);
            $user = $stmt->fetch();
            if ($user && $user['is_active']) {
                $user['type'] = 'customer';
                return $user;
            }
        }

        return null;
    }

    private static function respondUnauthorized(string $message): void
    {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'error'   => 'Unauthorized',
            'message' => $message,
        ]);
        exit;
    }

    private static function respondForbidden(string $message): void
    {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'error'   => 'Forbidden',
            'message' => $message,
        ]);
        exit;
    }
}
