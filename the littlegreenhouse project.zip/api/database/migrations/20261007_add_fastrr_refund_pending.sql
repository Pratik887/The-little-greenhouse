-- Safe, non-destructive migration for existing MySQL installations.
-- Allows the admin panel to distinguish an accepted, unconfirmed provider
-- refund from a completed refund.
ALTER TABLE `orders`
    MODIFY `payment_status` ENUM('PENDING', 'PAID', 'FAILED', 'REFUND_PENDING', 'REFUNDED')
    NOT NULL DEFAULT 'PENDING';
