-- ====================================================================
-- Database Schema: The Little Green House (TLGH) E-Commerce Platform
-- Compatible with: MySQL 5.7+ / MySQL 8.0+ / MariaDB 10.3+
-- Engine: InnoDB | Character Set: utf8mb4 | Collation: utf8mb4_unicode_ci
-- ====================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `fastrr_checkouts`;
DROP TABLE IF EXISTS `admin_activity_logs`;
DROP TABLE IF EXISTS `password_reset_tokens`;
DROP TABLE IF EXISTS `newsletter_subscribers`;
DROP TABLE IF EXISTS `appointments`;
DROP TABLE IF EXISTS `reviews`;
DROP TABLE IF EXISTS `order_items`;
DROP TABLE IF EXISTS `orders`;
DROP TABLE IF EXISTS `favourites`;
DROP TABLE IF EXISTS `cart_items`;
DROP TABLE IF EXISTS `product_images`;
DROP TABLE IF EXISTS `products`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `addresses`;
DROP TABLE IF EXISTS `customers`;
DROP TABLE IF EXISTS `admins`;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE IF NOT EXISTS `fastrr_checkouts` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `checkout_ref` VARCHAR(80) NOT NULL UNIQUE,
    `fastrr_order_id` VARCHAR(100) NOT NULL UNIQUE,
    `items_json` JSON NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `processed_order_id` INT NULL,
    INDEX `idx_fastrr_processed_order` (`processed_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `site_media` (
    `slot` VARCHAR(50) PRIMARY KEY,
    `image_url` VARCHAR(500) NOT NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 1. Admins Table
-- --------------------------------------------------------------------
CREATE TABLE `admins` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `full_name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `role` ENUM('OWNER', 'STAFF') NOT NULL DEFAULT 'STAFF',
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_admin_email` (`email`),
    INDEX `idx_admin_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 2. Customers Table
-- --------------------------------------------------------------------
CREATE TABLE `customers` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `first_name` VARCHAR(100) NOT NULL,
    `last_name` VARCHAR(100) NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `phone` VARCHAR(20) NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_customer_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 3. Addresses Table
-- --------------------------------------------------------------------
CREATE TABLE `addresses` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `customer_id` INT NOT NULL,
    `full_name` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(20) NOT NULL,
    `address_line1` VARCHAR(255) NOT NULL,
    `address_line2` VARCHAR(255) NULL,
    `landmark` VARCHAR(150) NULL,
    `city` VARCHAR(100) NOT NULL,
    `state` VARCHAR(100) NOT NULL,
    `postal_code` VARCHAR(20) NOT NULL,
    `country` VARCHAR(100) NOT NULL DEFAULT 'India',
    `is_default` BOOLEAN NOT NULL DEFAULT FALSE,
    `type` ENUM('SHIPPING', 'BILLING', 'BOTH') NOT NULL DEFAULT 'SHIPPING',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_address_customer` (`customer_id`),
    INDEX `idx_address_pincode` (`postal_code`),
    CONSTRAINT `fk_addresses_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 4. Categories Table
-- --------------------------------------------------------------------
CREATE TABLE `categories` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `slug` VARCHAR(100) NOT NULL UNIQUE,
    `description` TEXT NULL,
    `image_url` VARCHAR(500) NULL,
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_category_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 5. Products Table (Includes weight & dimensions for Shiprocket)
-- --------------------------------------------------------------------
CREATE TABLE `products` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `category_id` INT NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `slug` VARCHAR(255) NOT NULL UNIQUE,
    `short_description` VARCHAR(500) NULL,
    `description` TEXT NULL,
    `price` DECIMAL(10,2) NOT NULL,
    `compare_at_price` DECIMAL(10,2) NULL,
    `sku` VARCHAR(100) NOT NULL UNIQUE,
    `stock_quantity` INT NOT NULL DEFAULT 0,
    `online_stock_quantity` INT NULL DEFAULT NULL,
    `local_stock_quantity` INT NOT NULL DEFAULT 0,
    `weight_grams` INT NOT NULL DEFAULT 500 COMMENT 'Used for Shiprocket courier weight calculation',
    `length_cm` DECIMAL(6,2) NOT NULL DEFAULT 10.0,
    `breadth_cm` DECIMAL(6,2) NOT NULL DEFAULT 10.0,
    `height_cm` DECIMAL(6,2) NOT NULL DEFAULT 10.0,
    `dimensions` VARCHAR(100) NULL COMMENT 'Display dimensions e.g. 14cm x 16cm',
    `care_instructions` TEXT NULL,
    `tag` VARCHAR(100) NULL COMMENT 'e.g. Best Seller, Hand-thrown',
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
    `is_featured` BOOLEAN NOT NULL DEFAULT FALSE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_product_category` (`category_id`),
    INDEX `idx_product_slug` (`slug`),
    INDEX `idx_product_sku` (`sku`),
    INDEX `idx_product_active` (`is_active`),
    CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 6. Product Images Table
-- --------------------------------------------------------------------
CREATE TABLE `product_images` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `product_id` INT NOT NULL,
    `image_url` VARCHAR(500) NOT NULL,
    `alt_text` VARCHAR(255) NULL,
    `sort_order` INT NOT NULL DEFAULT 0,
    `is_primary` BOOLEAN NOT NULL DEFAULT FALSE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_images_product` (`product_id`),
    CONSTRAINT `fk_images_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 7. Cart Items Table
-- --------------------------------------------------------------------
CREATE TABLE `cart_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `customer_id` INT NULL,
    `session_id` VARCHAR(100) NULL,
    `product_id` INT NOT NULL,
    `quantity` INT NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_cart_customer` (`customer_id`),
    INDEX `idx_cart_session` (`session_id`),
    CONSTRAINT `fk_cart_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_cart_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 8. Favourites / Wishlist Table
-- --------------------------------------------------------------------
CREATE TABLE `favourites` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `customer_id` INT NOT NULL,
    `product_id` INT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_customer_product` (`customer_id`, `product_id`),
    INDEX `idx_fav_customer` (`customer_id`),
    CONSTRAINT `fk_fav_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_fav_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 9. Orders Table (Fully integrated with Shiprocket shipping & payments)
-- --------------------------------------------------------------------
CREATE TABLE `orders` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_number` VARCHAR(50) NOT NULL UNIQUE,
    `customer_id` INT NULL,
    `customer_name` VARCHAR(150) NOT NULL,
    `customer_email` VARCHAR(150) NOT NULL,
    `customer_phone` VARCHAR(20) NOT NULL,
    `shipping_address` JSON NOT NULL,
    `billing_address` JSON NULL,
    `subtotal` DECIMAL(10,2) NOT NULL,
    `shipping_cost` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `tax_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `discount_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `total_amount` DECIMAL(10,2) NOT NULL,
    `payment_status` ENUM('PENDING', 'PAID', 'FAILED', 'REFUND_PENDING', 'REFUNDED') NOT NULL DEFAULT 'PENDING',
    `payment_method` VARCHAR(50) NOT NULL DEFAULT 'ONLINE' COMMENT 'ONLINE, COD, SHIPROCKET_PAY',
    `payment_transaction_id` VARCHAR(150) NULL,
    `order_status` ENUM(
        'PENDING',
        'CONFIRMED',
        'PROCESSING',
        'SHIPPED',
        'OUT_FOR_DELIVERY',
        'DELIVERED',
        'CANCELLED'
    ) NOT NULL DEFAULT 'PENDING',
    -- Shiprocket integration fields:
    `shiprocket_order_id` VARCHAR(100) NULL COMMENT 'Order ID returned by Shiprocket',
    `shiprocket_shipment_id` VARCHAR(100) NULL COMMENT 'Shipment ID assigned by Shiprocket',
    `shiprocket_awb` VARCHAR(100) NULL COMMENT 'Air Waybill tracking number',
    `courier_name` VARCHAR(100) NULL COMMENT 'Assigned courier (e.g. Bluedart, Delhivery)',
    `tracking_url` VARCHAR(500) NULL COMMENT 'Customer-facing tracking URL',
    `shiprocket_status` VARCHAR(100) NULL COMMENT 'Raw status from Shiprocket API',
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_order_number` (`order_number`),
    INDEX `idx_order_customer` (`customer_id`),
    INDEX `idx_order_status` (`order_status`),
    INDEX `idx_order_payment_status` (`payment_status`),
    INDEX `idx_order_shiprocket_awb` (`shiprocket_awb`),
    CONSTRAINT `fk_orders_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 10. Order Items Table
-- --------------------------------------------------------------------
CREATE TABLE `order_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT NOT NULL,
    `product_id` INT NULL,
    `product_name` VARCHAR(255) NOT NULL,
    `sku` VARCHAR(100) NOT NULL,
    `unit_price` DECIMAL(10,2) NOT NULL,
    `quantity` INT NOT NULL,
    `total_price` DECIMAL(10,2) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_order_items_order` (`order_id`),
    CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_order_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 11. Reviews Table
-- --------------------------------------------------------------------
CREATE TABLE `reviews` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `product_id` INT NOT NULL,
    `customer_id` INT NULL,
    `reviewer_name` VARCHAR(100) NOT NULL,
    `reviewer_email` VARCHAR(150) NOT NULL,
    `rating` TINYINT NOT NULL CHECK (`rating` BETWEEN 1 AND 5),
    `title` VARCHAR(200) NULL,
    `comment` TEXT NOT NULL,
    `is_verified_purchase` BOOLEAN NOT NULL DEFAULT FALSE,
    `is_approved` BOOLEAN NOT NULL DEFAULT TRUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_reviews_product` (`product_id`),
    CONSTRAINT `fk_reviews_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_reviews_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 12. Newsletter Subscribers Table
-- --------------------------------------------------------------------
CREATE TABLE `newsletter_subscribers` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
    `unsubscribed_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_newsletter_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 13. Password Reset Tokens Table (Admins & Customers)
-- --------------------------------------------------------------------
CREATE TABLE `password_reset_tokens` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `email` VARCHAR(150) NOT NULL,
    `token` VARCHAR(255) NOT NULL UNIQUE,
    `user_type` ENUM('ADMIN', 'CUSTOMER') NOT NULL DEFAULT 'ADMIN',
    `expires_at` DATETIME NOT NULL,
    `used_at` DATETIME NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_pwd_token` (`token`),
    INDEX `idx_pwd_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 14. Appointments Table (Studio Visits)
-- --------------------------------------------------------------------
CREATE TABLE `appointments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `customer_name` VARCHAR(150) NOT NULL,
    `customer_email` VARCHAR(150) NOT NULL,
    `customer_phone` VARCHAR(20) NOT NULL,
    `preferred_date` DATE NOT NULL,
    `preferred_time` VARCHAR(20) NOT NULL,
    `party_size` INT NOT NULL DEFAULT 1,
    `notes` TEXT NULL,
    `status` ENUM('PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED') NOT NULL DEFAULT 'PENDING',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_appointment_date` (`preferred_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 15. Admin Activity Audit Logs Table
-- --------------------------------------------------------------------
CREATE TABLE `admin_activity_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `admin_id` INT NULL,
    `admin_email` VARCHAR(150) NOT NULL,
    `action` VARCHAR(100) NOT NULL,
    `details` JSON NULL,
    `ip_address` VARCHAR(45) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_audit_admin` (`admin_id`),
    INDEX `idx_audit_action` (`action`),
    CONSTRAINT `fk_audit_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- SEED DATA
-- ====================================================================

-- Administrators are provisioned with api/setup-admin.php; never seed a shared password.

-- 2. Initial Categories
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `sort_order`) VALUES
(1, 'Pots & Planters', 'pots', 'Handcrafted ceramic and terracotta planters for your botanical haven.', 1),
(2, 'Candles', 'candles', 'Small-batch, hand-poured soy wax candles infused with natural botanicals.', 2),
(3, 'Plants', 'plants', 'Healthy, acclimated indoor plants nurtured for your home.', 3),
(4, 'Home Décor', 'decor', 'Timeless artisanal homewares and handcrafted accessories.', 4);

-- 3. Initial Catalog Products (matching frontend catalog)
INSERT INTO `products` (`id`, `category_id`, `name`, `slug`, `short_description`, `description`, `price`, `compare_at_price`, `sku`, `stock_quantity`, `weight_grams`, `dimensions`, `tag`, `is_active`, `is_featured`) VALUES
(1, 1, 'Amber Stoneware Planter', 'amber-stoneware-planter', 'A hand-thrown stoneware planter with a warm amber glaze and drainage hole.', 'Crafted from coarse stoneware clay and finished in a layered amber glaze that catches the natural light. Each piece carries subtle variations in tone and texture from the firing process. Includes a recessed drainage hole and matching saucer.', 1450.00, NULL, 'POT-AMB-001', 18, 1200, '16cm H x 14cm W', 'Best Seller', 1, 1),
(2, 1, 'Clay Rim Terracotta Pot', 'clay-rim-terracotta-pot', 'Classic unglazed terracotta with a hand-burnished rim and natural patina.', 'Made using traditional wood-fired kilns, this unglazed terracotta planter allows root aeration while developing a rich, earthy patina over time. Perfect for succulents, cacti, and arid-climate house plants.', 980.00, NULL, 'POT-TER-002', 24, 900, '14cm H x 13cm W', 'Hand-thrown', 1, 1),
(3, 2, 'Sandalwood Pillar Candle', 'sandalwood-pillar-candle', 'Pure soy wax pillar infused with Mysore sandalwood and warm cedar.', 'Hand-poured using 100% natural soy wax and scented with essential oils of Mysore sandalwood, cedar bark, and dried clove. Burns cleanly for approximately 45 hours with a crackling cotton wick.', 620.00, 750.00, 'CND-SAN-001', 30, 450, '10cm H x 7cm Dia', 'Sale', 1, 1),
(4, 2, 'Smoked Vanilla Jar Candle', 'smoked-vanilla-jar-candle', 'Rich Bourbon vanilla smoked with oakwood in an amber glass jar.', 'An inviting blend of aged vanilla bean, toasted oak, and a hint of warm amber resin. Poured into an amber apothecary glass jar with a brass twist lid that preserves the botanical aroma between burns. Burn time: 50 hours.', 720.00, NULL, 'CND-VAN-002', 22, 500, '9cm H x 8cm Dia', 'New', 1, 1),
(5, 3, 'Trailing Pothos', 'trailing-pothos', 'Lush Epipremnum aureum in a nursery pot, ready to drape gracefully.', 'A resilient, air-purifying trailing vine featuring heart-shaped leaves marbled in rich emerald and creamy chartreuse. Thrives in moderate to bright indirect light and requires minimal fuss.', 540.00, NULL, 'PLT-POT-001', 15, 800, 'Vine length ~35cm', 'Low Light', 1, 1),
(6, 3, 'Snake Plant', 'snake-plant', 'Hardy Sansevieria trifasciata with striking architectural foliage.', 'Known for its upright architectural blades and unmatched resilience. Effectively purifies indoor air and thrives even in low light with infrequent watering schedules.', 690.00, NULL, 'PLT-SNK-002', 12, 1100, 'Height ~40cm', 'Air Purifying', 1, 1),
(7, 4, 'Woven Rattan Wall Mirror', 'woven-rattan-wall-mirror', 'Sunburst-style mirror framed in natural cane and hand-woven rattan.', 'Hand-crafted by master cane artisans using sustainable natural rattan. The sunburst silhouette adds organic warmth and dimension to entryways, bedrooms, or living spaces.', 2100.00, NULL, 'DEC-RAT-001', 8, 1500, '50cm Diameter', 'Artisanal', 1, 1),
(8, 4, 'Hand-Carved Wooden Tray', 'hand-carved-wooden-tray', 'Solid reclaimed teakwood tray with raised rim and organic grain.', 'Carved from a single block of salvaged aged teakwood, finished with food-safe botanical mineral oil. Suitable for displaying candles, planters, or styling tabletop essentials.', 890.00, NULL, 'DEC-TRY-002', 14, 750, '32cm L x 18cm W', 'Handcrafted', 1, 1),
(9, 1, 'Textured Ceramic Vase Duo', 'textured-ceramic-vase-duo', 'Set of two fluted ceramic bud vases in chalk white and sand.', 'Complementary pair of matte-glazed ceramic vases designed for dried botanicals or fresh seasonal stems. Featuring ribbed fluting that highlights handcrafted textures.', 1680.00, 1950.00, 'POT-VAS-003', 10, 1300, '18cm & 12cm H', 'Sale', 1, 1);

-- 4. Product Gallery Images
INSERT INTO `product_images` (`product_id`, `image_url`, `alt_text`, `sort_order`, `is_primary`) VALUES
(1, 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=800&q=80', 'Amber Stoneware Planter', 1, 1),
(2, 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=800&q=80', 'Clay Rim Terracotta Pot', 1, 1),
(3, 'https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=800&q=80', 'Sandalwood Pillar Candle', 1, 1),
(4, 'https://images.unsplash.com/photo-1572726729437-373264770020?auto=format&fit=crop&w=800&q=80', 'Smoked Vanilla Jar Candle', 1, 1),
(5, 'https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=800&q=80', 'Trailing Pothos', 1, 1),
(6, 'https://images.unsplash.com/photo-1593482892290-f54927ae1bf6?auto=format&fit=crop&w=800&q=80', 'Snake Plant', 1, 1),
(7, 'https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&w=800&q=80', 'Woven Rattan Wall Mirror', 1, 1),
(8, 'https://images.unsplash.com/photo-1534349762230-e0cadf78f5da?auto=format&fit=crop&w=800&q=80', 'Hand-Carved Wooden Tray', 1, 1),
(9, 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=800&q=80', 'Textured Ceramic Vase Duo', 1, 1);
