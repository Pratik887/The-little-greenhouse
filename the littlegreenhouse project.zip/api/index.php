<?php
/**
 * The Little Green House - Unified REST API Entry Point & Router
 *
 * Features:
 * - JWT-secured Admin Operations & Customer Authentication
 * - Transactional HTML Email Alerts (Password changes, Admin actions, New orders)
 * - Complete Shiprocket Integration (Orders, AWB, Tracking, Serviceability, Payments)
 * - MySQL PDO Database Persistence
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/utils/JWT.php';
require_once __DIR__ . '/utils/Mailer.php';
require_once __DIR__ . '/utils/Shiprocket.php';
require_once __DIR__ . '/utils/Fastrr.php';
// Optional: the Shiprocket catalog helper must never take down the whole API
// (admin login, checkout) if the file is missing or broken on the server.
$catalogUtil = __DIR__ . '/utils/FastrrCatalog.php';
if (is_file($catalogUtil)) {
    try {
        require_once $catalogUtil;
    } catch (Throwable $e) {
        error_log('FastrrCatalog failed to load: ' . $e->getMessage());
    }
}
require_once __DIR__ . '/middleware/auth.php';

// ====================================================================
// 1. CORS & Response Setup
// ====================================================================
$config     = require __DIR__ . '/config/config.php';
$corsOrigin = $config['app']['cors_origin'] ?? '*';

header("Access-Control-Allow-Origin: {$corsOrigin}");
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ====================================================================
// 2. Request Parsing Helpers
// ====================================================================
function getJsonInput(): array
{
    $raw = file_get_contents('php://input');
    if (empty($raw)) {
        return $_POST ?: [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function jsonResponse(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function errorResponse(string $message, int $statusCode = 400, ?array $extra = null): void
{
    $payload = ['success' => false, 'error' => $message];
    if ($extra) {
        $payload = array_merge($payload, $extra);
    }
    jsonResponse($payload, $statusCode);
}

function getClientIp(): string
{
    return $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}

function verifyAdminPassword(string $password, string $storedHash): bool
{
    if (password_verify($password, $storedHash)) {
        return true;
    }

    if (! preg_match('/^tlgh-pbkdf2-sha256\$(\d{6,7})\$([a-f0-9]{64})\$([a-f0-9]{64})$/', $storedHash, $m)) {
        return false;
    }

    $iterations = (int) $m[1];
    if ($iterations < 100000 || $iterations > 2000000) {
        return false;
    }

    $salt   = hex2bin($m[2]);
    $actual = hash_pbkdf2('sha256', $password, $salt, $iterations, 64, false);
    return hash_equals($m[3], $actual);
}

function logAdminActivity(int $adminId, string $adminEmail, string $action, ?array $details = null): void
{
    try {
        $db   = Database::getConnection();
        $stmt = $db->prepare('INSERT INTO admin_activity_logs (admin_id, admin_email, action, details, ip_address) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([
            $adminId,
            $adminEmail,
            $action,
            $details ? json_encode($details) : null,
            getClientIp(),
        ]);
    } catch (Exception $e) {
        error_log("Failed to write admin activity log: " . $e->getMessage());
    }
}

// ====================================================================
// 3. Routing Normalization
// ====================================================================
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$path       = parse_url($requestUri, PHP_URL_PATH);

// Strip base directory if hosted under a subdirectory (e.g., /TLGH/api or /api)
$scriptDir = dirname($_SERVER['SCRIPT_NAME']);
if ($scriptDir !== '/' && strpos($path, $scriptDir) === 0) {
    $path = substr($path, strlen($scriptDir));
}
$path = '/' . trim($path, '/');
if (strpos($path, '/api') === 0) {
    $path = substr($path, 4); // Strip '/api' prefix
    $path = '/' . trim($path, '/');
}
if (strpos($path, '/index.php') === 0) {
    $path = substr($path, 10);
    $path = '/' . trim($path, '/');
}

// Hosts that ignore api/.htaccess and do not pass PATH_INFO to PHP can still reach
// the API through a plain file URL: /api/index.php?__route=/health
if (isset($_GET['__route']) && is_string($_GET['__route'])) {
    $path = '/' . trim($_GET['__route'], '/');
    unset($_GET['__route']);
}

$method = $_SERVER['REQUEST_METHOD'];
$adminResourceRoute = preg_match('#^/admin/(products|categories|orders)(?:/|$)#', $path) === 1
    && preg_match('#^/admin/orders/[0-9]+/refund$#', $path) !== 1;
if ($adminResourceRoute) {
    // Keep management URLs in a dedicated namespace while sharing handlers.
    $path = substr($path, strlen('/admin'));
}

// ====================================================================
// 4. ROUTE DISPATCHER
// ====================================================================

try {
    // Include connection/bootstrap failures in the JSON error handler. Creating the
    // PDO connection before this try caused blank 500 responses when DB setup failed.
    $db = Database::getConnection();
    if ($adminResourceRoute) {
        AuthMiddleware::requireAdmin();
    }
    // ----------------------------------------------------------------
    // 4.1 System Health
    // ----------------------------------------------------------------
    if ($method === 'GET' && ($path === '' || $path === '/' || $path === '/health')) {
        jsonResponse([
            'success'   => true,
            'app'       => 'The Little Green House API',
            'version'   => '2.0.0',
            'status'    => 'healthy',
            'timestamp' => date('c'),
            'database'  => 'connected',
        ]);
    }

    // ----------------------------------------------------------------
    // 4.2 Shiprocket / Fastrr Custom Checkout & Catalog Feed APIs
    // ----------------------------------------------------------------

    // Owner-managed photos for the public home, about and visit page heroes.
    $siteMediaSlots = ['home_hero', 'home_story', 'about_hero', 'visit_hero'];
    // Product galleries store both image and video URLs in the existing
    // product_images table, preserving the product and checkout schema.
    if ($method === 'POST' && preg_match('#^/products/([0-9]+)/media$#', $path, $mediaMatch)) {
        $admin = AuthMiddleware::requireAdmin();
        $productId = (int) $mediaMatch[1];
        $productCheck = $db->prepare('SELECT id FROM products WHERE id = ? LIMIT 1');
        $productCheck->execute([$productId]);
        if (!$productCheck->fetchColumn()) errorResponse('Product not found.', 404);

        $files = $_FILES['media'] ?? null;
        if (!is_array($files) || !isset($files['name']) || !is_array($files['name'])) {
            errorResponse('Choose one or more product photos or videos.', 400);
        }
        $count = count($files['name']);
        if ($count < 1 || $count > 12) errorResponse('Upload between 1 and 12 files at a time.', 400);

        $baseUrl = rtrim((string) ($config['app']['url'] ?? ''), '/');
        if ($baseUrl === '') errorResponse('The public site URL is not configured.', 500);
        $imageTypes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
        $videoTypes = ['video/mp4' => 'mp4', 'video/webm' => 'webm'];
        $validatedFiles = [];
        foreach ($files['name'] as $i => $originalName) {
            $error = (int) ($files['error'][$i] ?? UPLOAD_ERR_NO_FILE);
            if ($error !== UPLOAD_ERR_OK || !is_uploaded_file($files['tmp_name'][$i] ?? '')) {
                errorResponse('One of the selected files did not upload successfully.', 400);
            }
            $tmp = $files['tmp_name'][$i];
            $size = (int) ($files['size'][$i] ?? 0);
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp) ?: '';
            $isImage = isset($imageTypes[$mime]);
            $isVideo = isset($videoTypes[$mime]);
            if ((!$isImage && !$isVideo) || $size < 1 || $size > ($isImage ? 10 : 50) * 1024 * 1024) {
                errorResponse('Use JPEG, PNG, WebP or GIF images up to 10 MB, or MP4 and WebM videos up to 50 MB.', 415);
            }
            if ($isImage) {
                $info = @getimagesize($tmp);
                if (!$info || (int) $info[0] > 10000 || (int) $info[1] > 10000) {
                    errorResponse('An uploaded image is invalid or larger than 10,000 pixels per side.', 415);
                }
            }
            $ext = $isImage ? $imageTypes[$mime] : $videoTypes[$mime];
            $validatedFiles[] = ['tmp' => $tmp, 'name' => (string) $originalName, 'ext' => $ext, 'is_image' => $isImage];
        }

        $uploadDir = dirname(__DIR__) . '/uploads/products';
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
            errorResponse('Product media storage is unavailable.', 500);
        }
        $saved = [];
        $savedPaths = [];
        $maxSortStmt = $db->prepare('SELECT COALESCE(MAX(sort_order), -1) FROM product_images WHERE product_id = ?');
        $maxSortStmt->execute([$productId]);
        $sortOrder = (int) $maxSortStmt->fetchColumn() + 1;
        $primaryCheck = $db->prepare('SELECT id FROM product_images WHERE product_id = ? AND is_primary = 1 LIMIT 1');
        $primaryCheck->execute([$productId]);
        $hasPrimary = (bool) $primaryCheck->fetchColumn();
        $insertMedia = $db->prepare('INSERT INTO product_images (product_id, image_url, alt_text, sort_order, is_primary) VALUES (?, ?, ?, ?, ?)');
        $db->beginTransaction();
        try {
            foreach ($validatedFiles as $file) {
                $filename = bin2hex(random_bytes(16)) . '.' . $file['ext'];
                $filePath = $uploadDir . '/' . $filename;
                if (!move_uploaded_file($file['tmp'], $filePath)) {
                    throw new RuntimeException('A product media file could not be saved.');
                }
                $savedPaths[] = $filePath;
                $isPrimary = (!$hasPrimary && $file['is_image']) ? 1 : 0;
                $url = $baseUrl . '/uploads/products/' . $filename;
                $alt = function_exists('mb_substr') ? mb_substr(pathinfo($file['name'], PATHINFO_FILENAME), 0, 255) : substr(pathinfo($file['name'], PATHINFO_FILENAME), 0, 255);
                $insertMedia->execute([$productId, $url, $alt, $sortOrder++, $isPrimary]);
                if ($isPrimary) $hasPrimary = true;
                $saved[] = ['id' => (int) $db->lastInsertId(), 'image_url' => $url, 'media_type' => $file['is_image'] ? 'image' : 'video'];
            }
            $db->commit();
        } catch (Throwable $uploadError) {
            if ($db->inTransaction()) $db->rollBack();
            foreach ($savedPaths as $savedPath) if (is_file($savedPath)) @unlink($savedPath);
            errorResponse($uploadError->getMessage(), 500);
        }

        logAdminActivity($admin['id'], $admin['email'], 'UPLOAD_PRODUCT_MEDIA', ['product_id' => $productId, 'count' => count($saved)]);
        if (class_exists('FastrrCatalog')) FastrrCatalog::pushProduct($db, $productId);
        jsonResponse(['success' => true, 'media' => $saved], 201);
    }

    if ($method === 'GET' && $path === '/admin/site-media') {
        AuthMiddleware::requireAdmin('OWNER');
        $rows = $db->query('SELECT slot, image_url FROM site_media ORDER BY slot')->fetchAll();
        $media = [];
        foreach ($rows as $row) { $media[$row['slot']] = $row['image_url']; }
        jsonResponse(['success' => true, 'media' => $media]);
    }
    if ($method === 'POST' && $path === '/admin/site-media') {
        $admin = AuthMiddleware::requireAdmin('OWNER');
        $slot = trim((string) ($_POST['slot'] ?? ''));
        $file = $_FILES['photo'] ?? null;
        if (!in_array($slot, $siteMediaSlots, true)) {
            errorResponse('Choose a supported page photo placement.', 400);
        }
        if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'] ?? '')) {
            errorResponse('Choose an image file to upload.', 400);
        }
        if ((int) ($file['size'] ?? 0) < 1 || (int) $file['size'] > 10 * 1024 * 1024) {
            errorResponse('Images must be smaller than 10 MB.', 413);
        }
        $imageInfo = @getimagesize($file['tmp_name']);
        $mime = $imageInfo['mime'] ?? '';
        $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
        if (!$imageInfo || !isset($extensions[$mime]) || (int) $imageInfo[0] > 10000 || (int) $imageInfo[1] > 10000) {
            errorResponse('Upload a valid JPEG, PNG, WebP or GIF image (maximum 10,000 px per side).', 415);
        }
        $uploadDir = dirname(__DIR__) . '/uploads/site';
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
            errorResponse('Image storage is unavailable on the server.', 500);
        }
        $filename = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
        if (!move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $filename)) {
            errorResponse('The image could not be saved.', 500);
        }
        $imageUrl = rtrim((string) ($config['app']['url'] ?? ''), '/') . '/uploads/site/' . $filename;
        if (($config['db']['driver'] ?? '') === 'mysql') {
            $save = $db->prepare('INSERT INTO site_media(slot, image_url) VALUES(?, ?) ON DUPLICATE KEY UPDATE image_url=VALUES(image_url), updated_at=CURRENT_TIMESTAMP');
        } else {
            $save = $db->prepare('INSERT INTO site_media(slot, image_url) VALUES(?, ?) ON CONFLICT(slot) DO UPDATE SET image_url=excluded.image_url, updated_at=CURRENT_TIMESTAMP');
        }
        $save->execute([$slot, $imageUrl]);
        logAdminActivity($admin['id'], $admin['email'], 'UPDATE_SITE_PHOTO', ['slot' => $slot]);
        jsonResponse(['success' => true, 'slot' => $slot, 'image_url' => $imageUrl]);
    }

    // 1. Fetch Products / Fetch Products by Collection (Shiprocket calls these).
    //    GET ?page=1&limit=100[&collection_id=N]  ->  {"data":{"total":N,"products":[...]}}
    if ($method === 'GET' && in_array($path, ['/fastrr/products', '/shiprocket/products', '/fastrr/collection-products', '/shiprocket/collection-products'], true)) {
        if (!class_exists('FastrrCatalog')) {
            errorResponse('Catalog helper missing on server: upload api/utils/FastrrCatalog.php', 503);
        }
        $rawPage = (int) ($_GET['page'] ?? 1);
        $page    = max(0, $rawPage > 0 ? $rawPage - 1 : 0);
        $limit   = min(250, max(1, (int) ($_GET['limit'] ?? 100)));
        $colId   = (int) ($_GET['collection_id'] ?? 0);

        $whereClause = 'WHERE p.is_active=1';
        $params      = [];
        if ($colId > 0) {
            $whereClause .= ' AND p.category_id=?';
            $params[]     = $colId;
        }

        $countStmt = $db->prepare("SELECT COUNT(*) FROM products p {$whereClause}");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        $stmt = $db->prepare(FastrrCatalog::productSelect() . " {$whereClause} ORDER BY p.id LIMIT ? OFFSET ?");
        $paramIndex = 1;
        foreach ($params as $pVal) {
            $stmt->bindValue($paramIndex++, $pVal, PDO::PARAM_INT);
        }
        $stmt->bindValue($paramIndex++, $limit, PDO::PARAM_INT);
        $stmt->bindValue($paramIndex++, $page * $limit, PDO::PARAM_INT);
        $stmt->execute();

        jsonResponse(['data' => ['total' => $total, 'products' => array_map([FastrrCatalog::class, 'mapProduct'], $stmt->fetchAll())]]);
    }

    // 2. Fetch Collections  ->  {"data":{"total":N,"collections":[...]}}
    if ($method === 'GET' && in_array($path, ['/fastrr/collections', '/shiprocket/collections'], true)) {
        if (!class_exists('FastrrCatalog')) {
            errorResponse('Catalog helper missing on server: upload api/utils/FastrrCatalog.php', 503);
        }
        $rawPage = (int) ($_GET['page'] ?? 1);
        $page = max(0, $rawPage > 0 ? $rawPage - 1 : 0);
        $limit = min(250, max(1, (int) ($_GET['limit'] ?? 100)));
        $total = (int) $db->query('SELECT COUNT(*) FROM categories WHERE is_active=1')->fetchColumn();
        $stmt = $db->prepare('SELECT id, name, slug, description, image_url, created_at, updated_at FROM categories WHERE is_active=1 ORDER BY sort_order, id LIMIT ? OFFSET ?');
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->bindValue(2, $page * $limit, PDO::PARAM_INT);
        $stmt->execute();

        jsonResponse(['data' => ['total' => $total, 'collections' => array_map([FastrrCatalog::class, 'mapCollection'], $stmt->fetchAll())]]);
    }

    // Owner-only: push the whole catalog to Shiprocket via the signed catalog webhooks.
    if ($method === 'POST' && $path === '/admin/fastrr/catalog/sync') {
        $admin = AuthMiddleware::requireAdmin('OWNER');
        if (!class_exists('FastrrCatalog')) {
            errorResponse('Catalog helper missing on server: upload api/utils/FastrrCatalog.php', 503);
        }
        $result = FastrrCatalog::pushAll($db);
        logAdminActivity($admin['id'], $admin['email'], 'FASTRR_CATALOG_SYNC', $result);
        jsonResponse(['success' => true, 'synced' => $result]);
    }

    // 3. Loyalty Points Manager APIs (Configurable in Shiprocket Custom Endpoints)
    if ($method === 'POST' && in_array($path, ['/fastrr/loyalty/get-points', '/shiprocket/loyalty/get-points'], true)) {
        $input = getJsonInput();
        $mobile = (string) ($input['mobile_number'] ?? '');
        jsonResponse([
            'data' => [
                'mobile_number'     => $mobile,
                'available_points'  => 0,
                'applicable_points' => 0
            ]
        ]);
    }

    if ($method === 'POST' && in_array($path, ['/fastrr/loyalty/block-points', '/shiprocket/loyalty/block-points'], true)) {
        $input = getJsonInput();
        $orderId = (string) ($input['order_id'] ?? '0');
        jsonResponse([
            'data' => [
                'status'           => true,
                'available_points' => 0,
                'message'          => 'Valid Customer Id',
                'debited_points'   => 0,
                'transaction_id'   => $orderId,
                'discount_value'   => 0
            ]
        ]);
    }

    if ($method === 'POST' && in_array($path, ['/fastrr/loyalty/unblock-points', '/shiprocket/loyalty/unblock-points'], true)) {
        jsonResponse(['data' => ['status' => 'Success']]);
    }

    // 4. Initiate Fastrr / Shiprocket Checkout Session
    if ($method === 'POST' && in_array($path, ['/fastrr/checkout', '/shiprocket/checkout'], true)) {
        $data = getJsonInput();
        $inputItems = $data['items'] ?? [];
        if (!$inputItems || !is_array($inputItems) || count($inputItems) > 50) {
            errorResponse('The cart must contain between 1 and 50 product rows');
        }

        // Normalize and merge duplicate product IDs before signing the cart.
        // This guarantees a single unique variant_id per catalog item.
        $quantities = [];
        foreach ($inputItems as $item) {
            if (!is_array($item)) {
                errorResponse('Invalid product or quantity');
            }
            $pid = filter_var($item['product_id'] ?? null, FILTER_VALIDATE_INT);
            $qty = filter_var($item['quantity'] ?? null, FILTER_VALIDATE_INT);
            if ($pid === false || $pid < 1 || $qty === false || $qty < 1) {
                errorResponse('Invalid product or quantity');
            }
            $quantities[$pid] = ($quantities[$pid] ?? 0) + $qty;
            if ($quantities[$pid] > 20) {
                errorResponse('Invalid product or quantity');
            }
        }
        $items = [];
        foreach ($quantities as $pid => $qty) {
            $items[] = ['product_id' => (int) $pid, 'quantity' => (int) $qty];
        }

        $variants = [];
        foreach ($items as $item) {
            $pid = (int) ($item['product_id'] ?? 0);
            $qty = (int) ($item['quantity'] ?? 0);
            if ($pid < 1 || $qty < 1 || $qty > 20) {
                errorResponse('Invalid product or quantity');
            }

            $q = $db->prepare('SELECT p.*, (SELECT image_url FROM product_images WHERE product_id=p.id AND is_primary=1 LIMIT 1) AS image_url, COALESCE(online_stock_quantity,stock_quantity) AS online_stock_quantity FROM products p WHERE p.id=?');
            $q->execute([$pid]);
            $p = $q->fetch();
            if (! $p || ! (int) $p['is_active'] || (int) $p['online_stock_quantity'] < $qty) {
                errorResponse('A cart item is unavailable or out of stock', 409);
            }

            // Provide variant_id + optional inline catalog_data for custom checkout
            $variantId = (string) (2147483648 + $pid);
            $variant = [
                'variant_id' => $variantId,
                'quantity'   => $qty,
            ];
            $imageUrl = trim((string) ($p['image_url'] ?? ''));
            if ($imageUrl !== '' && filter_var($imageUrl, FILTER_VALIDATE_URL)
                && in_array(strtolower((string) parse_url($imageUrl, PHP_URL_SCHEME)), ['http', 'https'], true)) {
                // Custom catalog data is optional; when present all required
                // properties (price, name, image_url) must be populated.
                $variant['catalog_data'] = [
                    'price'     => (float) $p['price'],
                    'name'      => (string) $p['name'],
                    'image_url' => $imageUrl,
                ];
            }
            $variants[] = $variant;
        }
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') ? 'https://' : 'http://';
        $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
        $configuredAppUrl = rtrim($config['app']['url'] ?? '', '/');
        $requestHost = strtolower((string) (parse_url('//' . $host, PHP_URL_HOST) ?: ''));
        $remoteHost = trim((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
        $isLoopbackClient = in_array($remoteHost, ['127.0.0.1', '::1'], true);
        $isLocalRequest = $isLoopbackClient && (in_array($requestHost, ['localhost', '127.0.0.1', '::1'], true)
            || str_ends_with($requestHost, '.localhost')
            || str_ends_with($requestHost, '.test'));
        $configuredHost = strtolower((string) (parse_url($configuredAppUrl, PHP_URL_HOST) ?: ''));
        $base = ($isLocalRequest && $host !== '')
            ? $protocol . $host
            : ((!empty($configuredHost) ? $configuredAppUrl : ($host ? $protocol . $host : $configuredAppUrl)));
        $returnUrl = rtrim($base, '/') . '/fastrr-return.php';
        $session   = bin2hex(random_bytes(20));
        $checkout  = Fastrr::createCheckoutToken($variants, $returnUrl . '?ref=' . $session);
        if (empty($checkout['success'])) {
            errorResponse($checkout['message'] ?? 'Fastrr checkout could not be started', 502);
        }

        $result  = $checkout['data'];
        $orderId = (string) ($result['order_id'] ?? $result['data']['order_id'] ?? '');
        $token   = (string) ($result['token'] ?? $result['access_token'] ?? $result['checkout_token'] ?? $result['data']['token'] ?? '');
        if ($orderId === '' || $token === '') {
            errorResponse('Fastrr returned an incomplete checkout session', 502);
        }

        $save = $db->prepare('INSERT INTO fastrr_checkouts(checkout_ref,fastrr_order_id,items_json) VALUES(?,?,?)');
        $save->execute([$session, $orderId, json_encode($items)]);
        jsonResponse([
            'success'         => true,
            'token'           => $token,
            'fastrr_order_id' => $orderId,
            'checkout_script' => $config['fastrr']['checkout_script'],
            'checkout_style'  => $config['fastrr']['checkout_style']
        ]);
    }

    // 5. Verify redirect callbacks server-to-server and handle Order Webhooks
    if (($method === 'POST' && in_array($path, ['/fastrr/verify', '/shiprocket/verify', '/fastrr/webhook', '/wh/v1/custom/order'], true))) {
        $isWebhook = in_array($path, ['/fastrr/webhook', '/wh/v1/custom/order'], true);
        $data      = getJsonInput();
        $ref       = trim((string) ($data['ref'] ?? ''));
        $orderId   = trim((string) ($data['order_id'] ?? $data['oid'] ?? ''));
        if ($orderId === '' || (! $isWebhook && $ref === '')) {
            errorResponse('Checkout reference and Fastrr order ID are required');
        }

        $q = $isWebhook ? $db->prepare('SELECT * FROM fastrr_checkouts WHERE fastrr_order_id=? LIMIT 1') : $db->prepare('SELECT * FROM fastrr_checkouts WHERE checkout_ref=? AND fastrr_order_id=? LIMIT 1');
        $q->execute($isWebhook ? [$orderId] : [$ref, $orderId]);
        $session = $q->fetch();
        if (! $session) {
            errorResponse('Checkout session not found', 404);
        }

        if ($session['processed_order_id']) {
            $q = $db->prepare('SELECT order_number,payment_status,order_status FROM orders WHERE id=?');
            $q->execute([$session['processed_order_id']]);
            jsonResponse(['success' => true, 'order' => $q->fetch(), 'already_processed' => true]);
        }
        $verified = Fastrr::orderDetails($orderId);
        if (empty($verified['success'])) {
            errorResponse('Could not verify the Fastrr order. Please retry shortly.', 502);
        }

        $remote = $verified['data'];
        if (($remote['order_id'] ?? '') !== $orderId || strtoupper((string) ($remote['status'] ?? '')) !== 'SUCCESS') {
            errorResponse('Fastrr has not confirmed this order yet', 409);
        }

        $paymentType    = strtoupper((string) ($remote['payment_type'] ?? ''));
        $paymentStatus  = strtolower((string) ($remote['payment_status'] ?? 'pending'));
        $isCod          = in_array($paymentType, ['COD', 'CASH_ON_DELIVERY'], true);
        $transactionId  = null;
        $receivedAmount = 0.0;
        if (! $isCod && $paymentStatus !== 'success') {
            errorResponse('Fastrr payment is not confirmed', 409);
        }

        if (! $isCod) {
            // The documented Order Details response includes `payments[]`;
            // there is no separate order-transactions endpoint.
            $confirmedPayments = array_values(array_filter(
                is_array($remote['payments'] ?? null) ? $remote['payments'] : [],
                static fn($payment) => is_array($payment)
                    && strtolower((string) ($payment['payment_status'] ?? '')) === 'success'
                    && (float) ($payment['amount_received'] ?? $payment['amount'] ?? 0) > 0
            ));
            if (!$confirmedPayments) {
                errorResponse('No successful Fastrr payment transaction was found', 409);
            }
            $receivedAmount = array_sum(array_map(
                static fn($payment) => (float) ($payment['amount_received'] ?? $payment['amount'] ?? 0),
                $confirmedPayments
            ));
            $transactionIds = array_values(array_filter(array_map(
                static fn($payment) => trim((string) ($payment['pg_transaction_id'] ?? $payment['txn_id'] ?? '')),
                $confirmedPayments
            )));
            $transactionId = $transactionIds ? implode(',', $transactionIds) : null;
        }
        $address = $remote['shipping_address'] ?? [];
        $email   = strtolower(trim((string) ($remote['email'] ?? $address['email'] ?? '')));
        $phone   = trim((string) ($remote['phone'] ?? $address['phone'] ?? ''));
        if (! filter_var($email, FILTER_VALIDATE_EMAIL) || $phone === '') {
            errorResponse('Fastrr order is missing valid customer contact information', 422);
        }

        $name       = trim(($address['first_name'] ?? '') . ' ' . ($address['last_name'] ?? '')) ?: 'Customer';
        $shipping   = ['full_name' => $name, 'phone' => $phone, 'address_line1' => $address['line1'] ?? '', 'address_line2' => $address['line2'] ?? '', 'city' => $address['city'] ?? '', 'state' => $address['state'] ?? '', 'postal_code' => $address['pincode'] ?? '', 'country' => $address['country'] ?? 'India'];
        $cart       = json_decode($session['items_json'] ?? '[]', true) ?: [];
        $orderItems = [];
        $subtotal   = 0.0;
        
        // If local cart session is present, process it
        $itemsToProcess = !empty($cart) ? $cart : ($remote['cart_data']['items'] ?? []);
        foreach ($itemsToProcess as $item) {
            $variantId = trim((string) ($item['variant_id'] ?? ''));
            $mappedVariantProductId = ctype_digit($variantId) && (int) $variantId > 2147483648
                ? (int) $variantId - 2147483648
                : (ctype_digit($variantId) ? (int) $variantId : 0);
            $pid = (int) ($item['product_id'] ?? $mappedVariantProductId);
            $sku = trim((string) ($item['sku'] ?? (!ctype_digit($variantId) ? $variantId : '')));
            
            $q = $db->prepare('SELECT id, name, sku, price, COALESCE(online_stock_quantity, stock_quantity) AS online_stock_quantity, weight_grams FROM products WHERE (sku = ? OR id = ?) AND is_active = 1 LIMIT 1');
            $q->execute([$sku, $pid]);
            $p   = $q->fetch();
            $qty = max(1, (int) ($item['quantity'] ?? 1));
            
            if ($p) {
                $total         = (float) $p['price'] * $qty;
                $subtotal     += $total;
                $orderItems[]  = [
                    'product_id'   => (int) $p['id'],
                    'product_name' => $p['name'],
                    'sku'          => $p['sku'],
                    'unit_price'   => (float) $p['price'],
                    'quantity'     => $qty,
                    'total_price'  => $total,
                    'weight_grams' => (int) $p['weight_grams']
                ];
            }
        }
        if (empty($orderItems)) {
            errorResponse('Unable to match order items with product catalog by SKU', 422);
        }
        $discount    = max(0, (float) ($remote['total_discount'] ?? $remote['coupon_discount'] ?? 0));
        $remoteTotal = max(0, (float) ($remote['total_amount_payable'] ?? ($subtotal - $discount)));
        if (! $isCod && $receivedAmount + 0.01 < $remoteTotal) {
            errorResponse('Verified payment amount does not cover the Fastrr order total', 409);
        }

        $shippingCost = max(0, $remoteTotal + $discount - $subtotal);
        $finalTotal   = max(0, $subtotal + $shippingCost - $discount);
        $number       = 'TLGH-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        $db->beginTransaction();
        try {
            // Serialize callback/webhook retries for this provider checkout.
            $lockSql = 'SELECT processed_order_id FROM fastrr_checkouts WHERE id = ?';
            if (($config['db']['driver'] ?? '') === 'mysql') {
                $lockSql .= ' FOR UPDATE';
            }
            $lock = $db->prepare($lockSql);
            $lock->execute([(int) $session['id']]);
            $lockedSession = $lock->fetch();
            if (!$lockedSession) {
                throw new DomainException('Checkout session no longer exists.');
            }
            if (!empty($lockedSession['processed_order_id'])) {
                $db->commit();
                $existingOrder = $db->prepare('SELECT order_number, payment_status, order_status FROM orders WHERE id = ?');
                $existingOrder->execute([(int) $lockedSession['processed_order_id']]);
                jsonResponse(['success' => true, 'order' => $existingOrder->fetch(), 'already_processed' => true]);
            }

            $ins = $db->prepare('INSERT INTO orders(order_number,customer_name,customer_email,customer_phone,shipping_address,subtotal,shipping_cost,discount_amount,total_amount,payment_status,payment_method,payment_transaction_id,order_status,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            $ins->execute([$number, $name, $email, $phone, json_encode($shipping), $subtotal, $shippingCost, $discount, $finalTotal, $isCod ? 'PENDING' : 'PAID', $isCod ? 'COD' : 'FASTRR', $transactionId ?: null, 'CONFIRMED', 'Fastrr order ' . $orderId]);
            $localId = (int) $db->lastInsertId();
            $itemIns = $db->prepare('INSERT INTO order_items(order_id,product_id,product_name,sku,unit_price,quantity,total_price) VALUES(?,?,?,?,?,?,?)');
            $stock = $db->prepare('UPDATE products SET online_stock_quantity=COALESCE(online_stock_quantity,stock_quantity)-?, stock_quantity=stock_quantity-? WHERE id=? AND COALESCE(online_stock_quantity,stock_quantity)>=? AND stock_quantity>=?');
            foreach ($orderItems as $it) {
                $itemIns->execute([$localId, $it['product_id'], $it['product_name'], $it['sku'], $it['unit_price'], $it['quantity'], $it['total_price']]);
                $stock->execute([$it['quantity'], $it['quantity'], $it['product_id'], $it['quantity'], $it['quantity']]);
                if ($stock->rowCount() !== 1) {
                    throw new DomainException('A product went out of stock while the order was being confirmed.');
                }
            }
            $done = $db->prepare('UPDATE fastrr_checkouts SET processed_order_id=? WHERE id=?');
            $done->execute([$localId, $session['id']]);
            $db->commit();
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            if ($e instanceof DomainException) {
                errorResponse($e->getMessage(), 409);
            }
            throw $e;
        }
        $sr         = Shiprocket::createOrder(['order_number' => $number, 'customer_name' => $name, 'customer_email' => $email, 'customer_phone' => $phone, 'shipping_address' => $shipping, 'subtotal' => $subtotal, 'shipping_cost' => $shippingCost, 'total_amount' => $subtotal + $shippingCost, 'payment_method' => $isCod ? 'COD' : 'FASTRR', 'items' => $orderItems]);
        $srOrder    = $sr['order_id'] ?? null;
        $srShipment = $sr['shipment_id'] ?? null;
        $srAwb      = $sr['awb_code'] ?? null;
        $courier    = $sr['courier_name'] ?? null;
        $tracking   = $srAwb ? 'https://shiprocket.co/tracking/' . $srAwb : null;
        if ($srShipment && ! $srAwb) {$awb = Shiprocket::generateAWB((int) $srShipment);
            $srAwb                          = $awb['response']['data']['awb_code'] ?? null;
            $courier                        = $awb['response']['data']['courier_name'] ?? $courier;if ($srAwb) {
                $tracking = 'https://shiprocket.co/tracking/' . $srAwb;
            }
        }
        if ($srOrder || $srShipment || $srAwb) {$u = $db->prepare('UPDATE orders SET shiprocket_order_id=?,shiprocket_shipment_id=?,shiprocket_awb=?,courier_name=?,tracking_url=?,shiprocket_status=? WHERE id=?');
            $u->execute([$srOrder, $srShipment, $srAwb, $courier, $tracking, 'CREATED', $localId]);}
        jsonResponse(['success' => true, 'order' => ['order_number' => $number, 'payment_status' => $isCod ? 'PENDING' : 'PAID', 'order_status' => 'CONFIRMED']]);
    }

    // ----------------------------------------------------------------
    // 4.2 Admin Authentication & Password Operations (JWT + Emails)
    // ----------------------------------------------------------------

    // POST /api/auth/admin/login
    if ($method === 'POST' && $path === '/auth/admin/login') {
        $data     = getJsonInput();
        $email    = strtolower(trim($data['email'] ?? ''));
        $password = $data['password'] ?? '';

        if (empty($email) || empty($password)) {
            errorResponse('Email and password are required');
        }

        // Persistent per-IP throttling limits password guessing across PHP workers.
        $db->exec('CREATE TABLE IF NOT EXISTS admin_login_attempts (ip_hash VARCHAR(64) PRIMARY KEY, attempts INTEGER NOT NULL, window_started INTEGER NOT NULL, blocked_until INTEGER NOT NULL DEFAULT 0)');
        $ipHash = hash('sha256', (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
        $now = time();
        $attemptStmt = $db->prepare('SELECT attempts, window_started, blocked_until FROM admin_login_attempts WHERE ip_hash = ?');
        $attemptStmt->execute([$ipHash]);
        $attempt = $attemptStmt->fetch();
        if ($attempt && (int) $attempt['blocked_until'] > $now) {
            errorResponse('Too many sign-in attempts. Try again later.', 429);
        }
        if (!$attempt || $now - (int) $attempt['window_started'] >= 900) {
            if ($attempt) {
                $reset = $db->prepare('UPDATE admin_login_attempts SET attempts = 0, window_started = ?, blocked_until = 0 WHERE ip_hash = ?');
                $reset->execute([$now, $ipHash]);
            } else {
                $reset = $db->prepare('INSERT INTO admin_login_attempts (ip_hash, attempts, window_started, blocked_until) VALUES (?, 0, ?, 0)');
                $reset->execute([$ipHash, $now]);
            }
        }

        $stmt = $db->prepare('SELECT id, full_name, email, password_hash, role, is_active FROM admins WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if (! $admin || ! verifyAdminPassword($password, $admin['password_hash'])) {
            $fail = $db->prepare('UPDATE admin_login_attempts SET attempts = attempts + 1, blocked_until = CASE WHEN attempts + 1 >= 5 THEN ? ELSE blocked_until END WHERE ip_hash = ?');
            $fail->execute([$now + 900, $ipHash]);
            errorResponse('Invalid admin email or password', 401);
        }

        if (! (bool) $admin['is_active']) {
            errorResponse('This admin account has been suspended', 403);
        }

        $clearAttempts = $db->prepare('DELETE FROM admin_login_attempts WHERE ip_hash = ?');
        $clearAttempts->execute([$ipHash]);

        $token = JWT::encode([
            'sub'       => (int) $admin['id'],
            'role_type' => 'admin',
            'role'      => $admin['role'],
            'email'     => $admin['email'],
            'name'      => $admin['full_name'],
        ], $config['jwt']['secret'], $config['jwt']['expiry_admin']);

        logAdminActivity($admin['id'], $admin['email'], 'ADMIN_LOGIN');

        jsonResponse([
            'success' => true,
            'message' => 'Login successful',
            'token'   => $token,
            'admin'   => [
                'id'        => (int) $admin['id'],
                'full_name' => $admin['full_name'],
                'email'     => $admin['email'],
                'role'      => $admin['role'],
            ],
        ]);
    }

    // POST /api/auth/admin/change-password (JWT ENFORCED + EMAIL ALERT)
    if ($method === 'POST' && $path === '/auth/admin/change-password') {
        $admin = AuthMiddleware::requireAdmin();
        $data  = getJsonInput();

        $currentPassword = $data['current_password'] ?? '';
        $newPassword     = $data['new_password'] ?? '';

        if (empty($currentPassword) || empty($newPassword)) {
            errorResponse('Current password and new password are required');
        }
        if (strlen($newPassword) < 8) {
            errorResponse('New password must be at least 8 characters long');
        }

        // Verify current password
        $stmt = $db->prepare('SELECT password_hash FROM admins WHERE id = ?');
        $stmt->execute([$admin['id']]);
        $row = $stmt->fetch();

        if (! verifyAdminPassword($currentPassword, $row['password_hash'])) {
            errorResponse('Current password is incorrect', 400);
        }

        $newHash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 10]);
        $stmt    = $db->prepare('UPDATE admins SET password_hash = ? WHERE id = ?');
        $stmt->execute([$newHash, $admin['id']]);

        $ip = getClientIp();
        logAdminActivity($admin['id'], $admin['email'], 'PASSWORD_CHANGED');

        // Send security email alert to admin
        Mailer::sendPasswordChangedAlert($admin['email'], $admin['full_name'], $ip);

        jsonResponse([
            'success' => true,
            'message' => 'Password updated successfully. Security confirmation email sent.',
        ]);
    }

    // POST /api/auth/admin/forgot-password (EMAIL DISPATCH)
    if ($method === 'POST' && $path === '/auth/admin/forgot-password') {
        $data  = getJsonInput();
        $email = trim($data['email'] ?? '');

        if (empty($email)) {
            errorResponse('Email is required');
        }

        $stmt = $db->prepare('SELECT id, full_name, email FROM admins WHERE email = ? AND is_active = 1');
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin) {
            $token     = bin2hex(random_bytes(32));
            $expiresAt = date('Y-m-d H:i:s', time() + 3600); // 1 hour

            $stmt = $db->prepare('INSERT INTO password_reset_tokens (email, token, user_type, expires_at) VALUES (?, ?, "ADMIN", ?)');
            $stmt->execute([$admin['email'], $token, $expiresAt]);

            // Dispatch reset email with link
            Mailer::sendPasswordResetLink($admin['email'], $token, $admin['full_name'], 'ADMIN');
        }

        // Always return success to prevent email enumeration
        jsonResponse([
            'success' => true,
            'message' => 'If an active admin account matches that email, a password reset link has been dispatched.',
        ]);
    }

    // POST /api/auth/admin/reset-password
    if ($method === 'POST' && $path === '/auth/admin/reset-password') {
        $data        = getJsonInput();
        $token       = trim($data['token'] ?? '');
        $newPassword = $data['new_password'] ?? '';

        if (empty($token) || empty($newPassword)) {
            errorResponse('Reset token and new password are required');
        }
        if (strlen($newPassword) < 8) {
            errorResponse('New password must be at least 8 characters long');
        }

        $stmt = $db->prepare('SELECT * FROM password_reset_tokens WHERE token = ? AND user_type = "ADMIN" AND used_at IS NULL AND expires_at > NOW() LIMIT 1');
        $stmt->execute([$token]);
        $resetRecord = $stmt->fetch();

        if (! $resetRecord) {
            errorResponse('Invalid or expired password reset token', 400);
        }

        $newHash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 10]);
        $stmt    = $db->prepare('UPDATE admins SET password_hash = ? WHERE email = ?');
        $stmt->execute([$newHash, $resetRecord['email']]);

        // Mark token used
        $stmt = $db->prepare('UPDATE password_reset_tokens SET used_at = NOW() WHERE id = ?');
        $stmt->execute([$resetRecord['id']]);

        // Send alert
        Mailer::sendPasswordChangedAlert($resetRecord['email'], 'Administrator', getClientIp());

        jsonResponse([
            'success' => true,
            'message' => 'Password reset successfully. You may now log in with your new password.',
        ]);
    }

    // ----------------------------------------------------------------
    // 4.3 Customer Authentication
    // ----------------------------------------------------------------

    // Customer accounts are intentionally disabled; checkout is guest-only.
    if ($method === 'POST' && $path === '/auth/customer/register') {
        errorResponse('Customer accounts are disabled. Place an order as a guest.', 410);
    }

    // POST /api/auth/customer/login
    if ($method === 'POST' && $path === '/auth/customer/login') {
        errorResponse('Customer accounts are disabled. Continue as a guest.', 410);
    }

    // ----------------------------------------------------------------
    // 4.4 Products & Categories (Public GET, Admin JWT for CUD)
    // ----------------------------------------------------------------

    // GET /api/categories
    if ($method === 'GET' && $path === '/categories') {
        $categoryVisibility = $adminResourceRoute ? '1 = 1' : 'is_active = 1';
        $stmt = $db->query("SELECT * FROM categories WHERE {$categoryVisibility} ORDER BY sort_order ASC, name ASC");
        jsonResponse(['success' => true, 'categories' => $stmt->fetchAll()]);
    }

    // Admin category management
    if ($method === 'POST' && $path === '/categories') {
        $admin = AuthMiddleware::requireAdmin();
        $data  = getJsonInput();
        $name  = trim($data['name'] ?? '');
        $slug  = strtolower(trim($data['slug'] ?? preg_replace('/[^a-z0-9]+/i', '-', $name), '-'));
        if ($name === '' || $slug === '') {
            errorResponse('Category name is required');
        }

        $stmt = $db->prepare('INSERT INTO categories (name, slug, description, image_url, sort_order) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$name, $slug, $data['description'] ?? null, $data['image_url'] ?? null, (int) ($data['sort_order'] ?? 0)]);
        logAdminActivity((int) $admin['id'], $admin['email'], 'CREATE_CATEGORY', ['name' => $name]);
        $newCatId = (int) $db->lastInsertId();
        if (class_exists('FastrrCatalog')) { FastrrCatalog::pushCollection($db, $newCatId); }
        jsonResponse(['success' => true, 'category_id' => $newCatId], 201);
    }

    // GET /api/products
    if ($method === 'GET' && $path === '/products') {
        $categoryId   = isset($_GET['category_id']) ? (int) $_GET['category_id'] : null;
        $categorySlug = $_GET['category'] ?? null;
        $featured     = isset($_GET['featured']) ? (int) $_GET['featured'] : null;
        $search       = trim($_GET['search'] ?? '');
        $slug         = trim((string) ($_GET['slug'] ?? ''));

        $sql = 'SELECT p.*, c.name as category_name, c.slug as category_slug,
                (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image,
                (SELECT AVG(rating) FROM reviews WHERE product_id = p.id AND is_approved = 1) as average_rating,
                (SELECT COUNT(*) FROM reviews WHERE product_id = p.id AND is_approved = 1) as reviews_count
                FROM products p
                JOIN categories c ON p.category_id = c.id
                WHERE ' . ($adminResourceRoute ? '1 = 1' : 'p.is_active = 1');
        $params = [];

        if ($categoryId) {
            $sql      .= ' AND p.category_id = ?';
            $params[]  = $categoryId;
        }
        if ($categorySlug) {
            $sql      .= ' AND c.slug = ?';
            $params[]  = $categorySlug;
        }
        if ($featured !== null) {
            $sql      .= ' AND p.is_featured = ?';
            $params[]  = $featured;
        }
        if ($search) {
            $sql        .= ' AND (p.name LIKE ? OR p.description LIKE ? OR p.tag LIKE ?)';
            $searchTerm  = "%{$search}%";
            $params[]    = $searchTerm;
            $params[]    = $searchTerm;
            $params[]    = $searchTerm;
        }
        if ($slug !== '') {
            $sql .= ' AND p.slug = ?';
            $params[] = $slug;
        }

        $sql  .= ' ORDER BY p.is_featured DESC, p.created_at DESC';
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $products = $stmt->fetchAll();

        jsonResponse(['success' => true, 'count' => count($products), 'products' => $products]);
    }

    // GET /api/products/{id}
    if ($method === 'GET' && preg_match('#^/products/([0-9]+)$#', $path, $matches)) {
        $productId = (int) $matches[1];
        $stmt      = $db->prepare('SELECT p.*, c.name as category_name, c.slug as category_slug FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ? LIMIT 1');
        $stmt->execute([$productId]);
        $product = $stmt->fetch();

        if (! $product) {
            errorResponse('Product not found', 404);
        }

        // Fetch gallery images
        $imgStmt = $db->prepare('SELECT * FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC');
        $imgStmt->execute([$productId]);
        $product['images'] = $imgStmt->fetchAll();

        // Fetch approved reviews
        $revStmt = $db->prepare('SELECT id, reviewer_name, rating, title, comment, is_verified_purchase, created_at FROM reviews WHERE product_id = ? AND is_approved = 1 ORDER BY created_at DESC');
        $revStmt->execute([$productId]);
        $product['reviews'] = $revStmt->fetchAll();

        jsonResponse(['success' => true, 'product' => $product]);
    }

    // POST /api/products (ADMIN JWT ENFORCED)
    if ($method === 'POST' && $path === '/products') {
        $admin = AuthMiddleware::requireAdmin();
        $data  = getJsonInput();

        if (empty($data['name']) || empty($data['price']) || empty($data['sku']) || empty($data['category_id'])) {
            errorResponse('Name, price, SKU, and category are required');
        }

        $slug = $data['slug'] ?? strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $data['name']), '-'));

        $onlineStock = max(0, (int) ($data['online_stock_quantity'] ?? $data['stock_quantity'] ?? 0));
        $localStock  = max(0, (int) ($data['local_stock_quantity'] ?? 0));
        $stmt = $db->prepare('INSERT INTO products (category_id, name, slug, short_description, description, price, compare_at_price, sku, stock_quantity, online_stock_quantity, local_stock_quantity, weight_grams, dimensions, care_instructions, tag, is_active, is_featured) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            (int) $data['category_id'],
            $data['name'],
            $slug,
            $data['short_description'] ?? null,
            $data['description'] ?? null,
            (float) $data['price'],
            ! empty($data['compare_at_price']) ? (float) $data['compare_at_price'] : null,
            $data['sku'],
            $onlineStock,
            $onlineStock,
            $localStock,
            (int) ($data['weight_grams'] ?? 500),
            $data['dimensions'] ?? null,
            $data['care_instructions'] ?? null,
            $data['tag'] ?? null,
            isset($data['is_active']) ? (int) $data['is_active'] : 1,
            isset($data['is_featured']) ? (int) $data['is_featured'] : 0,
        ]);
        $newId = (int) $db->lastInsertId();

        // Insert primary image if provided
        if (! empty($data['image_url'])) {
            $imgStmt = $db->prepare('INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, 1)');
            $imgStmt->execute([$newId, $data['image_url']]);
        }

        logAdminActivity($admin['id'], $admin['email'], 'CREATE_PRODUCT', ['product_id' => $newId, 'name' => $data['name']]);
        if (class_exists('FastrrCatalog')) { FastrrCatalog::pushProduct($db, $newId); }

        jsonResponse(['success' => true, 'message' => 'Product created successfully', 'product_id' => $newId], 201);
    }

    // PUT /api/products/{id} (ADMIN JWT ENFORCED)
    if ($method === 'PUT' && preg_match('#^/products/([0-9]+)$#', $path, $matches)) {
        $admin     = AuthMiddleware::requireAdmin();
        $productId = (int) $matches[1];
        $data      = getJsonInput();

        $stmt = $db->prepare('UPDATE products SET
            category_id = COALESCE(?, category_id),
            name = COALESCE(?, name),
            sku = COALESCE(?, sku),
            price = COALESCE(?, price),
            compare_at_price = ?,
            stock_quantity = COALESCE(?, stock_quantity),
            online_stock_quantity = COALESCE(?, online_stock_quantity),
            local_stock_quantity = COALESCE(?, local_stock_quantity),
            weight_grams = COALESCE(?, weight_grams),
            tag = COALESCE(?, tag),
            dimensions = COALESCE(?, dimensions),
            care_instructions = COALESCE(?, care_instructions),
            description = COALESCE(?, description),
            short_description = COALESCE(?, short_description),
            is_active = COALESCE(?, is_active),
            is_featured = COALESCE(?, is_featured)
            WHERE id = ?');
        $stmt->execute([
            isset($data['category_id']) ? (int) $data['category_id'] : null,
            $data['name'] ?? null,
            $data['sku'] ?? null,
            isset($data['price']) ? (float) $data['price'] : null,
            isset($data['compare_at_price']) ? (float) $data['compare_at_price'] : null,
            isset($data['online_stock_quantity']) ? max(0, (int) $data['online_stock_quantity']) : (isset($data['stock_quantity']) ? max(0, (int) $data['stock_quantity']) : null),
            isset($data['online_stock_quantity']) ? max(0, (int) $data['online_stock_quantity']) : (isset($data['stock_quantity']) ? max(0, (int) $data['stock_quantity']) : null),
            isset($data['local_stock_quantity']) ? max(0, (int) $data['local_stock_quantity']) : null,
            isset($data['weight_grams']) ? (int) $data['weight_grams'] : null,
            $data['tag'] ?? null,
            $data['dimensions'] ?? null,
            $data['care_instructions'] ?? null,
            $data['description'] ?? null,
            $data['short_description'] ?? null,
            isset($data['is_active']) ? (int) $data['is_active'] : null,
            isset($data['is_featured']) ? (int) $data['is_featured'] : null,
            $productId,
        ]);

        if (! empty($data['image_url'])) {
            $checkImg = $db->prepare('SELECT id FROM product_images WHERE product_id = ? AND is_primary = 1 LIMIT 1');
            $checkImg->execute([$productId]);
            if ($row = $checkImg->fetch()) {
                $updImg = $db->prepare('UPDATE product_images SET image_url = ? WHERE id = ?');
                $updImg->execute([$data['image_url'], $row['id']]);
            } else {
                $insImg = $db->prepare('INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, 1)');
                $insImg->execute([$productId, $data['image_url']]);
            }
        }

        logAdminActivity($admin['id'], $admin['email'], 'UPDATE_PRODUCT', ['product_id' => $productId]);
        if (class_exists('FastrrCatalog')) { FastrrCatalog::pushProduct($db, $productId); }

        jsonResponse(['success' => true, 'message' => 'Product updated successfully']);
    }

    // DELETE /api/products/{id} (ADMIN JWT ENFORCED)
    if ($method === 'DELETE' && preg_match('#^/products/([0-9]+)$#', $path, $matches)) {
        $admin     = AuthMiddleware::requireAdmin();
        $productId = (int) $matches[1];

        $snapshot = false;
        if (class_exists('FastrrCatalog')) {
            $snap = $db->prepare(FastrrCatalog::productSelect() . ' WHERE p.id = ?');
            $snap->execute([$productId]);
            $snapshot = $snap->fetch();
        }

        $stmt = $db->prepare('DELETE FROM products WHERE id = ?');
        $stmt->execute([$productId]);
        if ($snapshot) {
            FastrrCatalog::pushArchivedSnapshot($snapshot);
        }

        logAdminActivity($admin['id'], $admin['email'], 'DELETE_PRODUCT', ['product_id' => $productId]);

        jsonResponse(['success' => true, 'message' => 'Product deleted successfully']);
    }

    // ----------------------------------------------------------------
    // 4.5 Orders API (Shiprocket + Order Emails for Customer & Admin)
    // ----------------------------------------------------------------

    // POST /api/orders (Customer creates order -> Shiprocket shipment -> Notifications)
    if ($method === 'POST' && $path === '/orders') {
        $data     = getJsonInput();
        $authUser = AuthMiddleware::getOptionalUser();

        // Validate basic fields
        $customerName  = trim($data['customer_name'] ?? '');
        $customerEmail = trim($data['customer_email'] ?? '');
        $customerPhone = trim($data['customer_phone'] ?? '');
        $shippingAddr  = $data['shipping_address'] ?? null;
        $items         = $data['items'] ?? [];
        $paymentMethod = $data['payment_method'] ?? 'ONLINE'; // 'ONLINE' or 'COD'

        if (empty($customerName) || empty($customerEmail) || empty($customerPhone) || empty($shippingAddr) || empty($items)) {
            errorResponse('Customer details, shipping address, and order items are required');
        }

        // Calculate totals and verify items from DB
        $subtotal          = 0.0;
        $orderItemsPayload = [];
        $dbItems           = [];

        foreach ($items as $item) {
            $pId = (int) ($item['product_id'] ?? 0);
            $qty = (int) ($item['quantity'] ?? 1);
            if ($pId <= 0 || $qty <= 0) {
                continue;
            }

            $stmt = $db->prepare('SELECT id, name, sku, price, COALESCE(online_stock_quantity, stock_quantity) AS online_stock_quantity, weight_grams FROM products WHERE id = ? AND is_active = 1 LIMIT 1');
            $stmt->execute([$pId]);
            $prod = $stmt->fetch();

            if (! $prod) {
                errorResponse("Product ID {$pId} not found or inactive", 400);
            }

            $linePrice = (float) $prod['price'];
            $lineTotal = $linePrice * $qty;
            $subtotal  += $lineTotal;

            $orderItemsPayload[]  = [
                'product_id'   => $prod['id'],
                'product_name' => $prod['name'],
                'sku'          => $prod['sku'],
                'unit_price'   => $linePrice,
                'quantity'     => $qty,
                'total_price'  => $lineTotal,
                'weight_grams' => (int) $prod['weight_grams'],
            ];
        }

        if (empty($orderItemsPayload)) {
            errorResponse('No valid products in order items', 400);
        }

        // Free shipping if >= threshold (₹999 default)
        $freeThreshold       = (float) ($config['app']['free_shipping_threshold'] ?? 999.00);
        $defaultShippingCost = (float) ($config['app']['default_shipping_cost'] ?? 99.00);
        $shippingCost        = ($subtotal >= $freeThreshold) ? 0.00 : $defaultShippingCost;
        $totalAmount         = $subtotal + $shippingCost;

        // Generate unique order number
        $orderNumber = 'TLGH-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -4));

        $db->beginTransaction();
        try {
            $stmt = $db->prepare('INSERT INTO orders (
                order_number, customer_id, customer_name, customer_email, customer_phone,
                shipping_address, subtotal, shipping_cost, total_amount, payment_status, payment_method, order_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "PENDING")');

            $customerId = ($authUser && $authUser['type'] === 'customer') ? $authUser['id'] : null;
            $stmt->execute([
                $orderNumber,
                $customerId,
                $customerName,
                $customerEmail,
                $customerPhone,
                json_encode($shippingAddr),
                $subtotal,
                $shippingCost,
                $totalAmount,
                'PENDING',
                $paymentMethod,
            ]);
            $orderId = (int) $db->lastInsertId();

            // Insert line items & decrement stock
            $itemStmt  = $db->prepare('INSERT INTO order_items (order_id, product_id, product_name, sku, unit_price, quantity, total_price) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $stockStmt = $db->prepare('UPDATE products SET online_stock_quantity = CASE WHEN online_stock_quantity >= ? THEN online_stock_quantity - ? ELSE 0 END, stock_quantity = CASE WHEN online_stock_quantity >= ? THEN online_stock_quantity - ? ELSE 0 END WHERE id = ?');

            foreach ($orderItemsPayload as $it) {
                $itemStmt->execute([
                    $orderId,
                    $it['product_id'],
                    $it['product_name'],
                    $it['sku'],
                    $it['unit_price'],
                    $it['quantity'],
                    $it['total_price'],
                ]);
                $stockStmt->execute([$it['quantity'], $it['quantity'], $it['quantity'], $it['quantity'], $it['product_id']]);
            }

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            errorResponse('Order creation failed: ' . $e->getMessage(), 500);
        }

        // ------------------------------------------------------------
        // Shiprocket Integration: Push Order to Shiprocket
        // ------------------------------------------------------------
        $orderDataForShiprocket = [
            'order_number'     => $orderNumber,
            'customer_name'    => $customerName,
            'customer_email'   => $customerEmail,
            'customer_phone'   => $customerPhone,
            'shipping_address' => $shippingAddr,
            'subtotal'         => $subtotal,
            'shipping_cost'    => $shippingCost,
            'total_amount'     => $totalAmount,
            'payment_method'   => $paymentMethod,
            'items'            => $orderItemsPayload,
        ];

        $shiprocketResponse = Shiprocket::createOrder($orderDataForShiprocket);
        $srOrderId          = $shiprocketResponse['order_id'] ?? null;
        $srShipmentId       = $shiprocketResponse['shipment_id'] ?? null;
        $srAwb              = $shiprocketResponse['awb_code'] ?? null;
        $courierName        = $shiprocketResponse['courier_name'] ?? null;
        $trackingUrl        = $srAwb ? "https://shiprocket.co/tracking/{$srAwb}" : null;

        // If shipment created, attempt AWB generation if not yet provided
        if ($srShipmentId && ! $srAwb) {
            $awbRes = Shiprocket::generateAWB((int) $srShipmentId);
            if (! empty($awbRes['response']['data']['awb_code'])) {
                $srAwb       = $awbRes['response']['data']['awb_code'];
                $courierName = $awbRes['response']['data']['courier_name'] ?? $courierName;
                $trackingUrl = "https://shiprocket.co/tracking/{$srAwb}";
            }
        }

        // Update order with Shiprocket details
        if ($srOrderId || $srShipmentId || $srAwb) {
            $updateStmt = $db->prepare('UPDATE orders SET shiprocket_order_id = ?, shiprocket_shipment_id = ?, shiprocket_awb = ?, courier_name = ?, tracking_url = ?, shiprocket_status = "CREATED" WHERE id = ?');
            $updateStmt->execute([$srOrderId, $srShipmentId, $srAwb, $courierName, $trackingUrl, $orderId]);
        }

        // ------------------------------------------------------------
        // Email Notifications (Customer Confirmation + Admin Alert)
        // ------------------------------------------------------------
        $orderDataForEmails = [
            'order_number'      => $orderNumber,
            'customer_name'     => $customerName,
            'customer_email'    => $customerEmail,
            'customer_phone'    => $customerPhone,
            'subtotal'          => $subtotal,
            'shipping_cost'     => $shippingCost,
            'total_amount'      => $totalAmount,
            'payment_method'    => $paymentMethod,
            'payment_status'    => 'PENDING',
            'shiprocket_status' => $srShipmentId ? 'Shipment Booked' : 'Processing',
            'tracking_url'      => $trackingUrl,
            'items'             => $orderItemsPayload,
        ];

        // 1. Send receipt to Customer
        Mailer::sendOrderConfirmationCustomer($orderDataForEmails);

        // 2. Send notification to Store Admin
        Mailer::sendNewOrderAdminNotification($orderDataForEmails);

        jsonResponse([
            'success'      => true,
            'message'      => 'Order placed successfully. Confirmation email sent.',
            'order_number' => $orderNumber,
            'order_id'     => $orderId,
            'total_amount' => $totalAmount,
            'shiprocket'   => [
                'order_id'     => $srOrderId,
                'shipment_id'  => $srShipmentId,
                'awb_code'     => $srAwb,
                'courier_name' => $courierName,
                'tracking_url' => $trackingUrl,
            ],
        ], 201);
    }

    // GET /api/orders (ADMIN JWT ENFORCED, or Customer viewing own)
    if ($method === 'GET' && $path === '/orders/track') {
        $number = trim($_GET['order_number'] ?? '');
        $email  = strtolower(trim($_GET['email'] ?? ''));
        if ($number === '' || ! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            errorResponse('Order number and order email are required');
        }

        $stmt = $db->prepare('SELECT order_number, order_status, payment_status, payment_method, shiprocket_status, shiprocket_awb, courier_name, tracking_url, created_at FROM orders WHERE order_number = ? AND LOWER(customer_email) = ? LIMIT 1');
        $stmt->execute([$number, $email]);
        $order = $stmt->fetch();
        if (! $order) {
            errorResponse('No matching order found. Check the order number and email.', 404);
        }

        jsonResponse(['success' => true, 'order' => $order]);
    }

    if ($method === 'GET' && $path === '/orders') {
        $user = AuthMiddleware::getOptionalUser();
        if (! $user) {
            AuthMiddleware::requireAdmin(); // Triggers 401
        }

        if ($user['type'] === 'admin') {
            $stmt   = $db->query('SELECT * FROM orders ORDER BY created_at DESC LIMIT 100');
            $orders = $stmt->fetchAll();
        } else {
            $stmt = $db->prepare('SELECT * FROM orders WHERE customer_id = ? ORDER BY created_at DESC');
            $stmt->execute([$user['id']]);
            $orders = $stmt->fetchAll();
        }

        jsonResponse(['success' => true, 'orders' => $orders]);
    }

    // GET /api/orders/{id}
    if ($method === 'GET' && preg_match('#^/orders/([0-9]+)$#', $path, $matches)) {
        $orderId = (int) $matches[1];
        $admin   = AuthMiddleware::requireAdmin();

        $stmt = $db->prepare('SELECT * FROM orders WHERE id = ? LIMIT 1');
        $stmt->execute([$orderId]);
        $order = $stmt->fetch();

        if (! $order) {
            errorResponse('Order not found', 404);
        }

        $itemsStmt = $db->prepare('SELECT * FROM order_items WHERE order_id = ?');
        $itemsStmt->execute([$orderId]);
        $order['items'] = $itemsStmt->fetchAll();

        jsonResponse(['success' => true, 'order' => $order]);
    }

    // POST /api/admin/orders/{id}/refund (OWNER ONLY)
    // Refund initiation is a provider-side action; never mark a payment
    // refunded locally without an accepted Shiprocket refund request.
    if ($method === 'POST' && preg_match('#^/admin/orders/([0-9]+)/refund$#', $path, $matches)) {
        $admin = AuthMiddleware::requireAdmin('OWNER');
        $orderId = (int) $matches[1];
        $input = getJsonInput();

        $stmt = $db->prepare('SELECT id, order_number, total_amount, payment_status, payment_method, notes FROM orders WHERE id = ? LIMIT 1');
        $stmt->execute([$orderId]);
        $order = $stmt->fetch();
        if (!$order) {
            errorResponse('Order not found', 404);
        }
        if (strtoupper((string) $order['payment_method']) !== 'FASTRR') {
            errorResponse('Only Shiprocket Checkout payments can be refunded from this panel', 409);
        }
        if ($order['payment_status'] !== 'PAID') {
            errorResponse('Only paid orders without a pending refund can be refunded', 409);
        }

        $requestedAmount = (float) ($input['amount'] ?? $order['total_amount']);
        $orderAmount = (float) $order['total_amount'];
        if (!is_finite($requestedAmount) || $requestedAmount <= 0 || abs($requestedAmount - $orderAmount) > 0.01) {
            errorResponse('This panel currently supports full-order refunds only', 422);
        }

        $providerStmt = $db->prepare('SELECT fastrr_order_id FROM fastrr_checkouts WHERE processed_order_id = ? AND fastrr_order_id IS NOT NULL ORDER BY id DESC LIMIT 1');
        $providerStmt->execute([$orderId]);
        $providerOrderId = trim((string) $providerStmt->fetchColumn());
        if ($providerOrderId === '') {
            errorResponse('The Shiprocket order reference is missing for this order', 409);
        }

        // Atomically reserve this full refund so double-clicks or concurrent
        // requests cannot create two provider refund requests.
        $reserve = $db->prepare("UPDATE orders SET payment_status = 'REFUND_PENDING' WHERE id = ? AND payment_status = 'PAID'");
        $reserve->execute([$orderId]);
        if ($reserve->rowCount() !== 1) {
            errorResponse('The order is no longer eligible for a refund. Refresh the order and check its current status.', 409);
        }

        $refund = Fastrr::initiateRefund($providerOrderId, $orderAmount);
        if (empty($refund['success'])) {
            $providerHttpStatus = (int) ($refund['http_status'] ?? 0);
            $providerMessage = (string) ($refund['message'] ?? 'Shiprocket could not initiate the refund');
            $requestMayHaveReachedProvider = $providerHttpStatus >= 500
                || ($providerHttpStatus === 0 && stripos($providerMessage, 'credentials are not configured') === false
                    && stripos($providerMessage, 'Failed to encode') === false);
            if ($requestMayHaveReachedProvider) {
                $uncertainNote = trim((string) $order['notes']);
                $uncertainNote = ($uncertainNote !== '' ? $uncertainNote . "\n" : '') . 'Shiprocket refund status is unconfirmed; reconcile the provider refund report before retrying.';
                $keepPending = $db->prepare("UPDATE orders SET notes = ? WHERE id = ? AND payment_status = 'REFUND_PENDING'");
                $keepPending->execute([$uncertainNote, $orderId]);
                errorResponse('Shiprocket could not confirm whether it accepted the refund. The order remains refund pending; sync refund reports before retrying.', 502);
            }
            $release = $db->prepare("UPDATE orders SET payment_status = 'PAID' WHERE id = ? AND payment_status = 'REFUND_PENDING'");
            $release->execute([$orderId]);
            errorResponse($providerMessage, 502);
        }
        $refundDetails = $refund['data']['data'] ?? [];
        $providerStatus = strtoupper((string) ($refundDetails['status'] ?? $refund['data']['status'] ?? 'INITIATED'));
        $isRefunded = !empty($refundDetails['refunded']) || in_array($providerStatus, ['SUCCESS', 'COMPLETED', 'REFUNDED'], true);
        $paymentStatus = $isRefunded ? 'REFUNDED' : 'REFUND_PENDING';
        $providerRefundId = trim((string) ($refundDetails['id'] ?? $refundDetails['transaction_id'] ?? ''));
        $reason = trim((string) ($input['reason'] ?? ''));
        $reason = mb_substr($reason, 0, 500);
        $note = 'Shiprocket refund ' . $providerStatus . ' for ' . number_format($orderAmount, 2, '.', '')
            . ($providerRefundId !== '' ? ' (ref ' . $providerRefundId . ')' : '')
            . ($reason !== '' ? '. Reason: ' . $reason : '');
        $notes = trim((string) ($order['notes'] ?? ''));
        $notes = $notes === '' ? $note : $notes . "\n" . $note;

        $update = $db->prepare('UPDATE orders SET payment_status = ?, notes = ? WHERE id = ? AND payment_status = \'REFUND_PENDING\'');
        $update->execute([$paymentStatus, $notes, $orderId]);
        if ($update->rowCount() !== 1) {
            errorResponse('The payment status changed while the refund was being initiated. Recheck the order before retrying.', 409);
        }
        logAdminActivity($admin['id'], $admin['email'], 'FASTRR_REFUND_INITIATED', [
            'order_id' => $orderId,
            'amount' => $orderAmount,
            'provider_status' => $providerStatus,
            'provider_refund_id' => $providerRefundId,
        ]);

        jsonResponse([
            'success' => true,
            'payment_status' => $paymentStatus,
            'provider_status' => $providerStatus,
            'message' => $isRefunded ? 'Shiprocket confirmed the refund.' : 'Shiprocket accepted the refund request; confirmation is pending.',
        ], 202);
    }

    // POST /api/admin/fastrr/refunds/sync (OWNER ONLY)
    if ($method === 'POST' && $path === '/admin/fastrr/refunds/sync') {
        $admin = AuthMiddleware::requireAdmin('OWNER');
        $pending = $db->query("SELECT c.fastrr_order_id, o.id AS local_order_id, o.created_at FROM fastrr_checkouts c JOIN orders o ON o.id = c.processed_order_id WHERE o.payment_status = 'REFUND_PENDING' ORDER BY o.created_at ASC")->fetchAll();
        if (!$pending) {
            jsonResponse(['success' => true, 'updated' => 0, 'message' => 'There are no pending Shiprocket refunds to reconcile.']);
        }

        $from = gmdate('Y-m-d', strtotime((string) $pending[0]['created_at']));
        $to = gmdate('Y-m-d');
        $byProviderOrder = [];
        foreach ($pending as $row) {
            $byProviderOrder[(string) $row['fastrr_order_id']] = (int) $row['local_order_id'];
        }

        $updated = 0;
        for ($page = 0; $page < 50; $page++) {
            $report = Fastrr::refundReports($from, $to, $page);
            if (empty($report['success'])) {
                errorResponse($report['message'] ?? 'Shiprocket refund report could not be fetched', 502);
            }
            $entries = $report['data']['refunds'] ?? [];
            if (!is_array($entries) || !$entries) {
                break;
            }
            foreach ($entries as $entry) {
                if (!is_array($entry)) {
                    continue;
                }
                $providerOrderId = (string) ($entry['order_id'] ?? '');
                $providerStatus = strtoupper((string) ($entry['status'] ?? ''));
                $isRefunded = !empty($entry['refunded']) || in_array($providerStatus, ['SUCCESS', 'COMPLETED', 'REFUNDED'], true);
                if (!$isRefunded || !isset($byProviderOrder[$providerOrderId])) {
                    continue;
                }
                $localOrderId = $byProviderOrder[$providerOrderId];
                $update = $db->prepare("UPDATE orders SET payment_status = 'REFUNDED' WHERE id = ? AND payment_status = 'REFUND_PENDING'");
                $update->execute([$localOrderId]);
                $updated += $update->rowCount();
            }
        }
        logAdminActivity($admin['id'], $admin['email'], 'FASTRR_REFUNDS_RECONCILED', ['updated' => $updated]);
        jsonResponse(['success' => true, 'updated' => $updated, 'message' => 'Shiprocket refund statuses have been synchronized.']);
    }

    // PUT /api/orders/{id}/status (ADMIN JWT ENFORCED)
    if ($method === 'PUT' && preg_match('#^/orders/([0-9]+)/status$#', $path, $matches)) {
        $admin   = AuthMiddleware::requireAdmin();
        $orderId = (int) $matches[1];
        $data    = getJsonInput();

        $orderStatus   = $data['order_status'] ?? null;
        $paymentStatus = $data['payment_status'] ?? null;
        $courierName   = $data['courier_name'] ?? null;
        $awb           = $data['shiprocket_awb'] ?? ($data['awb'] ?? null);
        $trackingUrl   = $data['tracking_url'] ?? null;
        $notes         = $data['notes'] ?? null;

        // Fetch current order to compare and notify customer
        $currStmt = $db->prepare('SELECT * FROM orders WHERE id = ? LIMIT 1');
        $currStmt->execute([$orderId]);
        $currOrder = $currStmt->fetch();

        if (! $currOrder) {
            errorResponse('Order not found', 404);
        }

        if ($paymentStatus !== null) {
            $paymentStatus = strtoupper(trim((string) $paymentStatus));
            if (!in_array($paymentStatus, ['PENDING', 'PAID', 'FAILED'], true)) {
                errorResponse('Refund statuses can only be changed by the Shiprocket refund workflow', 422);
            }
            AuthMiddleware::requireAdmin('OWNER');
            if (strtoupper((string) $currOrder['payment_method']) === 'FASTRR'
                && $paymentStatus !== strtoupper((string) $currOrder['payment_status'])) {
                errorResponse('Shiprocket payments must be reconciled with Shiprocket before changing their status', 409);
            }
        }

        $stmt = $db->prepare('UPDATE orders SET
            order_status = COALESCE(?, order_status),
            payment_status = COALESCE(?, payment_status),
            courier_name = COALESCE(?, courier_name),
            shiprocket_awb = COALESCE(?, shiprocket_awb),
            tracking_url = COALESCE(?, tracking_url),
            notes = COALESCE(?, notes)
            WHERE id = ?');
        $stmt->execute([$orderStatus, $paymentStatus, $courierName, $awb, $trackingUrl, $notes, $orderId]);

        // If order status changed, notify customer via email
        if (! empty($orderStatus) && $orderStatus !== $currOrder['order_status'] && ! empty($currOrder['customer_email'])) {
            Mailer::sendOrderStatusUpdateCustomer(
                $currOrder,
                $orderStatus,
                $trackingUrl ?? $currOrder['tracking_url'],
                $courierName ?? $currOrder['courier_name'],
                $awb ?? $currOrder['shiprocket_awb']
            );
        }

        logAdminActivity($admin['id'], $admin['email'], 'UPDATE_ORDER_STATUS', [
            'order_id'       => $orderId,
            'order_status'   => $orderStatus,
            'payment_status' => $paymentStatus,
            'awb'            => $awb,
        ]);

        jsonResponse(['success' => true, 'message' => 'Order updated successfully']);
    }

    // GET /api/orders/{id}/track (Shiprocket Live Tracking)
    if ($method === 'GET' && preg_match('#^/orders/([0-9]+)/track$#', $path, $matches)) {
        $orderId = (int) $matches[1];
        $stmt    = $db->prepare('SELECT shiprocket_shipment_id, shiprocket_awb, tracking_url FROM orders WHERE id = ?');
        $stmt->execute([$orderId]);
        $order = $stmt->fetch();

        if (! $order) {
            errorResponse('Order not found', 404);
        }

        $trackingData = null;
        if (! empty($order['shiprocket_awb'])) {
            $trackingData = Shiprocket::trackAWB($order['shiprocket_awb']);
        } elseif (! empty($order['shiprocket_shipment_id'])) {
            $trackingData = Shiprocket::trackShipment((int) $order['shiprocket_shipment_id']);
        }

        jsonResponse([
            'success'      => true,
            'awb_code'     => $order['shiprocket_awb'],
            'tracking_url' => $order['tracking_url'],
            'tracking'     => $trackingData,
        ]);
    }

    // ----------------------------------------------------------------
    // 4.6 Staff & Admin Operations (OWNER JWT ENFORCED + EMAIL ALERTS)
    // ----------------------------------------------------------------

    // GET /api/admin/staff (OWNER ONLY)
    if ($method === 'GET' && $path === '/admin/staff') {
        AuthMiddleware::requireAdmin('OWNER');
        $stmt = $db->query('SELECT id, full_name, email, role, is_active, created_at FROM admins ORDER BY id ASC');
        jsonResponse(['success' => true, 'staff' => $stmt->fetchAll()]);
    }

    // POST /api/admin/staff (OWNER ONLY + EMAIL ALERT)
    if ($method === 'POST' && $path === '/admin/staff') {
        $owner = AuthMiddleware::requireAdmin('OWNER');
        $data  = getJsonInput();

        $name     = trim($data['full_name'] ?? '');
        $email    = trim($data['email'] ?? '');
        $password = $data['password'] ?? '';
        $role     = in_array($data['role'] ?? '', ['OWNER', 'STAFF']) ? $data['role'] : 'STAFF';

        if (empty($name) || empty($email) || empty($password)) {
            errorResponse('Full name, email, and temporary password are required');
        }

        $stmt = $db->prepare('SELECT id FROM admins WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            errorResponse('An admin with this email already exists', 409);
        }

        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $db->prepare('INSERT INTO admins (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)');
        $stmt->execute([$name, $email, $hash, $role]);
        $staffId = (int) $db->lastInsertId();

        // Security Notification to Owner
        Mailer::sendAdminOperationAlert($owner['email'], 'New Staff Member Created', [
            'staff_name'    => $name,
            'staff_email'   => $email,
            'assigned_role' => $role,
            'created_by'    => $owner['email'],
        ]);

        logAdminActivity($owner['id'], $owner['email'], 'CREATE_STAFF', ['staff_id' => $staffId, 'email' => $email]);

        jsonResponse([
            'success'  => true,
            'message'  => 'Staff member created successfully. Security alert dispatched.',
            'staff_id' => $staffId,
        ], 201);
    }

    // PUT /api/admin/staff/{id} (OWNER ONLY + EMAIL ALERT)
    if ($method === 'PUT' && preg_match('#^/admin/staff/([0-9]+)$#', $path, $matches)) {
        $owner   = AuthMiddleware::requireAdmin('OWNER');
        $staffId = (int) $matches[1];
        $data    = getJsonInput();

        $stmt = $db->prepare('SELECT full_name, email, role, is_active FROM admins WHERE id = ?');
        $stmt->execute([$staffId]);
        $target = $stmt->fetch();

        if (! $target) {
            errorResponse('Staff member not found', 404);
        }

        $role     = $data['role'] ?? $target['role'];
        $isActive = isset($data['is_active']) ? (int) $data['is_active'] : (int) $target['is_active'];

        $stmt = $db->prepare('UPDATE admins SET role = ?, is_active = ? WHERE id = ?');
        $stmt->execute([$role, $isActive, $staffId]);

        // Security Notification to Owner
        Mailer::sendAdminOperationAlert($owner['email'], 'Staff Member Permissions Modified', [
            'staff_id'    => $staffId,
            'staff_email' => $target['email'],
            'new_role'    => $role,
            'is_active'   => $isActive ? 'Active' : 'Suspended',
            'updated_by'  => $owner['email'],
        ]);

        logAdminActivity($owner['id'], $owner['email'], 'UPDATE_STAFF', ['staff_id' => $staffId, 'role' => $role]);

        jsonResponse(['success' => true, 'message' => 'Staff member updated successfully.']);
    }

    // DELETE /api/admin/staff/{id} (OWNER ONLY + EMAIL ALERT)
    if ($method === 'DELETE' && preg_match('#^/admin/staff/([0-9]+)$#', $path, $matches)) {
        $owner   = AuthMiddleware::requireAdmin('OWNER');
        $staffId = (int) $matches[1];

        if ($staffId === $owner['id']) {
            errorResponse('Cannot delete your own owner account', 400);
        }

        $stmt = $db->prepare('SELECT full_name, email FROM admins WHERE id = ?');
        $stmt->execute([$staffId]);
        $target = $stmt->fetch();

        if (! $target) {
            errorResponse('Staff member not found', 404);
        }

        $stmt = $db->prepare('DELETE FROM admins WHERE id = ?');
        $stmt->execute([$staffId]);

        // Security Notification to Owner
        Mailer::sendAdminOperationAlert($owner['email'], 'Staff Member Removed', [
            'staff_id'    => $staffId,
            'staff_email' => $target['email'],
            'deleted_by'  => $owner['email'],
        ]);

        logAdminActivity($owner['id'], $owner['email'], 'DELETE_STAFF', ['staff_id' => $staffId, 'email' => $target['email']]);

        jsonResponse(['success' => true, 'message' => 'Staff member removed successfully.']);
    }

    // ----------------------------------------------------------------
    // 4.7 Admin Dashboard Statistics
    // ----------------------------------------------------------------

    // GET /api/admin/dashboard (ADMIN JWT ENFORCED)
    if ($method === 'GET' && $path === '/admin/dashboard') {
        $admin = AuthMiddleware::requireAdmin();

        $revenue       = (float) $db->query("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE payment_status = 'PAID'")->fetchColumn();
        $totalOrders   = (int) $db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
        $pendingOrders = (int) $db->query("SELECT COUNT(*) FROM orders WHERE order_status = 'PENDING'")->fetchColumn();
        $lowStockCount = (int) $db->query("SELECT COUNT(*) FROM products WHERE stock_quantity <= 5 AND is_active = 1")->fetchColumn();

        // Recent orders
        $recentOrders = $db->query("SELECT id, order_number, customer_name, total_amount, payment_status, order_status, created_at FROM orders ORDER BY created_at DESC LIMIT 5")->fetchAll();

        // Recent admin activity logs
        $recentLogs = $db->query("SELECT id, admin_email, action, ip_address, created_at FROM admin_activity_logs ORDER BY created_at DESC LIMIT 8")->fetchAll();

        jsonResponse([
            'success'       => true,
            'metrics'       => [
                'total_revenue'  => $revenue,
                'total_orders'   => $totalOrders,
                'pending_orders' => $pendingOrders,
                'low_stock'      => $lowStockCount,
            ],
            'recent_orders' => $recentOrders,
            'activity_logs' => $recentLogs,
        ]);
    }

    // ----------------------------------------------------------------
    // 4.8 Cart API
    // ----------------------------------------------------------------

    // GET /api/cart
    if ($method === 'GET' && $path === '/cart') {
        $user      = AuthMiddleware::getOptionalUser();
        $sessionId = $_GET['session_id'] ?? null;

        if (! $user && ! $sessionId) {
            jsonResponse(['success' => true, 'items' => []]);
        }

        if ($user && $user['type'] === 'customer') {
            $stmt = $db->prepare('SELECT c.id as cart_item_id, c.quantity, p.*,
                (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as image_url
                FROM cart_items c
                JOIN products p ON c.product_id = p.id
                WHERE c.customer_id = ?');
            $stmt->execute([$user['id']]);
        } else {
            $stmt = $db->prepare('SELECT c.id as cart_item_id, c.quantity, p.*,
                (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as image_url
                FROM cart_items c
                JOIN products p ON c.product_id = p.id
                WHERE c.session_id = ?');
            $stmt->execute([$sessionId]);
        }

        jsonResponse(['success' => true, 'items' => $stmt->fetchAll()]);
    }

    // POST /api/cart
    if ($method === 'POST' && $path === '/cart') {
        $data      = getJsonInput();
        $productId = (int) ($data['product_id'] ?? 0);
        $qty       = max(1, (int) ($data['quantity'] ?? 1));
        $user      = AuthMiddleware::getOptionalUser();
        $sessionId = $data['session_id'] ?? null;

        if ($productId <= 0) {
            errorResponse('Valid product_id required');
        }

        $customerId = ($user && $user['type'] === 'customer') ? $user['id'] : null;

        if ($customerId) {
            $stmt = $db->prepare('SELECT id, quantity FROM cart_items WHERE customer_id = ? AND product_id = ?');
            $stmt->execute([$customerId, $productId]);
            $existing = $stmt->fetch();
            if ($existing) {
                $stmt = $db->prepare('UPDATE cart_items SET quantity = quantity + ? WHERE id = ?');
                $stmt->execute([$qty, $existing['id']]);
            } else {
                $stmt = $db->prepare('INSERT INTO cart_items (customer_id, product_id, quantity) VALUES (?, ?, ?)');
                $stmt->execute([$customerId, $productId, $qty]);
            }
        } else {
            $stmt = $db->prepare('SELECT id, quantity FROM cart_items WHERE session_id = ? AND product_id = ?');
            $stmt->execute([$sessionId, $productId]);
            $existing = $stmt->fetch();
            if ($existing) {
                $stmt = $db->prepare('UPDATE cart_items SET quantity = quantity + ? WHERE id = ?');
                $stmt->execute([$qty, $existing['id']]);
            } else {
                $stmt = $db->prepare('INSERT INTO cart_items (session_id, product_id, quantity) VALUES (?, ?, ?)');
                $stmt->execute([$sessionId, $productId, $qty]);
            }
        }

        jsonResponse(['success' => true, 'message' => 'Product added to cart']);
    }

    // ----------------------------------------------------------------
    // 4.9 Reviews & Newsletter
    // ----------------------------------------------------------------

    // POST /api/reviews
    if ($method === 'POST' && $path === '/reviews') {
        $data      = getJsonInput();
        $productId = (int) ($data['product_id'] ?? 0);
        $name      = trim($data['reviewer_name'] ?? '');
        $email     = trim($data['reviewer_email'] ?? '');
        $rating    = (int) ($data['rating'] ?? 5);
        $title     = trim($data['title'] ?? '');
        $comment   = trim($data['comment'] ?? '');

        if ($productId <= 0 || empty($name) || empty($email) || empty($comment)) {
            errorResponse('Product ID, name, email, and review comment are required');
        }

        $user       = AuthMiddleware::getOptionalUser();
        $customerId = ($user && $user['type'] === 'customer') ? $user['id'] : null;

        $stmt = $db->prepare('INSERT INTO reviews (product_id, customer_id, reviewer_name, reviewer_email, rating, title, comment, is_approved) VALUES (?, ?, ?, ?, ?, ?, ?, 1)');
        $stmt->execute([$productId, $customerId, $name, $email, min(5, max(1, $rating)), $title ?: null, $comment]);

        jsonResponse(['success' => true, 'message' => 'Review submitted successfully', 'review_id' => (int) $db->lastInsertId()], 201);
    }

    // POST /api/newsletter (Subscribe & Send Welcome Email)
    if ($method === 'POST' && $path === '/newsletter') {
        $data  = getJsonInput();
        $email = strtolower(trim($data['email'] ?? ''));

        if (empty($email) || ! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            errorResponse('A valid email address is required');
        }

        $stmt = $db->prepare('SELECT id, is_active FROM newsletter_subscribers WHERE email = ?');
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        $isNew = false;

        if ($row) {
            $upd = $db->prepare('UPDATE newsletter_subscribers SET is_active = 1, unsubscribed_at = NULL WHERE id = ?');
            $upd->execute([$row['id']]);
            if (! (bool) $row['is_active']) {
                $isNew = true;
            }
        } else {
            $ins = $db->prepare('INSERT INTO newsletter_subscribers (email) VALUES (?)');
            $ins->execute([$email]);
            $isNew = true;
        }

        // Send transactional welcome note if new or reactivated
        if ($isNew) {
            try {
                Mailer::sendNewsletterWelcome($email);
            } catch (Throwable $e) {
                error_log("Newsletter welcome email failed: " . $e->getMessage());
            }
        }

        jsonResponse([
            'success' => true,
            'message' => 'Thank you for joining our newsletter list! A welcome note has been sent to your email.'
        ]);
    }

    // GET & POST /api/newsletter/unsubscribe
    if (($method === 'GET' || $method === 'POST') && $path === '/newsletter/unsubscribe') {
        $email = strtolower(trim($_GET['email'] ?? getJsonInput()['email'] ?? ''));

        if (! empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $upd = $db->prepare("UPDATE newsletter_subscribers SET is_active = 0, unsubscribed_at = CURRENT_TIMESTAMP WHERE email = ?");
            $upd->execute([$email]);
        }

        if ($method === 'GET') {
            header('Content-Type: text/html; charset=UTF-8');
            echo "<!doctype html><html><head><meta charset='utf-8'><title>Unsubscribed | The Little Green House</title><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{font-family:sans-serif;background:#fbf7f1;color:#4a1b0c;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px;box-sizing:border-box}.card{background:#fff;border:1px solid #e3d3bd;border-radius:16px;padding:36px;max-width:480px;text-align:center;box-shadow:0 4px 20px rgba(74,27,12,0.06)}h2{color:#7a4632;margin-top:0}p{line-height:1.6;color:#6b5847}a{display:inline-block;margin-top:16px;color:#c3804c;text-decoration:none;font-weight:bold}</style></head><body><div class='card'><h2>You have been unsubscribed</h2><p>You will no longer receive studio emails and newsletter drops from The Little Green House.</p><a href='../../'>&larr; Return to The Little Green House</a></div></body></html>";
            exit;
        }

        jsonResponse(['success' => true, 'message' => 'You have been unsubscribed successfully.']);
    }

    // GET /api/admin/subscribers (ADMIN JWT ENFORCED)
    if ($method === 'GET' && $path === '/admin/subscribers') {
        AuthMiddleware::requireAdmin();
        $stmt = $db->query('SELECT id, email, is_active, created_at, unsubscribed_at FROM newsletter_subscribers ORDER BY created_at DESC');
        $subscribers = $stmt->fetchAll();
        jsonResponse(['success' => true, 'count' => count($subscribers), 'subscribers' => $subscribers]);
    }

    // ----------------------------------------------------------------
    // 4.10 Shiprocket Utilities
    // ----------------------------------------------------------------

    // GET /api/shiprocket/serviceability
    if ($method === 'GET' && $path === '/shiprocket/serviceability') {
        $pincode = trim($_GET['pincode'] ?? '');
        $weight  = (float) ($_GET['weight'] ?? 0.5);
        $cod     = ! empty($_GET['cod']);

        if (empty($pincode)) {
            errorResponse('Pincode is required');
        }

        $res = Shiprocket::checkServiceability($pincode, $weight, $cod);
        jsonResponse($res);
    }

    // POST /api/shiprocket/webhook (Inbound Shiprocket tracking & payment updates)
    if ($method === 'POST' && $path === '/shiprocket/webhook') {
        $webhookSecret = (string) ($config['shiprocket']['webhook_secret'] ?? '');
        $providedSecret = (string) ($_SERVER['HTTP_X_SHIPROCKET_WEBHOOK_SECRET'] ?? '');
        if ($webhookSecret === '' || $providedSecret === '' || !hash_equals($webhookSecret, $providedSecret)) {
            errorResponse('Webhook authentication failed', 401);
        }
        $payload       = getJsonInput();
        $currentAwb    = $payload['awb'] ?? null;
        $currentStatus = $payload['current_status'] ?? null;

        if ($currentAwb && $currentStatus) {
            $stmt = $db->prepare('UPDATE orders SET shiprocket_status = ? WHERE shiprocket_awb = ?');
            $stmt->execute([$currentStatus, $currentAwb]);
        }

        jsonResponse(['success' => true, 'message' => 'Webhook received']);
    }

    // 404 Fallback
    errorResponse("Endpoint not found: [{$method}] {$path}", 404);

} catch (Throwable $e) {
    error_log("Unhandled API Exception: " . $e->getMessage());
    if ($e instanceof PDOException || $e->getPrevious() instanceof PDOException) {
        errorResponse('Database unavailable. Check the configured MySQL connection and server reachability.', 503);
    }
    $message = (($config['app']['env'] ?? 'production') === 'development')
        ? 'Internal server error: ' . $e->getMessage()
        : 'Internal server error. Please check the server error log.';
    errorResponse($message, 500);
}
