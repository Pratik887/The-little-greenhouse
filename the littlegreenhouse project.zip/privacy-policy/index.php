<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — privacy policy</title>
  <meta name="description"
    content="learn how the little green house collects, uses, and protects your personal information." />
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🔒</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1180px;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
      letter-spacing: 0.01em;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    ul {
      list-style: none;
    }

    img {
      display: block;
      max-width: 100%;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 9999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    .reveal {
      opacity: 0;
      transform: translateY(24px);
      transition:
        opacity 0.8s var(--ease-hand),
        transform 0.8s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 14px 26px;
      border-radius: 100px;
      font-size: 0.9rem;
      font-weight: 500;
      letter-spacing: 0.02em;
      white-space: nowrap;
      transition: all 0.3s var(--ease-hand);
      min-height: 44px;
      touch-action: manipulation;
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      background: var(--c-900);
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
    }

    .btn-outline {
      border: 1.5px solid var(--c-700);
      color: var(--ink);
      background: transparent;
    }

    .btn-outline:hover {
      background: var(--c-800);
      color: var(--c-50);
      border-color: var(--c-800);
      transform: translateY(-3px);
    }

    /* header */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 600;
      background: rgba(251, 247, 241, 0.86);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 80px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.35rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
      transition: color 0.3s;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active {
      color: var(--ink);
    }

    .main-nav a.is-active::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s,
        color 0.3s;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .profile-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: var(--c-600);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition: 0.3s;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* privacy hero */
    .privacy-hero {
      padding: 60px 0 30px;
      text-align: center;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .privacy-hero h1 {
      font-size: clamp(2rem, 4vw, 3rem);
      line-height: 1.1;
      margin-bottom: 10px;
    }

    .privacy-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .privacy-hero p {
      color: var(--muted);
      font-size: 1.1rem;
      max-width: 600px;
      margin: 0 auto;
    }

    .last-updated {
      display: inline-block;
      margin-top: 16px;
      font-size: 0.85rem;
      color: var(--c-600);
      background: var(--c-100);
      padding: 6px 16px;
      border-radius: 30px;
    }

    /* privacy main */
    .privacy-main {
      padding: 50px 0 80px;
    }

    .privacy-content {
      max-width: 800px;
      margin: 0 auto;
    }

    .privacy-section {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      padding: 28px;
      margin-bottom: 24px;
    }

    .privacy-section h2 {
      font-size: 1.4rem;
      margin-bottom: 16px;
      font-family: var(--font-display);
    }

    .privacy-section h3 {
      font-size: 1.1rem;
      margin: 20px 0 10px;
    }

    .privacy-section p {
      color: var(--muted);
      font-size: 0.95rem;
      line-height: 1.7;
      margin-bottom: 12px;
    }

    .privacy-section ul {
      margin-bottom: 12px;
      padding-left: 20px;
    }

    .privacy-section ul li {
      color: var(--muted);
      font-size: 0.95rem;
      line-height: 1.7;
      margin-bottom: 8px;
      list-style: disc;
    }

    .privacy-section .highlight {
      background: var(--surface-2);
      border-left: 3px solid var(--c-600);
      padding: 16px 20px;
      border-radius: var(--radius-sm);
      margin: 16px 0;
    }

    .privacy-section .highlight p {
      color: var(--ink-soft);
      margin-bottom: 0;
    }

    /* table */
    .data-table {
      width: 100%;
      border-collapse: collapse;
      margin: 16px 0;
    }

    .data-table th {
      text-align: left;
      padding: 12px 16px;
      font-size: 0.85rem;
      font-weight: 500;
      color: var(--muted);
      border-bottom: 2px solid var(--line);
    }

    .data-table td {
      padding: 12px 16px;
      font-size: 0.9rem;
      border-bottom: 1px solid var(--line);
      color: var(--muted);
    }

    /* contact section */
    .contact-privacy {
      text-align: center;
      padding: 40px 20px;
      background: var(--surface-2);
      border-radius: var(--radius-lg);
      margin-top: 40px;
    }

    .contact-privacy h3 {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }

    .contact-privacy p {
      color: var(--muted);
      margin-bottom: 20px;
    }

    .contact-actions {
      display: flex;
      gap: 12px;
      justify-content: center;
      flex-wrap: wrap;
    }

    /* footer */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 70px 0 0;
      margin-top: 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.8fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 50px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand p {
      margin: 14px 0 20px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 12px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      transition: 0.3s;
    }

    .socials a:hover {
      background: var(--c-600);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 16px;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.2s;
    }

    .footer-col a:hover {
      color: white;
    }

    .footer-bottom {
      padding: 24px 0;
      text-align: center;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
    }

    /* responsive */
    @media (max-width: 1024px) {
      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 16px;
      }

      .header-inner {
        height: 64px;
      }

      .logo-text {
        font-size: 1.1rem;
      }

      .main-nav {
        position: fixed;
        top: 64px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 16px 28px 28px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition: 0.4s var(--ease-hand);
        z-index: 500;
        max-height: calc(100vh - 64px);
        overflow-y: auto;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 16px 0;
        border-bottom: 1px solid var(--line);
        font-size: 1rem;
      }

      .menu-toggle {
        display: flex;
      }

      .profile-avatar {
        width: 32px;
        height: 32px;
        font-size: 0.8rem;
      }

      .privacy-hero {
        padding: 40px 0 20px;
      }

      .privacy-hero h1 {
        font-size: 1.8rem;
      }

      .privacy-hero p {
        font-size: 1rem;
      }

      .privacy-main {
        padding: 30px 0 60px;
      }

      .privacy-section {
        padding: 20px 16px;
      }

      .privacy-section h2 {
        font-size: 1.2rem;
      }

      .privacy-section h3 {
        font-size: 1rem;
      }

      .data-table {
        display: block;
        overflow-x: auto;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 30px;
        padding-bottom: 30px;
      }

      .site-footer {
        padding: 50px 0 0;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <link rel="canonical" href="https://thelittlegreenhouse.in/privacy-policy/" />
  <meta property="og:title" content="the little green house — privacy policy" />
  <meta property="og:description" content="learn how the little green house collects, uses, and protects your personal information." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/privacy-policy/" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
  <a class="skip-link" href="#main">skip to privacy policy</a>
  <div class="grain" aria-hidden="true"></div>

  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo" aria-label="the little green house home">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="30" height="30">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products"><svg width="19" height="19" viewBox="0 0 24 24"
            fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg></a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="menu" aria-expanded="false" aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <section class="privacy-hero">
      <div class="wrap">
        <h1>privacy <em>policy</em></h1>
        <p>
          your trust matters to us. here's how we collect, use, and protect
          your information.
        </p>
        <span class="last-updated">last updated: january 15, 2026</span>
      </div>
    </section>

    <section class="privacy-main">
      <div class="wrap">
        <div class="privacy-content">
          <!-- introduction -->
          <div class="privacy-section">
            <h2>introduction</h2>
            <p>
              at the little green house, we respect your privacy and are committed to
              protecting your personal information. this policy explains what
              data we collect, how we use it, and the choices you have
              regarding your information.
            </p>
            <p>
              by using our website and services, you agree to the practices
              described in this policy.
            </p>
          </div>

          <!-- information we collect -->
          <div class="privacy-section">
            <h2>information we collect</h2>
            <p>we collect information you provide directly to us when you:</p>
            <ul>
              <li>create an account or make a purchase</li>
              <li>subscribe to our newsletter</li>
              <li>contact us for support</li>
              <li>participate in surveys or promotions</li>
              <li>book a studio visit</li>
            </ul>

            <h3>types of data collected</h3>
            <table class="data-table">
              <thead>
                <tr>
                  <th>category</th>
                  <th>examples</th>
                  <th>purpose</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>contact info</td>
                  <td>name, email, phone</td>
                  <td>order processing, support</td>
                </tr>
                <tr>
                  <td>shipping info</td>
                  <td>address, pincode</td>
                  <td>delivery of products</td>
                </tr>
                <tr>
                  <td>payment info</td>
                  <td>payment method (not stored)</td>
                  <td>processing transactions</td>
                </tr>
                <tr>
                  <td>usage data</td>
                  <td>browsing behavior, preferences</td>
                  <td>improving our services</td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- how we use info -->
          <div class="privacy-section">
            <h2>how we use your information</h2>
            <ul>
              <li>process and fulfill your orders</li>
              <li>send order confirmations and shipping updates</li>
              <li>respond to your questions and requests</li>
              <li>send newsletters and promotional emails (if opted in)</li>
              <li>improve our products and website experience</li>
              <li>comply with legal obligations</li>
            </ul>

            <div class="highlight">
              <p>
                <strong>we never sell your personal information.</strong> your
                data is used solely to provide you with our products and
                services.
              </p>
            </div>
          </div>

          <!-- data protection -->
          <div class="privacy-section">
            <h2>data protection</h2>
            <p>
              we implement appropriate technical and organizational measures
              to protect your personal information against unauthorized
              access, alteration, disclosure, or destruction.
            </p>
            <ul>
              <li>ssl encryption for all transactions</li>
              <li>
                secure payment gateways (we never store full card details)
              </li>
              <li>restricted access to personal data</li>
              <li>regular security reviews</li>
            </ul>
          </div>

          <!-- cookies -->
          <div class="privacy-section">
            <h2>cookies & tracking</h2>
            <p>
              we use cookies and similar technologies to enhance your browsing
              experience, analyze site traffic, and understand where our
              visitors come from.
            </p>

            <h3>types of cookies we use</h3>
            <ul>
              <li>
                <strong>essential cookies:</strong> required for basic site
                functionality
              </li>
              <li>
                <strong>analytics cookies:</strong> help us understand how
                visitors use our site
              </li>
              <li>
                <strong>preference cookies:</strong> remember your settings
                and preferences
              </li>
            </ul>

            <p>
              you can control cookies through your browser settings. disabling
              cookies may affect site functionality.
            </p>
          </div>

          <!-- third-party -->
          <div class="privacy-section">
            <h2>third-party services</h2>
            <p>
              we use trusted third-party services to operate our business:
            </p>
            <ul>
              <li>
                <strong>payment processors:</strong> to securely handle
                transactions
              </li>
              <li>
                <strong>shipping carriers:</strong> to deliver your orders
              </li>
              <li><strong>email services:</strong> to send communications</li>
              <li><strong>analytics:</strong> to understand site usage</li>
            </ul>
            <p>
              these services have their own privacy policies and only receive
              the information necessary to perform their functions.
            </p>
          </div>

          <!-- your rights -->
          <div class="privacy-section">
            <h2>your rights</h2>
            <p>you have the right to:</p>
            <ul>
              <li>access the personal information we hold about you</li>
              <li>request correction of inaccurate data</li>
              <li>request deletion of your data</li>
              <li>opt out of marketing communications</li>
              <li>withdraw consent at any time</li>
            </ul>
            <p>
              to exercise any of these rights, contact us at
              <strong>privacy@thelittlegreenhouse.com</strong>.
            </p>
          </div>

          <!-- children's privacy -->
          <div class="privacy-section">
            <h2>children's privacy</h2>
            <p>
              our services are not intended for children under 13. we do not
              knowingly collect personal information from children under 13.
              if you believe a child has provided us with personal
              information, please contact us and we will delete it.
            </p>
          </div>

          <!-- changes -->
          <div class="privacy-section">
            <h2>changes to this policy</h2>
            <p>
              we may update this privacy policy from time to time. we will
              notify you of any significant changes by posting the new policy
              on this page and updating the "last updated" date.
            </p>
            <p>we encourage you to review this policy periodically.</p>
          </div>

          <!-- contact -->
          <div class="contact-privacy">
            <h3>questions about privacy?</h3>
            <p>we're here to help with any privacy-related concerns.</p>
            <div class="contact-actions">
              <a href="mailto:privacy@thelittlegreenhouse.com" class="btn btn-primary">email us</a>
              <a href="#contact" class="btn btn-outline">contact page</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>handmade pots, candles & home décor — made slowly, on purpose.</p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    (function () {
      // menu toggle
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) =>
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }),
        );
      }

      // close mobile nav on outside click
      document.addEventListener("click", (e) => {
        if (mainNav && mainNav.classList.contains("is-open")) {
          if (
            !e.target.closest(".main-nav") &&
            !e.target.closest(".menu-toggle")
          ) {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }
        }
      });

      // header shadow
      const header = document.querySelector(".site-header");
      window.addEventListener(
        "scroll",
        () => {
          header.style.boxShadow =
            window.scrollY > 20
              ? "0 8px 24px -18px rgba(53,29,21,0.35)"
              : "none";
        },
        { passive: true },
      );

      // scroll reveal
      const revealObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              revealObserver.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.1 },
      );

      document
        .querySelectorAll(".reveal")
        .forEach((el) => revealObserver.observe(el));
    })();
  </script>
</body>

</html>