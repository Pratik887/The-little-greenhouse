<?php
require_once __DIR__ . '/../api/utils/SiteMedia.php';
$aboutHeroPhoto = SiteMedia::get('about_hero');
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — our story</title>
  <meta name="description"
    content="the story behind the little green house — a small studio making handcrafted pots, candles, plants and earthy home décor, one piece at a time." />
  <link rel="canonical" href="https://thelittlegreenhouse.in/ourstory/" />
  <meta property="og:title" content="the little green house — our story" />
  <meta property="og:description" content="the story behind our small studio and the pieces we make by hand." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/ourstory/" />
  <?php if ($aboutHeroPhoto): ?><meta property="og:image" content="<?= htmlspecialchars(SiteMedia::absolute($aboutHeroPhoto), ENT_QUOTES, 'UTF-8') ?>" /><?php endif; ?>
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🏺</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    /* ============================================================
       the little green house — story page styles (inherits main theme)
       ============================================================ */
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --accent-2: var(--c-500);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1180px;
    }

    *,
    *::before,
    *::after {
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      margin: 0;
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
    }

    img,
    svg {
      display: block;
      max-width: 100%;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    ul {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    h1,
    h2,
    h3,
    h4 {
      font-family: var(--font-display);
      font-weight: 500;
      margin: 0;
      text-transform: lowercase;
    }

    p {
      margin: 0;
    }

    input {
      font-family: inherit;
      text-transform: none;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    /* grain overlay */
    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    /* reveal */
    .reveal {
      opacity: 0;
      transform: translateY(22px);
      transition:
        opacity 0.9s var(--ease-hand),
        transform 0.9s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      html {
        scroll-behavior: auto;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 15px 28px;
      border-radius: 100px;
      font-size: 0.95rem;
      letter-spacing: 0.02em;
      transition:
        transform 0.35s var(--ease-hand),
        box-shadow 0.35s var(--ease-hand),
        background 0.35s ease,
        color 0.35s ease;
      white-space: nowrap;
    }

    .btn svg {
      transition: transform 0.35s var(--ease-hand);
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
      background: var(--c-900);
    }

    .btn-primary:hover svg {
      transform: translateX(4px);
    }

    .btn-ghost {
      background: transparent;
      border: 1.5px solid var(--c-800);
      color: var(--ink);
    }

    .btn-ghost:hover {
      background: var(--c-800);
      color: var(--c-50);
      transform: translateY(-3px);
    }

    .eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 9px;
      font-family: var(--font-body);
      font-size: 0.82rem;
      letter-spacing: 0.14em;
      color: var(--c-700);
      margin-bottom: 14px;
    }

    .eyebrow-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-600);
      box-shadow: 0 0 0 4px var(--c-200);
    }

    /* header */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 500;
      background: rgba(251, 247, 241, 0.82);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 82px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.3rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active-link {
      color: var(--ink);
    }

    .main-nav a.is-active-link::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s ease,
        color 0.3s ease;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition:
        transform 0.3s var(--ease-hand),
        opacity 0.3s ease;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* ===== story hero (page specific) ===== */
    .story-hero {
      padding: 70px 0 40px;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .story-hero-inner {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .story-hero h1 {
      font-size: clamp(2.6rem, 5.5vw, 4.4rem);
      line-height: 1.08;
      letter-spacing: -0.01em;
      max-width: 800px;
      margin-bottom: 20px;
    }

    .story-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .story-hero p {
      font-size: 1.15rem;
      color: var(--muted);
      max-width: 640px;
      margin-bottom: 28px;
    }

    /* ===== story full content ===== */
    .story-main {
      padding: 80px 0 100px;
    }

    .story-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 60px 70px;
      align-items: start;
    }

    .story-block h2 {
      font-size: 1.8rem;
      margin-bottom: 16px;
      line-height: 1.2;
    }

    .story-block h2 em {
      color: var(--c-600);
      font-style: italic;
    }

    .story-block p {
      color: var(--muted);
      font-size: 1.05rem;
      margin-bottom: 18px;
      max-width: 520px;
    }

    .story-block p:last-of-type {
      margin-bottom: 0;
    }

    .story-visual-block {
      border-radius: var(--radius-lg);
      overflow: hidden;
      box-shadow: var(--shadow-lift);
      background: var(--c-100);
      transform: rotate(-1.2deg);
      transition: transform 0.6s var(--ease-hand);
    }

    .story-visual-block:hover {
      transform: rotate(0deg);
    }

    .story-visual-block svg {
      width: 100%;
      height: auto;
      display: block;
    }

    .story-highlight {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      padding: 32px 34px;
      margin-top: 28px;
      display: flex;
      flex-wrap: wrap;
      gap: 20px 40px;
      align-items: center;
    }

    .story-highlight .hl-item {
      display: flex;
      flex-direction: column;
    }

    .story-highlight .hl-num {
      font-family: var(--font-display);
      font-size: 2rem;
      color: var(--c-600);
      line-height: 1;
    }

    .story-highlight .hl-label {
      font-size: 0.85rem;
      color: var(--muted);
      letter-spacing: 0.02em;
    }

    /* ===== footer ===== */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 80px 0 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.6fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 60px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand .logo-text em {
      color: var(--c-400);
    }

    .footer-brand p {
      margin: 16px 0 22px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 10px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      color: var(--c-200);
      transition:
        background 0.3s ease,
        transform 0.3s var(--ease-hand);
    }

    .socials a:hover {
      background: var(--c-600);
      transform: translateY(-3px);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 18px;
    }

    .footer-col {
      display: flex;
      flex-direction: column;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.3s ease;
    }

    .footer-col a:hover {
      color: var(--c-100);
    }

    .footer-bottom {
      padding: 26px 0;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
      text-align: center;
    }

    /* ===== responsive ===== */
    @media (max-width: 1024px) {
      .story-grid {
        grid-template-columns: 1fr;
        gap: 50px;
      }

      .story-visual-block {
        max-width: 520px;
        margin: 0 auto;
      }

      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 20px;
      }

      .main-nav {
        position: fixed;
        top: 82px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 20px 28px 30px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition:
          transform 0.45s var(--ease-hand),
          opacity 0.4s ease;
        z-index: 400;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 14px 0;
        border-bottom: 1px solid var(--line);
      }

      .menu-toggle {
        display: flex;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 34px;
      }

      .story-highlight {
        flex-direction: column;
        align-items: flex-start;
        gap: 14px;
      }

      .story-hero h1 {
        font-size: 2.2rem;
      }

      .story-main {
        padding: 40px 0 60px;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <link rel="canonical" href="https://thelittlegreenhouse.in/ourstory/" />
  <meta property="og:title" content="the little green house — our story" />
  <meta property="og:description" content="the story behind the little green house — a small studio making handcrafted pots, candles, plants and earthy home d&#233;cor, one piece at a time." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/ourstory/" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
  <a class="skip-link" href="#main">skip to content</a>
  <div class="grain" aria-hidden="true"></div>

  <!-- ===== header ===== -->
  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="34" height="34">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/" class="is-active-link">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="open menu" aria-expanded="false"
          aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <!-- ===== story hero ===== -->
    <section class="story-hero" aria-label="our story introduction"<?= $aboutHeroPhoto ? ' style="background-image:linear-gradient(rgba(251,247,241,.82),rgba(251,247,241,.90)),url(\'' . htmlspecialchars($aboutHeroPhoto, ENT_QUOTES, 'UTF-8') . '\');background-size:cover;background-position:center"' : '' ?>>
      <div class="wrap story-hero-inner">
        <p class="eyebrow reveal">
          <span class="eyebrow-dot"></span>since 2016
        </p>
        <h1 class="reveal">
          a studio built <em>by hand,</em> <br />one piece at a time
        </h1>
        <p class="reveal">
          the little green house isn't a factory — it's a small room with a wheel, a
          pour table, and a deep belief that the things we live with should
          carry the mark of the person who made them.
        </p>
        <div class="reveal">
          <a href="#story-continue" class="btn btn-primary">read the full story</a>
        </div>
      </div>
    </section>

    <!-- ===== story main content ===== -->
    <section class="story-main" id="story-continue" aria-label="full story">
      <div class="wrap">
        <div class="story-grid">
          <!-- left column: text -->
          <div class="story-block">
            <div class="reveal">
              <p class="eyebrow">
                <span class="eyebrow-dot"></span>the beginning
              </p>
              <h2>from a spare room <br />to a <em>quiet studio</em></h2>
              <p>
                the little green house started in 2016 with a second‑hand pottery
                wheel and a handful of candle tins. the name came from a sunlit space where handcrafted pottery,
                botanical candles, and lush indoor plants live together.
              </p>
              <p>
                what began as a weekend experiment slowly became a way of
                life. every pot is still centred by hand. every candle is
                still poured one batch at a time. we don't chase scale — we
                chase honesty.
              </p>
            </div>

            <div class="story-highlight reveal">
              <div class="hl-item">
                <span class="hl-num">9</span>
                <span class="hl-label">years in the studio</span>
              </div>
              <div class="hl-item">
                <span class="hl-num">100%</span>
                <span class="hl-label">hand‑finished pieces</span>
              </div>
              <div class="hl-item">
                <span class="hl-num">1</span>
                <span class="hl-label">wheel, one studio</span>
              </div>
            </div>

            <div class="reveal" style="margin-top: 38px">
              <p class="eyebrow">
                <span class="eyebrow-dot"></span>our philosophy
              </p>
              <h2>made slowly, <em>on purpose</em></h2>
              <p>
                we believe that the things you keep close should be made with
                care — not speed. that's why every piece we make is touched by
                the same pair of hands, from the first wedge of clay to the
                final inspection.
              </p>
              <p>
                if a glaze runs a little differently, or a candle's edge isn't
                perfectly straight — that's not a flaw. that's the hand that
                made it, still visible. we'd rather make three hundred pieces
                we're proud of than three thousand we're not.
              </p>
            </div>
          </div>

          <!-- right column: visual (svg illustration) -->
          <div class="story-visual-block reveal">
            <svg viewBox="0 0 500 600" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <!-- background earth tone -->
              <rect width="500" height="600" fill="#f5ecdf" rx="24" />
              <!-- shelf -->
              <rect x="40" y="520" width="420" height="14" rx="4" fill="#ce9969" opacity="0.5" />
              <!-- potter's wheel base -->
              <ellipse cx="250" cy="490" rx="160" ry="30" fill="#c3804c" opacity="0.4" />
              <ellipse cx="250" cy="482" rx="150" ry="26" fill="#975637" />
              <!-- pot being shaped -->
              <path d="M190 320 Q178 420 250 480 Q322 420 310 320 Z" fill="#ce9969" />
              <ellipse cx="250" cy="318" rx="64" ry="20" fill="#7a4632" />
              <ellipse cx="250" cy="313" rx="52" ry="14" fill="#e5cdae" opacity="0.8" />
              <!-- hands (simplified) -->
              <path d="M160 390 Q138 370 130 330 Q128 310 148 306 Q162 304 168 320 Q188 340 190 380 Z" fill="#7a4632" />
              <path d="M340 390 Q362 370 370 330 Q372 310 352 306 Q338 304 332 320 Q312 340 310 380 Z" fill="#7a4632" />
              <!-- clay splashes / texture -->
              <circle cx="200" cy="260" r="6" fill="#fbf7f1" opacity="0.5" />
              <circle cx="290" cy="270" r="5" fill="#fbf7f1" opacity="0.4" />
              <circle cx="250" cy="240" r="4" fill="#fbf7f1" opacity="0.5" />
              <!-- small finished pots on shelf -->
              <path d="M80 500 Q74 520 100 525 Q126 520 120 500 Z" fill="#b56c41" />
              <ellipse cx="100" cy="498" rx="22" ry="7" fill="#633b2b" />
              <path d="M380 500 Q374 520 400 525 Q426 520 420 500 Z" fill="#c3804c" />
              <ellipse cx="400" cy="498" rx="22" ry="7" fill="#7a4632" />
              <!-- candle beside wheel -->
              <rect x="380" y="420" width="30" height="54" rx="3" fill="#f5ecdf" stroke="#ddbb94" stroke-width="2" />
              <rect x="392" y="406" width="6" height="16" fill="#e5cdae" />
              <ellipse cx="395" cy="400" rx="4" ry="9" fill="#e6a95c" />
              <!-- leaves / plant -->
              <path d="M250 310 C230 250 190 220 160 190 C200 220 230 250 245 298" fill="#8a9a6b" />
              <path d="M250 310 C270 245 310 215 340 185 C300 220 270 250 255 298" fill="#7a8a5c" />
              <path d="M250 310 C250 240 250 200 250 165 C250 210 250 255 250 306" fill="#9aab77" />
              <!-- tiny sparkle / dust -->
              <circle cx="220" cy="140" r="3" fill="#ce9969" opacity="0.4" />
              <circle cx="280" cy="130" r="2" fill="#ce9969" opacity="0.3" />
            </svg>
          </div>
        </div>

        <!-- extra block: "the process" teaser (optional but adds depth) -->
        <div class="story-grid" style="
              margin-top: 80px;
              border-top: 1px solid var(--line);
              padding-top: 70px;
            ">
          <div class="story-block reveal">
            <p class="eyebrow">
              <span class="eyebrow-dot"></span>the process
            </p>
            <h2>from raw material <br />to your <em>shelf</em></h2>
            <p>
              clay is wedged, centred, and thrown on the wheel. candles are
              weighed and poured by eye, not by app. every single piece is
              inspected before it's wrapped — nothing ships that we wouldn't
              keep ourselves.
            </p>
            <p>
              we use recycled kraft, straw, and minimal packaging. because the
              thing you're receiving should feel like it was made for you —
              because it was.
            </p>
            <a href="../theprocess/" class="btn btn-ghost" style="margin-top: 20px">see the full process →</a>
          </div>
          <div class="story-block reveal">
            <p class="eyebrow">
              <span class="eyebrow-dot"></span>our promise
            </p>
            <h2>made to be kept, <em>not replaced</em></h2>
            <p>
              we don't design for trends. we design for longevity — pieces
              that will still feel warm and honest a decade from now. because
              a home isn't built in a season. it's built slowly, one piece at
              a time.
            </p>
            <p style="
                  margin-top: 12px;
                  font-style: italic;
                  color: var(--c-800);
                ">
              — the the little green house studio
            </p>
          </div>
        </div>

        <!-- back to top / shop link -->
        <div style="text-align: center; margin-top: 70px" class="reveal">
          <a href="#top" class="btn btn-primary" style="padding: 12px 32px">back to top</a>
          <a href="../shop/" class="btn btn-ghost" style="margin-left: 12px">visit the shop</a>
        </div>
      </div>
    </section>
  </main>

  <!-- ===== footer ===== -->
  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>
          handmade pots, candles &amp; home décor — made slowly, on purpose.
        </p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    (function () {
      "use strict";

      // scroll reveal
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.15, rootMargin: "0px 0px -40px 0px" },
      );

      document
        .querySelectorAll(".reveal")
        .forEach((el) => observer.observe(el));

      // mobile nav toggle
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) => {
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          });
        });
      }

      // cart dot micro interaction (visual only)
      const cartDot = document.querySelector(".cart-dot");
      document.addEventListener("click", (e) => {
        const btn = e.target.closest(".add-btn");
        if (!btn) return;
        if (cartDot) {
          cartDot.style.animation = "none";
          void cartDot.offsetWidth;
          cartDot.style.background = "var(--c-600)";
          cartDot.style.transform = "scale(1.6)";
          setTimeout(() => {
            cartDot.style.transform = "scale(1)";
          }, 300);
        }
      });

      // header shadow on scroll
      const header = document.querySelector(".site-header");
      window.addEventListener(
        "scroll",
        () => {
          if (header) {
            header.style.boxShadow =
              window.scrollY > 20
                ? "0 8px 24px -18px rgba(53,29,21,0.35)"
                : "none";
          }
        },
        { passive: true },
      );
    })();
  </script>
</body>

</html>
