<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — terms & conditions</title>
  <meta name="description"
    content="read the terms and conditions for using the little green house website and purchasing handmade products." />
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>📋</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1180px;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
      letter-spacing: 0.01em;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    ul {
      list-style: none;
    }

    img {
      display: block;
      max-width: 100%;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 9999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    .reveal {
      opacity: 0;
      transform: translateY(24px);
      transition:
        opacity 0.8s var(--ease-hand),
        transform 0.8s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 14px 26px;
      border-radius: 100px;
      font-size: 0.9rem;
      font-weight: 500;
      letter-spacing: 0.02em;
      white-space: nowrap;
      transition: all 0.3s var(--ease-hand);
      min-height: 44px;
      touch-action: manipulation;
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      background: var(--c-900);
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
    }

    .btn-outline {
      border: 1.5px solid var(--c-700);
      color: var(--ink);
      background: transparent;
    }

    .btn-outline:hover {
      background: var(--c-800);
      color: var(--c-50);
      border-color: var(--c-800);
      transform: translateY(-3px);
    }

    /* header */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 600;
      background: rgba(251, 247, 241, 0.86);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 80px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.35rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
      transition: color 0.3s;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active {
      color: var(--ink);
    }

    .main-nav a.is-active::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s,
        color 0.3s;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .profile-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: var(--c-600);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition: 0.3s;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* terms hero */
    .terms-hero {
      padding: 60px 0 30px;
      text-align: center;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .terms-hero h1 {
      font-size: clamp(2rem, 4vw, 3rem);
      line-height: 1.1;
      margin-bottom: 10px;
    }

    .terms-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .terms-hero p {
      color: var(--muted);
      font-size: 1.1rem;
      max-width: 600px;
      margin: 0 auto;
    }

    .last-updated {
      display: inline-block;
      margin-top: 16px;
      font-size: 0.85rem;
      color: var(--c-600);
      background: var(--c-100);
      padding: 6px 16px;
      border-radius: 30px;
    }

    /* terms main */
    .terms-main {
      padding: 50px 0 80px;
    }

    .terms-content {
      max-width: 800px;
      margin: 0 auto;
    }

    .terms-section {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      padding: 28px;
      margin-bottom: 24px;
    }

    .terms-section h2 {
      font-size: 1.4rem;
      margin-bottom: 16px;
      font-family: var(--font-display);
    }

    .terms-section h3 {
      font-size: 1.1rem;
      margin: 20px 0 10px;
    }

    .terms-section p {
      color: var(--muted);
      font-size: 0.95rem;
      line-height: 1.7;
      margin-bottom: 12px;
    }

    .terms-section ul {
      margin-bottom: 12px;
      padding-left: 20px;
    }

    .terms-section ul li {
      color: var(--muted);
      font-size: 0.95rem;
      line-height: 1.7;
      margin-bottom: 8px;
      list-style: disc;
    }

    .terms-section .highlight {
      background: var(--surface-2);
      border-left: 3px solid var(--c-600);
      padding: 16px 20px;
      border-radius: var(--radius-sm);
      margin: 16px 0;
    }

    .terms-section .highlight p {
      color: var(--ink-soft);
      margin-bottom: 0;
    }

    /* info box */
    .info-box {
      display: flex;
      gap: 16px;
      padding: 20px;
      background: var(--surface-2);
      border-radius: var(--radius-sm);
      margin: 16px 0;
      align-items: flex-start;
    }

    .info-box .icon {
      font-size: 1.8rem;
      flex-shrink: 0;
    }

    .info-box h4 {
      font-size: 0.95rem;
      margin-bottom: 4px;
    }

    .info-box p {
      font-size: 0.85rem;
      color: var(--muted);
      margin-bottom: 0;
    }

    /* contact section */
    .contact-terms {
      text-align: center;
      padding: 40px 20px;
      background: var(--surface-2);
      border-radius: var(--radius-lg);
      margin-top: 40px;
    }

    .contact-terms h3 {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }

    .contact-terms p {
      color: var(--muted);
      margin-bottom: 20px;
    }

    .contact-actions {
      display: flex;
      gap: 12px;
      justify-content: center;
      flex-wrap: wrap;
    }

    /* footer */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 70px 0 0;
      margin-top: 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.8fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 50px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand p {
      margin: 14px 0 20px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 12px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      transition: 0.3s;
    }

    .socials a:hover {
      background: var(--c-600);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 16px;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.2s;
    }

    .footer-col a:hover {
      color: white;
    }

    .footer-bottom {
      padding: 24px 0;
      text-align: center;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
    }

    /* responsive */
    @media (max-width: 1024px) {
      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 16px;
      }

      .header-inner {
        height: 64px;
      }

      .logo-text {
        font-size: 1.1rem;
      }

      .main-nav {
        position: fixed;
        top: 64px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 16px 28px 28px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition: 0.4s var(--ease-hand);
        z-index: 500;
        max-height: calc(100vh - 64px);
        overflow-y: auto;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 16px 0;
        border-bottom: 1px solid var(--line);
        font-size: 1rem;
      }

      .menu-toggle {
        display: flex;
      }

      .profile-avatar {
        width: 32px;
        height: 32px;
        font-size: 0.8rem;
      }

      .terms-hero {
        padding: 40px 0 20px;
      }

      .terms-hero h1 {
        font-size: 1.8rem;
      }

      .terms-hero p {
        font-size: 1rem;
      }

      .terms-main {
        padding: 30px 0 60px;
      }

      .terms-section {
        padding: 20px 16px;
      }

      .terms-section h2 {
        font-size: 1.2rem;
      }

      .terms-section h3 {
        font-size: 1rem;
      }

      .info-box {
        flex-direction: column;
        gap: 8px;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 30px;
        padding-bottom: 30px;
      }

      .site-footer {
        padding: 50px 0 0;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <link rel="canonical" href="https://thelittlegreenhouse.in/terms-and-conditions/" />
  <meta property="og:title" content="the little green house — terms &amp; conditions" />
  <meta property="og:description" content="read the terms and conditions for using the little green house website and purchasing handmade products." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/terms-and-conditions/" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
  <a class="skip-link" href="#main">skip to terms</a>
  <div class="grain" aria-hidden="true"></div>

  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo" aria-label="the little green house home">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="30" height="30">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products"><svg width="19" height="19" viewBox="0 0 24 24"
            fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg></a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="menu" aria-expanded="false" aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <section class="terms-hero">
      <div class="wrap">
        <h1>terms <em>&amp;</em> conditions</h1>
        <p>
          please read these terms carefully before using our website or
          purchasing our products.
        </p>
        <span class="last-updated">last updated: january 15, 2026</span>
      </div>
    </section>

    <section class="terms-main">
      <div class="wrap">
        <div class="terms-content">
          <!-- acceptance -->
          <div class="terms-section">
            <h2>acceptance of terms</h2>
            <p>
              by accessing or using the the little green house website, you agree to be
              bound by these terms and conditions. if you do not agree with
              any part of these terms, please do not use our website.
            </p>
            <p>
              we reserve the right to update or modify these terms at any time
              without prior notice. your continued use of the site after any
              changes constitutes acceptance of the updated terms.
            </p>
          </div>

          <!-- products -->
          <div class="terms-section">
            <h2>products & handmade nature</h2>
            <p>
              all our products are handmade by artisans in bhubaneswar,
              odisha. due to the nature of handmade items:
            </p>
            <ul>
              <li>
                each piece is unique and may have slight variations in color,
                texture, size, and finish
              </li>
              <li>
                product images are representative — your item may differ
                slightly from what's shown
              </li>
              <li>
                natural materials like terracotta and clay may develop patina
                over time
              </li>
              <li>
                these variations are not defects but characteristics of
                authentic handmade products
              </li>
            </ul>

            <div class="highlight">
              <p>
                <strong>we believe in transparency:</strong> what you see is a
                handmade creation, not a factory product. embrace the
                imperfections — they make your piece one of a kind.
              </p>
            </div>
          </div>

          <!-- orders -->
          <div class="terms-section">
            <h2>orders & payment</h2>
            <h3>placing orders</h3>
            <p>
              when you place an order, you're making an offer to purchase. we
              reserve the right to accept or decline any order for any reason.
            </p>

            <h3>pricing</h3>
            <p>
              all prices are listed in indian rupees (₹) and include
              applicable taxes unless stated otherwise. we reserve the right
              to change prices at any time without notice.
            </p>

            <h3>payment</h3>
            <p>
              we accept major credit/debit cards, upi, net banking, and select
              digital wallets. payment must be completed before orders are
              processed.
            </p>

            <div class="info-box">
              <div class="icon">🔒</div>
              <div>
                <h4>secure payments</h4>
                <p>
                  all transactions are encrypted and processed through secure
                  payment gateways. we never store your full card details.
                </p>
              </div>
            </div>
          </div>

          <!-- shipping -->
          <div class="terms-section">
            <h2>shipping & delivery</h2>
            <ul>
              <li>orders are processed within 3-5 business days</li>
              <li>
                domestic delivery takes 5-8 business days after dispatch
              </li>
              <li>
                international delivery takes 2-3 weeks depending on
                destination
              </li>
              <li>free shipping on domestic orders over ₹2,500</li>
              <li>
                delivery times are estimates and may vary during peak seasons
              </li>
            </ul>
            <p>
              risk of loss passes to you upon delivery of the products to the
              carrier. we're not responsible for delays caused by customs,
              weather, or other circumstances beyond our control.
            </p>
          </div>

          <!-- returns -->
          <div class="terms-section">
            <h2>returns & refunds</h2>
            <p>
              we accept returns within <strong>14 days</strong> of delivery
              for unused, undamaged items in original packaging.
            </p>

            <h3>non-returnable items</h3>
            <ul>
              <li>custom or personalized orders</li>
              <li>items marked as "final sale" or "clearance"</li>
              <li>gift cards</li>
              <li>used candles or items showing signs of wear</li>
            </ul>

            <p>
              refunds are processed to the original payment method within 5-7
              business days after we receive and inspect the returned item.
            </p>
          </div>

          <!-- intellectual property -->
          <div class="terms-section">
            <h2>intellectual property</h2>
            <p>
              all content on this website, including text, graphics, logos,
              images, product designs, and software, is the property of the little green house and protected by
              intellectual property laws.
            </p>
            <p>
              you may not reproduce, distribute, modify, or create derivative
              works of any content without our prior written consent.
            </p>
          </div>

          <!-- user accounts -->
          <div class="terms-section">
            <h2>user accounts</h2>
            <p>if you create an account, you are responsible for:</p>
            <ul>
              <li>
                maintaining the confidentiality of your account credentials
              </li>
              <li>all activities that occur under your account</li>
              <li>providing accurate and current information</li>
              <li>notifying us immediately of any unauthorized use</li>
            </ul>
            <p>
              we reserve the right to terminate accounts or refuse service at
              our discretion.
            </p>
          </div>

          <!-- liability -->
          <div class="terms-section">
            <h2>limitation of liability</h2>
            <p>
              the little green house shall not be liable for any indirect, incidental,
              special, consequential, or punitive damages arising from your
              use of our products or website.
            </p>
            <p>
              our total liability for any claim shall not exceed the amount
              you paid for the specific product in question.
            </p>

            <div class="highlight">
              <p>
                <strong>nothing in these terms limits liability that cannot be
                  excluded under applicable law.</strong>
              </p>
            </div>
          </div>

          <!-- governing law -->
          <div class="terms-section">
            <h2>governing law</h2>
            <p>
              these terms shall be governed by and construed in accordance
              with the laws of india. any disputes shall be subject to the
              exclusive jurisdiction of the courts in bhubaneswar, odisha.
            </p>
          </div>

          <!-- contact -->
          <div class="contact-terms">
            <h3>questions about these terms?</h3>
            <p>we're here to clarify anything you need.</p>
            <div class="contact-actions">
              <a href="mailto:legal@thelittlegreenhouse.com" class="btn btn-primary">email us</a>
              <a href="#contact" class="btn btn-outline">contact page</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>handmade pots, candles & home décor — made slowly, on purpose.</p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    (function () {
      // menu toggle
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) =>
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }),
        );
      }

      // close mobile nav on outside click
      document.addEventListener("click", (e) => {
        if (mainNav && mainNav.classList.contains("is-open")) {
          if (
            !e.target.closest(".main-nav") &&
            !e.target.closest(".menu-toggle")
          ) {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }
        }
      });

      // header shadow
      const header = document.querySelector(".site-header");
      window.addEventListener(
        "scroll",
        () => {
          header.style.boxShadow =
            window.scrollY > 20
              ? "0 8px 24px -18px rgba(53,29,21,0.35)"
              : "none";
        },
        { passive: true },
      );

      // scroll reveal
      const revealObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              revealObserver.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.1 },
      );

      document
        .querySelectorAll(".reveal")
        .forEach((el) => revealObserver.observe(el));
    })();
  </script>
</body>

</html>