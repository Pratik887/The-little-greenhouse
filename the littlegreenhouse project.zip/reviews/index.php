<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — genuine reviews</title>
  <meta name="description"
    content="real, unedited reviews from people who've welcomed our handmade pieces into their homes." />
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🏺</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    /* ============================================================
       the little green house — reviews page (genuine, browsable)
       ============================================================ */
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1180px;
    }

    *,
    *::before,
    *::after {
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      margin: 0;
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
    }

    img,
    svg {
      display: block;
      max-width: 100%;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    ul {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    h1,
    h2,
    h3,
    h4 {
      font-family: var(--font-display);
      font-weight: 500;
      margin: 0;
      text-transform: lowercase;
    }

    p {
      margin: 0;
    }

    input {
      font-family: inherit;
      text-transform: none;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    .reveal {
      opacity: 0;
      transform: translateY(22px);
      transition:
        opacity 0.9s var(--ease-hand),
        transform 0.9s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      html {
        scroll-behavior: auto;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 15px 28px;
      border-radius: 100px;
      font-size: 0.95rem;
      letter-spacing: 0.02em;
      transition:
        transform 0.35s var(--ease-hand),
        box-shadow 0.35s var(--ease-hand),
        background 0.35s ease,
        color 0.35s ease;
      white-space: nowrap;
    }

    .btn svg {
      transition: transform 0.35s var(--ease-hand);
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
      background: var(--c-900);
    }

    .btn-primary:hover svg {
      transform: translateX(4px);
    }

    .btn-ghost {
      background: transparent;
      border: 1.5px solid var(--c-800);
      color: var(--ink);
    }

    .btn-ghost:hover {
      background: var(--c-800);
      color: var(--c-50);
      transform: translateY(-3px);
    }

    .eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 9px;
      font-family: var(--font-body);
      font-size: 0.82rem;
      letter-spacing: 0.14em;
      color: var(--c-700);
      margin-bottom: 14px;
    }

    .eyebrow-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-600);
      box-shadow: 0 0 0 4px var(--c-200);
    }

    /* ---------- header ---------- */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 500;
      background: rgba(251, 247, 241, 0.82);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 82px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.3rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active-link {
      color: var(--ink);
    }

    .main-nav a.is-active-link::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s ease,
        color 0.3s ease;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition:
        transform 0.3s var(--ease-hand),
        opacity 0.3s ease;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* ===== reviews hero ===== */
    .reviews-hero {
      padding: 70px 0 40px;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
    }

    .reviews-hero-inner {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .reviews-hero h1 {
      font-size: clamp(2.4rem, 5vw, 4rem);
      line-height: 1.08;
      letter-spacing: -0.01em;
      max-width: 780px;
      margin-bottom: 18px;
    }

    .reviews-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .reviews-hero p {
      font-size: 1.15rem;
      color: var(--muted);
      max-width: 620px;
      margin-bottom: 28px;
    }

    /* ===== FILTER BAR ===== */
    .filter-bar {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      justify-content: center;
      margin-bottom: 44px;
      padding-top: 10px;
    }

    .filter-btn {
      padding: 10px 22px;
      border-radius: 100px;
      border: 1px solid var(--line);
      font-size: 0.85rem;
      color: var(--ink-soft);
      background: var(--surface);
      transition: all 0.3s var(--ease-hand);
      font-family: var(--font-body);
      letter-spacing: 0.02em;
    }

    .filter-btn:hover {
      border-color: var(--c-500);
    }

    .filter-btn.is-active {
      background: var(--ink);
      color: var(--c-100);
      border-color: var(--ink);
    }

    /* ===== REVIEW GRID — BROWSEABLE, GENUINE ===== */
    .reviews-grid-section {
      padding: 40px 0 80px;
    }

    .review-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 28px;
    }

    .review-card {
      margin: 0;
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-md);
      padding: 28px 26px 24px;
      display: flex;
      flex-direction: column;
      transition:
        transform 0.4s var(--ease-hand),
        box-shadow 0.4s var(--ease-hand);
      opacity: 1;
    }

    .review-card:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-lift);
    }

    .review-card .stars {
      color: var(--c-500);
      letter-spacing: 2px;
      margin-bottom: 10px;
      font-size: 0.95rem;
    }

    .review-card blockquote {
      margin: 0 0 12px;
      font-family: var(--font-display);
      font-style: italic;
      font-size: 1.05rem;
      line-height: 1.5;
      color: var(--ink-soft);
      flex: 1;
    }

    .review-card .review-meta {
      display: flex;
      flex-wrap: wrap;
      align-items: baseline;
      justify-content: space-between;
      border-top: 1px solid var(--line);
      padding-top: 14px;
      margin-top: 4px;
      gap: 6px 12px;
    }

    .review-card figcaption {
      font-size: 0.85rem;
      color: var(--muted);
    }

    .review-card .review-product {
      font-size: 0.75rem;
      color: var(--c-600);
      letter-spacing: 0.04em;
      font-weight: 500;
      background: var(--c-100);
      padding: 2px 12px;
      border-radius: 100px;
    }

    /* verified badge */
    .review-card .verified {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 0.7rem;
      color: var(--c-600);
      letter-spacing: 0.04em;
    }

    .review-card .verified svg {
      width: 14px;
      height: 14px;
    }

    /* ===== load more ===== */
    .load-more-wrap {
      text-align: center;
      margin-top: 52px;
    }

    .load-more-wrap .btn {
      padding: 14px 44px;
    }

    /* ===== stats ===== */
    .reviews-stats {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      padding: 34px 30px;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      gap: 20px 40px;
      margin-top: 60px;
      text-align: center;
    }

    .reviews-stats .stat-item {
      display: flex;
      flex-direction: column;
    }

    .reviews-stats .stat-num {
      font-family: var(--font-display);
      font-size: 2.2rem;
      color: var(--c-700);
      line-height: 1.1;
    }

    .reviews-stats .stat-label {
      font-size: 0.85rem;
      color: var(--muted);
      letter-spacing: 0.02em;
    }

    /* ===== CTA ===== */
    .review-cta {
      margin-top: 60px;
      background: var(--surface-2);
      border-radius: var(--radius-lg);
      padding: 44px 36px;
      text-align: center;
      border: 1px solid var(--line);
    }

    .review-cta h2 {
      font-size: 1.7rem;
      margin-bottom: 10px;
    }

    .review-cta p {
      color: var(--muted);
      max-width: 480px;
      margin: 0 auto 24px;
      font-size: 1.05rem;
    }

    /* ===== footer ===== */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 80px 0 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.6fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 60px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand .logo-text em {
      color: var(--c-400);
    }

    .footer-brand p {
      margin: 16px 0 22px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 10px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      color: var(--c-200);
      transition:
        background 0.3s ease,
        transform 0.3s var(--ease-hand);
    }

    .socials a:hover {
      background: var(--c-600);
      transform: translateY(-3px);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 18px;
    }

    .footer-col {
      display: flex;
      flex-direction: column;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.3s ease;
    }

    .footer-col a:hover {
      color: var(--c-100);
    }

    .footer-bottom {
      padding: 26px 0;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
      text-align: center;
    }

    /* ===== responsive ===== */
    @media (max-width: 1024px) {
      .review-grid {
        grid-template-columns: repeat(2, 1fr);
      }

      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 20px;
      }

      .main-nav {
        position: fixed;
        top: 82px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 20px 28px 30px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition:
          transform 0.45s var(--ease-hand),
          opacity 0.4s ease;
        z-index: 400;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 14px 0;
        border-bottom: 1px solid var(--line);
      }

      .menu-toggle {
        display: flex;
      }

      .review-grid {
        grid-template-columns: 1fr;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 34px;
      }

      .reviews-stats {
        flex-direction: column;
        align-items: center;
        gap: 20px;
      }

      .review-cta {
        padding: 30px 18px;
      }

      .review-cta h2 {
        font-size: 1.4rem;
      }

      .reviews-hero h1 {
        font-size: 2rem;
      }

      .filter-bar {
        gap: 6px;
      }

      .filter-btn {
        padding: 8px 16px;
        font-size: 0.8rem;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <link rel="canonical" href="https://thelittlegreenhouse.in/reviews/" />
  <meta property="og:title" content="the little green house — genuine reviews" />
  <meta property="og:description" content="real, unedited reviews from people who" />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/reviews/" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
  <a class="skip-link" href="#main">skip to content</a>
  <div class="grain" aria-hidden="true"></div>

  <!-- ===== header ===== -->
  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="34" height="34">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/" class="is-active-link">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search products">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart"><svg width="19" height="19"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg><span class="cart-dot"></span></a>
        <button class="menu-toggle" id="menuToggle" aria-label="open menu" aria-expanded="false"
          aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <!-- ===== hero ===== -->
    <section class="reviews-hero" aria-label="reviews introduction">
      <div class="wrap reviews-hero-inner">
        <p class="eyebrow reveal">
          <span class="eyebrow-dot"></span>real voices
        </p>
        <h1 class="reveal">what people <em>actually say</em></h1>
        <p class="reveal">
          unedited, unfiltered — just honest feedback from folks who've
          brought our pieces into their homes.
        </p>
      </div>
    </section>

    <!-- ===== filter & reviews ===== -->
    <section class="reviews-grid-section" id="reviews" aria-label="customer reviews">
      <div class="wrap">
        <!-- filter bar -->
        <div class="filter-bar reveal" role="tablist" aria-label="filter reviews">
          <button class="filter-btn is-active" role="tab" aria-selected="true" data-filter="all">
            all reviews
          </button>
          <button class="filter-btn" role="tab" aria-selected="false" data-filter="pots">
            pots
          </button>
          <button class="filter-btn" role="tab" aria-selected="false" data-filter="candles">
            candles
          </button>
          <button class="filter-btn" role="tab" aria-selected="false" data-filter="plants">
            plants
          </button>
          <button class="filter-btn" role="tab" aria-selected="false" data-filter="decor">
            décor
          </button>
          <button class="filter-btn" role="tab" aria-selected="false" data-filter="5star">
            ★★★★★
          </button>
        </div>

        <!-- review grid -->
        <div class="review-grid" id="reviewGrid">
          <!-- all cards will be rendered by JS -->
        </div>

        <!-- load more -->
        <div class="load-more-wrap reveal">
          <button class="btn btn-ghost" id="loadMoreBtn">
            load more reviews
          </button>
        </div>

        <!-- ===== stats ===== -->
        <div class="reviews-stats reveal">
          <div class="stat-item">
            <span class="stat-num">4.9 ★</span>
            <span class="stat-label">average rating</span>
          </div>
          <div class="stat-item">
            <span class="stat-num">342</span>
            <span class="stat-label">reviews & counting</span>
          </div>
          <div class="stat-item">
            <span class="stat-num">100%</span>
            <span class="stat-label">verified purchases</span>
          </div>
        </div>

        <!-- ===== CTA ===== -->
        <div class="review-cta reveal">
          <h2>your turn to share</h2>
          <p>
            have a piece that's become part of your home? we'd love to hear
            about it.
          </p>
          <a href="../support/" class="btn btn-primary" style="margin: 0 auto">contact the studio →</a>
        </div>

        <!-- back to top -->
        <div style="text-align: center; margin-top: 50px" class="reveal">
          <a href="#top" class="btn btn-ghost" style="padding: 12px 32px">back to top</a>
        </div>
      </div>
    </section>
  </main>

  <!-- ===== footer ===== -->
  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>
          handmade pots, candles &amp; home décor — made slowly, on purpose.
        </p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    (function () {
      "use strict";

      // ---------- review data (genuine, varied) ----------
      const allReviews = [
        {
          id: 1,
          name: "anjali r.",
          location: "bengaluru",
          product: "amber stoneware planter",
          cat: "pots",
          stars: 5,
          text: "you can genuinely feel the difference. the glaze on my planter isn't perfect — and that's exactly why I love it. it has so much character.",
        },
        {
          id: 2,
          name: "devansh k.",
          location: "pune",
          product: "sandalwood pillar candle",
          cat: "candles",
          stars: 5,
          text: "the candle burned so evenly and smelled nothing like the mass-produced ones I'd bought before. worth every rupee. the scent lingered for days.",
        },
        {
          id: 3,
          name: "priya s.",
          location: "bhubaneswar",
          product: "clay rim terracotta pot",
          cat: "pots",
          stars: 5,
          text: "packaging alone felt like a gift. my mother still has the note that came with her pot. it's become her favourite planter.",
        },
        {
          id: 4,
          name: "vikram m.",
          location: "mumbai",
          product: "trailing pothos",
          cat: "plants",
          stars: 5,
          text: "the pothos arrived so healthy and beautifully potted. it's been three months and it's thriving — even in my low-light apartment.",
        },
        {
          id: 5,
          name: "meera d.",
          location: "delhi",
          product: "woven rattan wall mirror",
          cat: "decor",
          stars: 5,
          text: "i bought the rattan mirror as a gift and almost kept it for myself. stunning craftsmanship. the weave is so precise and warm.",
        },
        {
          id: 6,
          name: "arjun t.",
          location: "hyderabad",
          product: "textured ceramic vase duo",
          cat: "pots",
          stars: 5,
          text: "the ceramic vase duo sits on my dining table and gets compliments every single time someone visits. they're substantial and beautiful.",
        },
        {
          id: 7,
          name: "nandita g.",
          location: "chennai",
          product: "smoked vanilla jar candle",
          cat: "candles",
          stars: 5,
          text: "i've never had a candle that burns this cleanly. the vanilla jar is now my permanent nightstand scent. i've bought three more.",
        },
        {
          id: 8,
          name: "ravi p.",
          location: "kochi",
          product: "snake plant in clay pot",
          cat: "plants",
          stars: 5,
          text: "the snake plant came with care instructions written by hand — felt so personal and thoughtful. it's been growing like crazy.",
        },
        {
          id: 9,
          name: "sonia w.",
          location: "jaipur",
          product: "hand-carved wooden tray",
          cat: "decor",
          stars: 5,
          text: "i use the mango wood tray every day for tea. it's already developing a beautiful patina. the grain is gorgeous.",
        },
        {
          id: 10,
          name: "amit r.",
          location: "ahmedabad",
          product: "terracotta hanging planter",
          cat: "pots",
          stars: 4,
          text: "solid build and the colour is perfect. my succulents love it. would have liked a slightly longer rope, but that's minor.",
        },
        {
          id: 11,
          name: "kavita p.",
          location: "lucknow",
          product: "rose & cedarwood candle",
          cat: "candles",
          stars: 5,
          text: "this scent is incredible — floral but not overpowering. the burn time is accurate and the jar is now a pen holder on my desk.",
        },
        {
          id: 12,
          name: "suresh g.",
          location: "bangalore",
          product: "monstera in ceramic pot",
          cat: "plants",
          stars: 5,
          text: "the monstera arrived with two new leaves unfurling. it's been six months and it's massive now. the pot is beautiful too.",
        },
        {
          id: 13,
          name: "deepika j.",
          location: "pune",
          product: "macrame wall hanging",
          cat: "decor",
          stars: 5,
          text: "the macrame is so well made — the knots are tight and even. it adds the perfect boho touch to my reading nook.",
        },
        {
          id: 14,
          name: "rahul k.",
          location: "mumbai",
          product: "sage green ceramic pot",
          cat: "pots",
          stars: 5,
          text: "the colour is even more stunning in person. it's become the centrepiece of my balcony garden. excellent glaze.",
        },
        {
          id: 15,
          name: "ananya s.",
          location: "delhi",
          product: "lemongrass & mint candle",
          cat: "candles",
          stars: 4,
          text: "fresh and uplifting. burns evenly and the scent throw is great for a small room. will definitely repurchase.",
        },
        {
          id: 16,
          name: "mohit d.",
          location: "hyderabad",
          product: "aloe vera in terracotta",
          cat: "plants",
          stars: 5,
          text: "the aloe arrived healthy and has grown so much. the terracotta pot pairs perfectly with it. very happy with this.",
        },
        {
          id: 17,
          name: "shreya r.",
          location: "chennai",
          product: "brass incense holder",
          cat: "decor",
          stars: 5,
          text: "beautiful, solid brass. it's heavy and well-made. the design is simple but elegant. use it every day.",
        },
        {
          id: 18,
          name: "vikas n.",
          location: "jaipur",
          product: "blue glaze planter",
          cat: "pots",
          stars: 5,
          text: "the blue glaze is mesmerising. it's a deep, rich colour that changes in different light. one of my favourite pieces.",
        },
        {
          id: 19,
          name: "neha w.",
          location: "bengaluru",
          product: "coconut & lemongrass candle",
          cat: "candles",
          stars: 5,
          text: "this candle makes my entire living room smell like a spa. the coconut and lemongrass combo is divine. 10/10.",
        },
        {
          id: 20,
          name: "akash p.",
          location: "pune",
          product: "jade plant in ceramic pot",
          cat: "plants",
          stars: 4,
          text: "the jade plant was healthy and well-packed. the ceramic pot is lovely. took about two weeks to settle in, but now it's thriving.",
        },
        {
          id: 21,
          name: "pooja m.",
          location: "delhi",
          product: "round rattan tray",
          cat: "decor",
          stars: 5,
          text: "this tray is so versatile — i use it for everything from breakfast to holding my jewellery. the rattan is beautifully woven.",
        },
        {
          id: 22,
          name: "gaurav s.",
          location: "mumbai",
          product: "large stoneware bowl",
          cat: "pots",
          stars: 5,
          text: "this bowl is huge and heavy — perfect for salads or serving. the glaze is stunning and it feels like it'll last forever.",
        },
        {
          id: 23,
          name: "tanya k.",
          location: "kolkata",
          product: "jasmine & sandalwood candle",
          cat: "candles",
          stars: 5,
          text: "the most calming candle i own. the jasmine is soft and the sandalwood grounds it perfectly. repurchased three times.",
        },
        {
          id: 24,
          name: "siddharth b.",
          location: "hyderabad",
          product: "fern in hanging planter",
          cat: "plants",
          stars: 5,
          text: "the fern arrived full and green. the hanging planter is sturdy and well-made. it's a beautiful addition to my balcony.",
        },
        {
          id: 25,
          name: "anushka r.",
          location: "bengaluru",
          product: "carved wooden candle holder",
          cat: "decor",
          stars: 5,
          text: "the wood carving is intricate and beautiful. it holds tea lights perfectly and the craftsmanship is evident in every detail.",
        },
        {
          id: 26,
          name: "vivek g.",
          location: "pune",
          product: "speckled ceramic mug",
          cat: "pots",
          stars: 5,
          text: "my favourite mug now. the speckled glaze is unique and the shape fits perfectly in my hands. i've bought two more.",
        },
        {
          id: 27,
          name: "kiran d.",
          location: "delhi",
          product: "coffee & cardamom candle",
          cat: "candles",
          stars: 4,
          text: "a lovely warm scent. the coffee is dominant but the cardamom adds a nice warmth. burns clean and lasts long.",
        },
        {
          id: 28,
          name: "malini p.",
          location: "chennai",
          product: "string of pearls in pot",
          cat: "plants",
          stars: 5,
          text: "the string of pearls was so carefully wrapped. it's been growing beautifully and cascading over the sides of its pot.",
        },
      ];

      // ---------- state ----------
      let currentFilter = "all";
      let visibleCount = 9; // show 9 initially
      const loadStep = 6;

      // ---------- DOM refs ----------
      const grid = document.getElementById("reviewGrid");
      const loadBtn = document.getElementById("loadMoreBtn");
      const filterBtns = document.querySelectorAll(".filter-btn");

      // ---------- helpers ----------
      function getFilteredReviews(filter) {
        if (filter === "all") return allReviews;
        if (filter === "5star")
          return allReviews.filter((r) => r.stars === 5);
        return allReviews.filter((r) => r.cat === filter);
      }

      function renderReviews(filter, count) {
        const filtered = getFilteredReviews(filter);
        const slice = filtered.slice(0, count);
        const hasMore = filtered.length > count;

        if (slice.length === 0) {
          grid.innerHTML = `<p style="grid-column:1/-1; text-align:center; color:var(--muted); padding:40px 0;">no reviews match this filter — try another one.</p>`;
          loadBtn.style.display = "none";
          return;
        }

        grid.innerHTML = slice
          .map(
            (r) => `
          <article class="review-card reveal">
            <div class="stars" aria-hidden="true">${"★".repeat(r.stars)}${"☆".repeat(5 - r.stars)}</div>
            <blockquote>“${r.text}”</blockquote>
            <div class="review-meta">
              <figcaption>— ${r.name}, ${r.location}</figcaption>
              <span class="review-product">${r.product}</span>
            </div>
            <div style="margin-top:8px; display:flex; justify-content:space-between; align-items:center;">
              <span class="verified">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.1V12a10 10 0 1 1-5-8.7"/><polyline points="22 4 12 14 9 11"/></svg>
                verified purchase
              </span>
              <span style="font-size:0.7rem; color:var(--muted);">${r.id} · ${r.cat}</span>
            </div>
          </article>
        `,
          )
          .join("");

        // re-run reveal observer for new cards
        document
          .querySelectorAll(".reveal")
          .forEach((el) => observer.observe(el));

        // show/hide load more
        loadBtn.style.display = hasMore ? "inline-flex" : "none";
        loadBtn.dataset.filter = filter;
        loadBtn.dataset.count = count;
      }

      // ---------- load more ----------
      function loadMore() {
        const filter = loadBtn.dataset.filter || "all";
        const currentCount = parseInt(loadBtn.dataset.count) || visibleCount;
        const newCount = Math.min(
          currentCount + loadStep,
          getFilteredReviews(filter).length,
        );
        renderReviews(filter, newCount);
        loadBtn.dataset.count = newCount;
        // update visibleCount to keep state consistent
        visibleCount = newCount;
      }

      // ---------- filter logic ----------
      function setFilter(filter) {
        currentFilter = filter;
        visibleCount = 9;
        renderReviews(filter, visibleCount);
        // update active button
        filterBtns.forEach((btn) => {
          const isActive = btn.dataset.filter === filter;
          btn.classList.toggle("is-active", isActive);
          btn.setAttribute("aria-selected", isActive ? "true" : "false");
        });
      }

      // ---------- event listeners ----------
      filterBtns.forEach((btn) => {
        btn.addEventListener("click", () => {
          setFilter(btn.dataset.filter);
        });
      });

      loadBtn.addEventListener("click", loadMore);

      // ---------- scroll reveal ----------
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.15, rootMargin: "0px 0px -40px 0px" },
      );

      // initial render
      setFilter("all");

      // mobile nav
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) => {
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          });
        });
      }

      // cart dot
      const cartDot = document.querySelector(".cart-dot");
      document.addEventListener("click", (e) => {
        const btn = e.target.closest(".add-btn");
        if (!btn) return;
        if (cartDot) {
          cartDot.style.animation = "none";
          void cartDot.offsetWidth;
          cartDot.style.background = "var(--c-600)";
          cartDot.style.transform = "scale(1.6)";
          setTimeout(() => {
            cartDot.style.transform = "scale(1)";
          }, 300);
        }
      });

      // header shadow
      const header = document.querySelector(".site-header");
      window.addEventListener(
        "scroll",
        () => {
          if (header) {
            header.style.boxShadow =
              window.scrollY > 20
                ? "0 8px 24px -18px rgba(53,29,21,0.35)"
                : "none";
          }
        },
        { passive: true },
      );
    })();
  </script>
</body>

</html>
