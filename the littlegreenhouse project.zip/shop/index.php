<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>the little green house — shop handmade</title>
  <meta name="description"
    content="shop handmade pots, candles, and home décor from the little green house studio – made slowly, with purpose." />
  <link rel="icon"
    href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🕯️</text></svg>" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Jost:wght@300;400;500;600&display=swap"
    rel="stylesheet" />
  <style>
    :root {
      --c-50: #fbf7f1;
      --c-100: #f5ecdf;
      --c-200: #e5cdae;
      --c-300: #ddbb94;
      --c-400: #ce9969;
      --c-500: #c3804c;
      --c-600: #b56c41;
      --c-700: #975637;
      --c-800: #7a4632;
      --c-900: #633b2b;
      --c-950: #351d15;
      --bg: var(--c-50);
      --surface: #ffffff;
      --surface-2: var(--c-100);
      --ink: var(--c-950);
      --ink-soft: var(--c-800);
      --muted: var(--c-700);
      --line: var(--c-200);
      --accent: var(--c-600);
      --font-display: "Fraunces", "Iowan Old Style", serif;
      --font-body: "Jost", "Segoe UI", sans-serif;
      --radius-sm: 10px;
      --radius-md: 18px;
      --radius-lg: 30px;
      --shadow-soft: 0 10px 30px -12px rgba(53, 29, 21, 0.18);
      --shadow-lift: 0 20px 45px -15px rgba(53, 29, 21, 0.28);
      --ease-hand: cubic-bezier(0.22, 0.9, 0.3, 1);
      --container: 1280px;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background: var(--bg);
      color: var(--ink);
      font-family: var(--font-body);
      font-weight: 400;
      line-height: 1.6;
      text-transform: lowercase;
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
      letter-spacing: 0.01em;
    }

    a {
      color: inherit;
      text-decoration: none;
    }

    ul {
      list-style: none;
    }

    img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    button {
      font-family: inherit;
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
    }

    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
    }

    .skip-link {
      position: absolute;
      left: -999px;
      top: 0;
      background: var(--ink);
      color: var(--bg);
      padding: 12px 18px;
      border-radius: 0 0 10px 0;
      z-index: 9999;
    }

    .skip-link:focus {
      left: 0;
    }

    :focus-visible {
      outline: 2px solid var(--c-700);
      outline-offset: 3px;
      border-radius: 4px;
    }

    .wrap {
      max-width: var(--container);
      margin: 0 auto;
      padding: 0 28px;
    }

    .grain {
      position: fixed;
      inset: 0;
      z-index: 2000;
      pointer-events: none;
      opacity: 0.035;
      mix-blend-mode: multiply;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    }

    .reveal {
      opacity: 0;
      transform: translateY(24px);
      transition:
        opacity 0.8s var(--ease-hand),
        transform 0.8s var(--ease-hand);
    }

    .reveal.in-view {
      opacity: 1;
      transform: translateY(0);
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation: none !important;
        transition-duration: 0.01ms !important;
      }

      .reveal {
        opacity: 1;
        transform: none;
      }
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 14px 26px;
      border-radius: 100px;
      font-size: 0.9rem;
      font-weight: 500;
      letter-spacing: 0.02em;
      white-space: nowrap;
      transition: all 0.3s var(--ease-hand);
    }

    .btn-primary {
      background: var(--ink);
      color: var(--c-100);
      box-shadow: var(--shadow-soft);
    }

    .btn-primary:hover {
      background: var(--c-900);
      transform: translateY(-3px);
      box-shadow: var(--shadow-lift);
    }

    .btn-outline {
      border: 1.5px solid var(--c-700);
      color: var(--ink);
      background: transparent;
    }

    .btn-outline:hover {
      background: var(--c-800);
      color: var(--c-50);
      border-color: var(--c-800);
      transform: translateY(-3px);
    }

    /* header */
    .site-header {
      position: sticky;
      top: 0;
      z-index: 600;
      background: rgba(251, 247, 241, 0.86);
      backdrop-filter: blur(14px) saturate(1.1);
      border-bottom: 1px solid rgba(99, 59, 43, 0.1);
    }

    .header-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 80px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-mark {
      color: var(--c-700);
      display: flex;
    }

    .logo-text {
      font-family: var(--font-display);
      font-size: 1.35rem;
      letter-spacing: 0.01em;
      color: var(--ink);
    }

    .logo-text em {
      font-style: normal;
      color: var(--c-500);
    }

    .main-nav {
      display: flex;
      gap: 34px;
    }

    .main-nav a {
      font-size: 0.95rem;
      color: var(--ink-soft);
      position: relative;
      padding: 4px 0;
      transition: color 0.3s;
    }

    .main-nav a::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: -2px;
      width: 100%;
      height: 1.5px;
      background: var(--c-600);
      transform: scaleX(0);
      transform-origin: right;
      transition: transform 0.4s var(--ease-hand);
    }

    .main-nav a:hover::after {
      transform: scaleX(1);
      transform-origin: left;
    }

    .main-nav a.is-active {
      color: var(--ink);
    }

    .main-nav a.is-active::after {
      transform: scaleX(1);
      background: var(--c-500);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .icon-btn {
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      color: var(--ink-soft);
      transition:
        background 0.3s,
        color 0.3s;
      position: relative;
    }

    .icon-btn:hover {
      background: var(--c-100);
      color: var(--ink);
    }

    .cart-dot {
      position: absolute;
      top: 8px;
      right: 9px;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--c-500);
    }

    .menu-toggle {
      display: none;
      flex-direction: column;
      justify-content: center;
      gap: 5px;
      width: 40px;
      height: 40px;
    }

    .menu-toggle span {
      display: block;
      width: 20px;
      height: 1.5px;
      background: var(--ink);
      margin: 0 auto;
      transition: 0.3s;
    }

    .menu-toggle.is-open span:nth-child(1) {
      transform: translateY(6.5px) rotate(45deg);
    }

    .menu-toggle.is-open span:nth-child(2) {
      opacity: 0;
    }

    .menu-toggle.is-open span:nth-child(3) {
      transform: translateY(-6.5px) rotate(-45deg);
    }

    /* shop hero */
    .shop-hero {
      padding: 60px 0 30px;
      background: var(--surface-2);
      border-bottom: 1px solid var(--line);
      text-align: center;
    }

    .shop-hero h1 {
      font-size: clamp(2.5rem, 5vw, 4rem);
      line-height: 1.1;
      letter-spacing: -0.01em;
      margin-bottom: 12px;
    }

    .shop-hero h1 em {
      color: var(--c-600);
      font-style: italic;
    }

    .shop-hero p {
      font-size: 1.2rem;
      color: var(--muted);
      max-width: 600px;
      margin: 0 auto 20px;
    }

    .filter-bar {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 12px;
      margin-top: 30px;
    }

    .filter-btn {
      padding: 10px 22px;
      border-radius: 50px;
      background: transparent;
      border: 1px solid var(--c-300);
      color: var(--c-800);
      font-size: 0.85rem;
      transition: 0.2s;
      letter-spacing: 0.03em;
    }

    .filter-btn:hover {
      border-color: var(--c-600);
      color: var(--c-600);
    }

    .filter-btn.active {
      background: var(--ink);
      color: var(--c-100);
      border-color: var(--ink);
    }

    /* product grid */
    .product-section {
      padding: 50px 0 80px;
    }

    .product-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
      gap: 26px;
    }

    .product-card {
      background: var(--surface);
      border-radius: var(--radius-md);
      overflow: hidden;
      border: 1px solid var(--line);
      transition:
        transform 0.35s var(--ease-hand),
        box-shadow 0.35s;
      display: flex;
      flex-direction: column;
    }

    .product-card:hover {
      transform: translateY(-8px);
      box-shadow: var(--shadow-lift);
    }

    .product-media {
      position: relative;
      width: 100%;
      aspect-ratio: 4 / 3;
      /* vertical 4:3 */
      background: var(--surface-2);
      overflow: hidden;
    }

    .product-media img {
      transition: transform 0.6s var(--ease-hand);
    }

    .product-card:hover .product-media img {
      transform: scale(1.04);
    }

    .badge {
      position: absolute;
      top: 12px;
      left: 12px;
      background: var(--c-600);
      color: white;
      padding: 4px 12px;
      border-radius: 30px;
      font-size: 0.7rem;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      backdrop-filter: blur(4px);
    }

    .wishlist-btn {
      position: absolute;
      top: 12px;
      right: 12px;
      width: 36px;
      height: 36px;
      background: rgba(255, 255, 255, 0.7);
      backdrop-filter: blur(4px);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: 0.2s;
    }

    .wishlist-btn:hover {
      background: white;
      transform: scale(1.1);
    }

    .product-info {
      padding: 20px 18px 22px;
      flex: 1;
      display: flex;
      flex-direction: column;
    }

    .product-category {
      font-size: 0.7rem;
      letter-spacing: 0.08em;
      color: var(--c-600);
      margin-bottom: 6px;
    }

    .product-title {
      font-family: var(--font-display);
      font-size: 1.3rem;
      font-weight: 500;
      margin-bottom: 4px;
    }

    .product-price {
      font-size: 1.2rem;
      font-weight: 500;
      color: var(--c-700);
      margin-bottom: 14px;
    }

    .product-actions {
      margin-top: auto;
      display: flex;
      gap: 10px;
    }

    .add-btn {
      flex: 1;
      background: var(--ink);
      color: var(--c-100);
      border-radius: 30px;
      padding: 10px 12px;
      font-size: 0.8rem;
      transition: 0.2s;
      border: none;
    }

    .add-btn:hover {
      background: var(--c-700);
    }

    /* footer */
    .site-footer {
      background: var(--ink);
      color: var(--c-200);
      padding: 70px 0 0;
    }

    .footer-inner {
      display: grid;
      grid-template-columns: 1.8fr 1fr 1fr 1fr;
      gap: 40px;
      padding-bottom: 50px;
      border-bottom: 1px solid rgba(245, 236, 223, 0.12);
    }

    .footer-brand .logo-text {
      color: var(--c-100);
    }

    .footer-brand p {
      margin: 14px 0 20px;
      font-size: 0.9rem;
      color: var(--c-300);
      max-width: 260px;
    }

    .socials {
      display: flex;
      gap: 12px;
    }

    .socials a {
      width: 38px;
      height: 38px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid rgba(245, 236, 223, 0.2);
      transition: 0.3s;
    }

    .socials a:hover {
      background: var(--c-600);
    }

    .footer-col h4 {
      font-family: var(--font-body);
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--c-400);
      margin-bottom: 16px;
    }

    .footer-col a {
      display: block;
      font-size: 0.9rem;
      color: var(--c-300);
      margin-bottom: 12px;
      transition: color 0.2s;
    }

    .footer-col a:hover {
      color: white;
    }

    .footer-bottom {
      padding: 24px 0;
      text-align: center;
    }

    .footer-bottom p {
      font-size: 0.8rem;
      color: var(--c-400);
    }

    /* responsive */
    @media (max-width: 1024px) {
      .product-grid {
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      }

      .footer-inner {
        grid-template-columns: 1fr 1fr;
      }
    }

    @media (max-width: 760px) {
      .wrap {
        padding: 0 18px;
      }

      .main-nav {
        position: fixed;
        top: 80px;
        left: 0;
        right: 0;
        background: var(--bg);
        flex-direction: column;
        padding: 16px 28px 28px;
        gap: 0;
        border-bottom: 1px solid var(--line);
        transform: translateY(-130%);
        opacity: 0;
        transition: 0.4s var(--ease-hand);
        z-index: 500;
      }

      .main-nav.is-open {
        transform: translateY(0);
        opacity: 1;
      }

      .main-nav a {
        padding: 14px 0;
        border-bottom: 1px solid var(--line);
      }

      .menu-toggle {
        display: flex;
      }

      .product-grid {
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 16px;
      }

      .footer-inner {
        grid-template-columns: 1fr;
        gap: 30px;
      }

      .filter-bar {
        gap: 8px;
      }

      .filter-btn {
        padding: 8px 16px;
        font-size: 0.75rem;
      }

      .product-info {
        padding: 14px 12px 16px;
      }

      .product-title {
        font-size: 1.1rem;
      }
    }
      input, textarea, select { text-transform: none; }
</style>
  <link rel="canonical" href="https://thelittlegreenhouse.in/shop/" />
  <meta property="og:title" content="the little green house — shop handmade" />
  <meta property="og:description" content="shop handmade pots, candles, and home d&#233;cor from the little green house studio – made slowly, with purpose." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://thelittlegreenhouse.in/shop/" />
  <meta property="og:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:image" content="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1200&h=630&q=85" />
  <meta property="og:site_name" content="the little green house" />
</head>

<body>
  <a class="skip-link" href="#main">skip to shop</a>
  <div class="grain" aria-hidden="true"></div>

  <header class="site-header" id="top">
    <div class="wrap header-inner">
      <a href="../" class="logo" aria-label="the little green house home">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 48 48" width="34" height="34">
            <path d="M14 18 Q12 40 24 42 Q36 40 34 18 Z" fill="none" stroke="currentColor" stroke-width="2" />
            <ellipse cx="24" cy="17" rx="11" ry="4" fill="none" stroke="currentColor" stroke-width="2" />
          </svg>
        </span>
        <span class="logo-text">the little green house</span>
      </a>
      <nav class="main-nav" id="main-nav" aria-label="primary">
        <a href="../shop/" class="is-active">shop</a>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit</a>
      </nav>
      <div class="header-actions">
        <a href="../shop/" class="icon-btn" aria-label="search">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </a>
        <a href="../cart/" class="icon-btn cart-btn" aria-label="view cart" id="headerCartBtn">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.3 4.6A1 1 0 0 0 5.6 19H17M17 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM9 19a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
          </svg>
          <span class="cart-dot" id="cartBadge" aria-label="cart items"></span>
        </a>
        <button class="menu-toggle" id="menuToggle" aria-label="menu" aria-expanded="false" aria-controls="main-nav">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    <section class="shop-hero">
      <div class="wrap">
        <h1>handmade <em>shop</em></h1>
        <p>
          small batches, honest materials — pots, candles, and quiet pieces
          for your home.
        </p>
        <div class="filter-bar" id="filterBar">
          <button class="filter-btn active" data-filter="all">all</button>
          <button class="filter-btn" data-filter="pots">
            pots & planters
          </button>
          <button class="filter-btn" data-filter="candles">candles</button>
          <button class="filter-btn" data-filter="decor">home décor</button>
          <button class="filter-btn" data-filter="plants">plants</button>
        </div>
      </div>
    </section>

    <section class="product-section" aria-label="product listing">
      <div class="wrap">
        <div class="product-grid" id="productGrid">
          <!-- product cards will be injected by javascript -->
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="wrap footer-inner">
      <div class="footer-brand">
        <span class="logo-text">the little green house</span>
        <p>handmade pots, candles & home décor — made slowly, on purpose.</p>
        <div class="socials">
          <a href="https://instagram.com/thelittlegreenhouse" aria-label="instagram" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <rect x="3" y="3" width="18" height="18" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle cx="17.5" cy="6.5" r="1" />
            </svg></a>
          <a href="https://pinterest.com/thelittlegreenhouse" aria-label="pinterest" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <circle cx="12" cy="12" r="10" />
              <path d="M9.5 17.5 12 8m0 0c3 0 4.5 1.5 4.5 3.8 0 2.5-1.3 4.7-3.6 4.7-1 0-1.7-.5-2-1" />
            </svg></a>
          <a href="https://facebook.com/thelittlegreenhouse" aria-label="facebook" target="_blank" rel="noopener noreferrer"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" stroke-width="1.6">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z" />
            </svg></a>
        </div>
      </div>
      <nav class="footer-col" aria-label="shop links">
        <h4>shop</h4>
        <a href="../shop/?cat=pots">pots &amp; planters</a>
        <a href="../shop/?cat=candles">candles</a>
        <a href="../shop/?cat=plants">plants</a>
        <a href="../shop/?cat=decor">home décor</a>
        <a href="../category/">browse categories</a>
      </nav>
      <nav class="footer-col" aria-label="studio links">
        <h4>studio</h4>
        <a href="../ourstory/">our story</a>
        <a href="../theprocess/">the process</a>
        <a href="../reviews/">reviews</a>
        <a href="../visit/">visit us</a>
        <a href="../faqs/">faqs</a>
      </nav>
      <div class="footer-col">
        <h4>help &amp; care</h4>
        <a href="../shipping-and-returns/">shipping &amp; returns</a>
        <a href="../care-guide/">caring for your piece</a>
        <a href="../terms-and-conditions/">terms &amp; conditions</a>
        <a href="../privacy-policy/">privacy policy</a>
        <a href="../order/">track order</a>
        <a href="../cart/">shopping cart</a>
      </div>
    </div>
    <div class="wrap footer-bottom">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script src="../cart.js?v=20261013-cart-fix-1"></script>
  <script>
    (function () {
      let products = [];

      const grid = document.getElementById("productGrid");
      const filterBar = document.getElementById("filterBar");
      let activeFilter = new URLSearchParams(window.location.search).get("cat") || "all";

      function renderProducts(filter) {
        const filtered =
          filter === "all"
            ? products
            : products.filter((p) => p.category === filter);
        if (!filtered.length) {
          grid.innerHTML = `<p role="status" style="grid-column:1/-1;text-align:center;padding:36px;color:var(--muted)">No products are available in this collection yet.</p>`;
          return;
        }
        grid.innerHTML = filtered
          .map(
            (p) => `
          <article class="product-card reveal in-view" data-category="${p.category}">
            <div class="product-media">
              <a href="../product/?id=${p.id}" style="display:block;width:100%;height:100%;"><img src="${p.img}" alt="${p.title}" loading="lazy" /></a>
              ${p.badge ? `<span class="badge">${p.badge}</span>` : ""}
              <button class="wishlist-btn" aria-label="add to wishlist" onclick="window.location.href='../favourites/'">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z"/></svg>
              </button>
            </div>
            <div class="product-info">
              <span class="product-category">${p.category}</span>
              <h3 class="product-title"><a href="../product/?id=${p.id}" style="color:inherit;text-decoration:none;">${p.title}</a></h3>
              <span class="product-price">${p.compare ? `<s class="was" style="color:var(--muted);font-size:0.9rem;">&#8377;${Number(p.compare).toLocaleString('en-IN')}</s> ` : ""}${p.price}</span>
              <div class="product-actions">
                <button class="add-btn" data-add="${p.id}" ${p.stock < 1 ? 'disabled aria-disabled="true"' : ''} aria-label="add ${p.title} to cart">${p.stock < 1 ? 'out of stock' : 'add to cart'}</button>
                <a href="../product/?id=${p.id}" style="flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;border:1.5px solid var(--c-300);color:var(--c-700);font-size:0.7rem;transition:0.2s;" aria-label="view ${p.title}" title="view details">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
              </div>
            </div>
          </article>
        `,
          )
          .join("");
      }

      async function loadCatalog() {
        try {
          const [response, categoryResponse] = await Promise.all([fetch('../api/products'), fetch('../api/categories')]);
          if (!response.ok) return;
          const data = await response.json();
          if (Array.isArray(data.products)) {
            products = data.products.map(p => ({
              id: Number(p.id),
              title: p.name,
              category: p.category_slug,
              price: `\u20b9${Number(p.price).toLocaleString('en-IN')}`,
              rawPrice: Number(p.price),
              compare: Number(p.compare_at_price) > Number(p.price) ? Number(p.compare_at_price) : 0,
              img: p.primary_image || 'https://placehold.co/600x450/E5CDAE/633B2B?text=handmade',
              badge: p.tag || '',
              category_name: p.category_name || p.category_slug,
              // The shared cart rejects a product with no available stock.
              // Preserve the API's web-stock value when mapping shop cards.
              stock: Math.max(0, Number(p.online_stock_quantity ?? p.stock_quantity ?? 0))
            }));
          }
          if (categoryResponse.ok) {
            const categoryData = await categoryResponse.json();
            if (Array.isArray(categoryData.categories)) {
              if (!categoryData.categories.some(c => c.slug === activeFilter)) activeFilter = 'all';
              filterBar.innerHTML = `<button class="filter-btn ${activeFilter === 'all' ? 'active' : ''}" data-filter="all">all</button>` +
                categoryData.categories.map(c => `<button class="filter-btn ${activeFilter === c.slug ? 'active' : ''}" data-filter="${c.slug}">${c.name}</button>`).join('');
            }
          }
          renderProducts(activeFilter);
        } catch (_) { /* Keep the local preview catalog when the API is offline. */ }
      }
      renderProducts(activeFilter);
      loadCatalog();

      filterBar.addEventListener("click", (e) => {
        const btn = e.target.closest(".filter-btn");
        if (!btn) return;
        filterBar.querySelectorAll(".filter-btn").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        activeFilter = btn.dataset.filter;
        renderProducts(activeFilter);
      });

      /* ── Add to Cart ── */
      grid.addEventListener("click", (e) => {
        const button = e.target.closest("[data-add]");
        if (!button) return;
        const product = products.find((item) => item.id === Number(button.dataset.add));
        if (!product) return;

        const addedItems = window.TLGHCart.add({
          id: product.id,
          title: product.title,
          price: product.rawPrice || Number(product.price.replace(/[^\d]/g, '')),
          category: product.category_name || product.category,
          img: product.img,
          stock: product.stock
        }, 1);

        if (!addedItems) {
          button.textContent = 'out of stock';
          button.disabled = true;
          button.setAttribute('aria-disabled', 'true');
          return;
        }

        // Visual feedback on button
        const origText = button.textContent;
        button.textContent = "\u2713 added!";
        button.style.background = "var(--c-700)";
        setTimeout(() => {
          button.textContent = origText;
          button.style.background = "";
        }, 1400);

        // Mini toast
        showCartToast(product.title);
      });

      function showCartToast(title) {
        let toast = document.getElementById('addToCartToast');
        if (!toast) {
          toast = document.createElement('div');
          toast.id = 'addToCartToast';
          toast.style.cssText = [
            'position:fixed', 'bottom:28px', 'left:50%', 'transform:translateX(-50%) translateY(16px)',
            'background:var(--c-950,#351d15)', 'color:#fff', 'padding:12px 22px',
            'border-radius:50px', 'font-size:0.85rem', 'opacity:0', 'transition:all 0.3s ease',
            'z-index:3000', 'pointer-events:none', 'display:flex', 'align-items:center', 'gap:8px',
            'box-shadow:0 8px 24px rgba(53,29,21,0.35)'
          ].join(';');
          document.body.appendChild(toast);
        }
        toast.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> <span>${title.substring(0,28)}${title.length>28?'…':''} added to cart</span> <a href="../cart/" style="color:var(--c-300);text-decoration:underline;font-size:0.78rem;white-space:nowrap;">view cart</a>`;
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(-50%) translateY(0)';
        clearTimeout(toast._t);
        toast._t = setTimeout(() => {
          toast.style.opacity = '0';
          toast.style.transform = 'translateX(-50%) translateY(16px)';
        }, 2800);
      }

      // menu toggle
      const menuToggle = document.getElementById("menuToggle");
      const mainNav = document.getElementById("main-nav");
      if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
          const isOpen = mainNav.classList.toggle("is-open");
          menuToggle.classList.toggle("is-open", isOpen);
          menuToggle.setAttribute("aria-expanded", String(isOpen));
        });
        mainNav.querySelectorAll("a").forEach((link) =>
          link.addEventListener("click", () => {
            mainNav.classList.remove("is-open");
            menuToggle.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
          }),
        );
      }

      // scroll reveal
      const revealObserver = new IntersectionObserver(
        (entries) => { entries.forEach((entry) => { if (entry.isIntersecting) entry.target.classList.add("in-view"); }); },
        { threshold: 0.1 },
      );
      document.querySelectorAll(".reveal").forEach((el) => revealObserver.observe(el));

      // header shadow
      const header = document.querySelector(".site-header");
      window.addEventListener("scroll", () => {
        header.style.boxShadow = window.scrollY > 20 ? "0 8px 24px -18px rgba(53,29,21,0.35)" : "none";
      }, { passive: true });
    })();
  </script>
</body>

</html>
