<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="refresh" content="2; url=../shop/" />
  <title>guest checkout | the little green house</title>
  <meta name="description" content="Continue to the Little Green House shop and checkout as a guest." />
  <meta name="robots" content="noindex, nofollow" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../styles.css" />
  <style>
    body {
      background: #fbf7f1;
      color: #3b2c22;
      font-family: "Jost", sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      text-transform: lowercase;
    }
    .redirect-card {
      max-width: 540px;
      margin: 80px auto;
      padding: 36px 32px;
      background: #ffffff;
      border: 1px solid #e3d3bd;
      border-radius: 20px;
      text-align: center;
      box-shadow: 0 10px 30px -12px rgba(53, 29, 21, 0.12);
    }
    .redirect-card h1 {
      font-family: "Fraunces", serif;
      font-size: 2rem;
      color: #4a1b0c;
      margin-bottom: 12px;
    }
    .redirect-card p {
      color: #6b5847;
      line-height: 1.7;
      margin-bottom: 24px;
      font-size: 0.95rem;
    }
  </style>
</head>

<body>
  <header class="site-header">
    <div class="wrap" style="display:flex; justify-content:space-between; align-items:center; height:70px;">
      <a class="logo-text" href="../">the little green house</a>
      <nav style="display:flex; gap:20px;">
        <a href="../shop/">shop</a>
        <a href="../order/">track order</a>
        <a href="../cart/">cart</a>
      </nav>
    </div>
  </header>

  <main class="wrap">
    <div class="redirect-card">
      <h1>shop as a guest</h1>
      <p>
        we have simplified our studio experience — customer profiles and accounts are no longer needed! you can place orders seamlessly as a guest with fast express checkout and track any shipment anytime.
      </p>
      <a class="btn btn-primary" href="../shop/">continue to shop &rarr;</a>
    </div>
  </main>

  <footer class="site-footer">
    <div class="wrap footer-bottom" style="text-align:center; padding:20px 0;">
      <p>© 2026 The Little Green House. Developed by MSC HIRETECH.</p>
    </div>
  </footer>

  <script>
    setTimeout(function() {
      window.location.replace("../shop/");
    }, 1500);
  </script>
</body>

</html>
