// ==========================================================================
// the little green house — site script
// ==========================================================================

(function () {
    "use strict";

    /* ---------------------------------------------------------------------
       product data
       small illustrated svg "photos" so every card feels hand illustrated
       rather than stock-photo generic, in keeping with the earthy palette.
    --------------------------------------------------------------------- */
    const products = [];

    // --- tiny inline svg "product photo" generators (keeps things on-brand,
    // no external stock imagery needed, loads instantly) -------------------
    function potSvg(body, rim) {
        return `<svg viewBox="0 0 200 200"><path d="M60 90 Q54 160 100 175 Q146 160 140 90 Z" fill="${body}"/><ellipse cx="100" cy="88" rx="42" ry="14" fill="${rim}"/><ellipse cx="100" cy="84" rx="36" ry="11" fill="${body}" opacity="0.6"/></svg>`;
    }
    function candleSvg(wax, flame) {
        return `<svg viewBox="0 0 200 200"><rect x="76" y="90" width="48" height="86" rx="4" fill="${wax}" stroke="#ddbb94" stroke-width="2"/><rect x="96" y="70" width="8" height="22" fill="#e5cdae"/><ellipse cx="100" cy="62" rx="6" ry="13" fill="${flame}"/></svg>`;
    }
    function jarCandleSvg(wax, flame) {
        return `<svg viewBox="0 0 200 200"><rect x="66" y="100" width="68" height="70" rx="10" fill="${wax}" stroke="#c3804c" stroke-width="2"/><rect x="96" y="82" width="8" height="20" fill="#e5cdae"/><ellipse cx="100" cy="76" rx="6" ry="12" fill="${flame}"/></svg>`;
    }
    function plantSvg(leaf, pot) {
        return `<svg viewBox="0 0 200 200"><path d="M78 150 Q74 178 100 182 Q126 178 122 150 Z" fill="${pot}"/><path d="M100 150 C80 120 55 110 40 90 C65 105 92 122 100 145" fill="${leaf}"/><path d="M100 150 C120 115 145 105 160 88 C138 108 112 125 102 148" fill="${leaf}" opacity="0.85"/><path d="M100 150 C100 110 100 90 100 65 C100 95 100 125 100 148" fill="${leaf}" opacity="0.7"/></svg>`;
    }
    function snakePlantSvg(leaf, pot) {
        return `<svg viewBox="0 0 200 200"><path d="M74 150 Q70 178 100 182 Q130 178 126 150 Z" fill="${pot}"/><path d="M85 150 C82 110 88 80 92 55 C96 80 92 115 96 150 Z" fill="${leaf}"/><path d="M100 150 C98 105 104 75 108 48 C112 75 106 112 110 150 Z" fill="${leaf}" opacity="0.9"/><path d="M113 150 C112 115 118 90 122 68 C126 92 120 118 122 150 Z" fill="${leaf}" opacity="0.8"/></svg>`;
    }
    function mirrorSvg(frame, glass) {
        return `<svg viewBox="0 0 200 200"><circle cx="100" cy="100" r="60" fill="none" stroke="${frame}" stroke-width="14"/><circle cx="100" cy="100" r="50" fill="${glass}" opacity="0.6"/><rect x="94" y="158" width="12" height="26" fill="${frame}"/></svg>`;
    }
    function traySvg(wood, dark) {
        return `<svg viewBox="0 0 200 200"><ellipse cx="100" cy="110" rx="70" ry="30" fill="${wood}"/><ellipse cx="100" cy="105" rx="58" ry="22" fill="${dark}" opacity="0.35"/></svg>`;
    }
    function vaseDuoSvg(a, b) {
        return `<svg viewBox="0 0 200 200"><path d="M60 100 Q56 160 82 172 Q108 160 104 100 Z" fill="${a}"/><path d="M118 80 Q112 160 148 176 Q184 160 178 80 Z" fill="${b}"/></svg>`;
    }

    /* ---------------------------------------------------------------------
       render products
    --------------------------------------------------------------------- */
    const grid = document.getElementById("productGrid");
    const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
    const asAmount = value => Number(String(value ?? "").replace(/[^0-9.]/g, "")) || 0;
    const money = value => `₹${asAmount(value).toLocaleString("en-IN")}`;

    function renderProducts(filter) {
        if (!grid) return;
        const list = filter === "all" ? products : products.filter(p => p.cat === filter);
        if (!list.length) {
            grid.innerHTML = `<p role="status" style="grid-column:1/-1;text-align:center;padding:36px;color:var(--muted)">The collection is being prepared. Please check back soon.</p>`;
            return;
        }

        grid.innerHTML = list.map((p, i) => `
      <article class="product-card" style="transition-delay:${(i % 3) * 80}ms">
        <div class="product-media">
          ${p.tag ? `<span class="product-tag">${escapeHtml(p.tag)}</span>` : ""}
          <button class="product-wish" aria-label="save ${p.name} to wishlist" onclick="window.location.href='favourites/'">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z"/></svg>
          </button>
          <a href="product/?id=${Number(String(p.id).replace('p',''))}" style="display:block;width:100%;height:100%;">${p.image ? `<img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" loading="lazy" style="width:100%;height:100%;object-fit:cover">` : p.svg}</a>
        </div>
        <div class="product-info">
            <h3><a href="product/?id=${Number(String(p.id).replace('p',''))}" style="color:inherit;text-decoration:none;">${escapeHtml(p.name)}</a></h3>
            <p class="p-desc">${escapeHtml(p.desc)}</p>
          <div class="product-bottom">
            <span class="p-price">${p.was ? `<span class="was">${money(p.was)}</span>` : ""}${money(p.price)}</span>
          <button class="add-btn" aria-label="add ${escapeHtml(p.name)} to cart" data-product="${Number(String(p.id).replace('p',''))}" data-name="${escapeHtml(p.name)}" data-price="${asAmount(p.price)}" data-category="${escapeHtml(p.cat)}" ${p.stock === 0 ? "disabled" : ""}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </button>
          </div>
        </div>
      </article>
    `).join("");

        // stagger the reveal after paint
        requestAnimationFrame(() => {
            grid.querySelectorAll(".product-card").forEach(card => {
                observer.observe(card);
            });
        });
    }

    /* ---------------------------------------------------------------------
       scroll reveal (intersection observer)
    --------------------------------------------------------------------- */
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("in-view");
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15, rootMargin: "0px 0px -40px 0px" });

    document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

    renderProducts("all");

    // The database catalog is the source of truth for names, images, prices,
    // categories and availability. Keep the illustrated catalog as an offline preview.
    (async function loadCatalog() {
        try {
            const [productResponse, categoryResponse] = await Promise.all([
                fetch("api/products", { headers: { Accept: "application/json" } }),
                fetch("api/categories", { headers: { Accept: "application/json" } })
            ]);
            if (!productResponse.ok || !categoryResponse.ok) return;
            const [productData, categoryData] = await Promise.all([productResponse.json(), categoryResponse.json()]);
            if (Array.isArray(productData.products)) {
                products.splice(0, products.length, ...productData.products.map(p => ({
                    id: Number(p.id), name: p.name, desc: p.short_description || p.description || "",
                    price: Number(p.price), was: Number(p.compare_at_price) > Number(p.price) ? Number(p.compare_at_price) : "",
                    cat: p.category_slug, tag: p.tag || "", image: p.primary_image || "", stock: Number(p.stock_quantity), svg: ""
                })));
            }
            const chips = document.querySelector(".filter-row");
            if (chips && Array.isArray(categoryData.categories)) {
                chips.innerHTML = `<button class="filter-chip is-active" role="tab" aria-selected="true" data-filter="all">all</button>` +
                    categoryData.categories.map(c => `<button class="filter-chip" role="tab" aria-selected="false" data-filter="${c.slug}">${c.name}</button>`).join("");
                chips.querySelectorAll(".filter-chip").forEach(chip => chip.addEventListener("click", () => {
                    chips.querySelectorAll(".filter-chip").forEach(c => { c.classList.remove("is-active"); c.setAttribute("aria-selected", "false"); });
                    chip.classList.add("is-active"); chip.setAttribute("aria-selected", "true"); renderProducts(chip.dataset.filter);
                }));
                const categoryGrid = document.querySelector(".cat-grid");
                if (categoryGrid) categoryGrid.innerHTML = categoryData.categories.map(c => `<a href="shop/?cat=${encodeURIComponent(c.slug)}" class="cat-card reveal"><div class="cat-icon">${c.image_url ? `<img src="${escapeHtml(c.image_url)}" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;border-radius:50%">` : escapeHtml(c.name.slice(0, 1).toUpperCase())}</div><h3>${escapeHtml(c.name)}</h3><p>${escapeHtml(c.description || "Thoughtful pieces, made slowly and by hand.")}</p></a>`).join("");
            }
            renderProducts(document.querySelector(".filter-chip.is-active")?.dataset.filter || "all");
        } catch (_) { /* Keep the offline preview catalog if the API is unavailable. */ }
    })();

    /* ---------------------------------------------------------------------
       category filters
    --------------------------------------------------------------------- */
    document.querySelectorAll(".filter-chip").forEach(chip => {
        chip.addEventListener("click", () => {
            document.querySelectorAll(".filter-chip").forEach(c => {
                c.classList.remove("is-active");
                c.setAttribute("aria-selected", "false");
            });
            chip.classList.add("is-active");
            chip.setAttribute("aria-selected", "true");
            renderProducts(chip.dataset.filter);
        });
    });

    /* ---------------------------------------------------------------------
       cart micro-interaction (visual feedback only — no backend)
    --------------------------------------------------------------------- */
    let cartCount = Number(localStorage.getItem('tlgh_cart_count') || 0);
    const cartDot = document.querySelector(".cart-dot");

    document.addEventListener("click", (e) => {
        const btn = e.target.closest(".add-btn");
        if (!btn) return;
        const productId = Number(btn.dataset.product);
        const basket = JSON.parse(localStorage.getItem('tlgh_cart') || '[]');
        const item = basket.find(entry => Number(entry.product_id) === productId);
        if (item) item.quantity++;
        else basket.push({ product_id: productId, quantity: 1, title: btn.dataset.name, price: Number(btn.dataset.price), category: btn.dataset.category });
        localStorage.setItem('tlgh_cart', JSON.stringify(basket));
        cartCount = basket.reduce((n, entry) => n + entry.quantity, 0);
        localStorage.setItem('tlgh_cart_count', String(cartCount));
        btn.style.transform = "scale(0.85) rotate(90deg)";
        setTimeout(() => { btn.style.transform = ""; }, 250);
        if (cartDot) {
            cartDot.style.animation = "none";
            // trigger reflow to restart animation
            void cartDot.offsetWidth;
            cartDot.style.background = "var(--c-600)";
            cartDot.style.transform = "scale(1.6)";
            setTimeout(() => { cartDot.style.transform = "scale(1)"; }, 300);
        }
    });

    /* ---------------------------------------------------------------------
       mobile nav toggle
    --------------------------------------------------------------------- */
    const menuToggle = document.getElementById("menuToggle");
    const mainNav = document.getElementById("main-nav");

    if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", () => {
            const isOpen = mainNav.classList.toggle("is-open");
            menuToggle.classList.toggle("is-open", isOpen);
            menuToggle.setAttribute("aria-expanded", String(isOpen));
        });

        mainNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                mainNav.classList.remove("is-open");
                menuToggle.classList.remove("is-open");
                menuToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    /* ---------------------------------------------------------------------
       newsletter subscription system
    --------------------------------------------------------------------- */
    const newsletterForm = document.getElementById("newsletterForm");
    const formNote = document.getElementById("formNote");

    if (newsletterForm) {
        newsletterForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const emailInput = document.getElementById("newsletterEmail");
            const email = (emailInput ? emailInput.value : "").trim();
            const submitBtn = newsletterForm.querySelector('button[type="submit"]');
            
            if (!email) return;

            if (formNote) {
                formNote.style.color = "var(--ink-soft)";
                formNote.textContent = "adding you to the studio list…";
            }
            if (submitBtn) {
                submitBtn.disabled = true;
            }

            // Determine API path based on directory depth
            const isSubdir = window.location.pathname.includes('/') && 
                             !window.location.pathname.endsWith('/') && 
                             window.location.pathname.split('/').filter(Boolean).length > 1;
            const apiEndpoint = (document.querySelector('base')?.href || '') + (isSubdir || window.location.pathname.includes('/shop') || window.location.pathname.includes('/product') || window.location.pathname.includes('/category') || window.location.pathname.includes('/cart') || window.location.pathname.includes('/order') || window.location.pathname.includes('/visit') ? '../api/newsletter' : 'api/newsletter');

            try {
                const response = await fetch(apiEndpoint, {
                    method: "POST",
                    headers: { "Content-Type": "application/json", "Accept": "application/json" },
                    body: JSON.stringify({ email })
                });
                const data = await response.json().catch(() => ({}));
                
                if (!response.ok) {
                    throw new Error(data.error || "Subscription could not be processed");
                }
                
                if (formNote) {
                    formNote.style.color = "var(--clay-dark)";
                    formNote.textContent = data.message || "thank you — you're on the list! a welcome note is on its way to your inbox.";
                }
                newsletterForm.reset();
            } catch (error) {
                if (formNote) {
                    formNote.style.color = "var(--danger, #a5423a)";
                    formNote.textContent = error.message || "we couldn't save your subscription just now. please try again shortly.";
                }
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                }
            }
        });
    }

    /* ---------------------------------------------------------------------
       header shadow on scroll (subtle depth cue)
    --------------------------------------------------------------------- */
    const header = document.querySelector(".site-header");
    let lastScroll = 0;
    window.addEventListener("scroll", () => {
        const y = window.scrollY;
        if (header) {
            header.style.boxShadow = y > 20 ? "0 8px 24px -18px rgba(53,29,21,0.35)" : "none";
        }
        lastScroll = y;
    }, { passive: true });

})();
